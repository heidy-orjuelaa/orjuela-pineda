package silkRoad;

import java.util.Random;
import shapes.Rectangle;

/**
 * Tienda autónoma que decide su propia ubicación dentro del rango del mapa.
 * Ignora la posición que se le indica al ser creada. 
 */
public class AutonomousStore extends Store {

    private static final int MAX_LENGTH = 100; 
    private Random rand = new Random();

    public AutonomousStore(int location, int tenges) {
        super(randLocation(), tenges);
    }

    private static int randLocation() {
        Random random = new Random();
        return random.nextInt(MAX_LENGTH); 
    }

    @Override
    public String toString() {
        return "AutonomousStore{" +
                "location=" + getLocation() +
                ", tenges=" + getTenges() +
                '}';
    }
}
