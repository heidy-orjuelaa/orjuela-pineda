package silkRoad;

/**
 * Clase NormalRobot.
 * 
 * Representa un robot estándar dentro del juego SilkRoad.
 * 
 */

public class NormalRobot extends Robot {

    public NormalRobot(int location, String color) {
        super(location, color);
    }
}
