package silkRoad;
import shapes.Rectangle; 


/**
 * Clase Store
 * Cada tienda tiene una ubicación, una cantidad de tenges (dinero),
 * y un contador de cuántas veces ha sido desocupada.
 * 
 * La tienda puede ser mostrada o escondida visualmente mediante
 * un objeto Rectangle. Su color cambia dependiendo de si está vacía o llena.
 * 
 */
public class Store {

    private int location;        
    private int tenges;           
    private int initialTenges;    
    private int timesEmptied;     
    private Rectangle shape;      
    private boolean visible;      

    /**
     * Crea una tienda en una posición específica con cierta cantidad de tenges iniciales.
     *
     * @param location posición de la tienda en la ruta.
     * @param tenges cantidad inicial de tenges.
     * @throws IllegalArgumentException si location o tenges son negativos.
     */
    public Store(int location, int tenges) {
        if (location < 0) {
            throw new IllegalArgumentException("La ubicación de la tienda no puede ser negativa.");
        }
        if (tenges < 0) {
            throw new IllegalArgumentException("La cantidad inicial de tenges no puede ser negativa.");
        }
        
        this.location = location;
        this.tenges = tenges;
        this.initialTenges = tenges;
        this.timesEmptied = 0;
        this.visible = false;

        
        this.shape = new Rectangle();
        this.shape.changeColor("green");
        this.shape.moveHorizontal(location * 50);
    }

    /**
     * Retira una cantidad de dinero de la tienda.
     * Si la cantidad excede los tenges disponibles, la tienda queda vacía.
     *
     * @param amount cantidad a retirar (no puede ser negativa).
     * @throws IllegalArgumentException si amount es negativo.
     */
    public void withdraw(int amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("No se puede retirar una cantidad negativa.");
        }

        if (amount <= tenges) {
            tenges -= amount;
        } else {
            tenges = 0;
        }

        if (tenges == 0) {
            timesEmptied++;
            showEmpty();
        }
    }
    
    
    /** 
     * Reabastece la tienda con su cantidad inicial de tenges. 
     */
    public void resupply() {
        tenges = initialTenges;
        showFull();
    }

    /** Devuelve la cantidad actual de tenges. */
    public int getTenges() {
        return tenges;
    }

    /** Devuelve cuántas veces la tienda ha sido vaciada. */
    public int getTimesEmptied() {
        return timesEmptied;
    }

    /** Devuelve la ubicación de la tienda. */
    public int getLocation() {
        return location;
    }

    /** Devuelve la cantidad inicial de tenges. */
    public int getInitialTenges() {
        return initialTenges;
    }

    public void setTenges(int tenges) {
        this.tenges = tenges;
    }

    /** Muestra gráficamente la tienda. */
    public void show() {
        visible = true;
        shape.makeVisible();
    }

    /** Oculta gráficamente la tienda. */
    public void hide() {
        visible = false;
        shape.makeInvisible();
    }

    /** Cambia el color de la tienda a rojo cuando está vacía. */
    private void showEmpty() {
        shape.changeColor("red"); 
    }

    /** Cambia el color de la tienda a verde cuando está llena. */
    private void showFull() {
        shape.changeColor("green"); 
    }
}
