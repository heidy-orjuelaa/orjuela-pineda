package test;


import silkRoad.*;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas básicas para la clase SilkRoad.
 * 
 * Cubre las operaciones principales:
 * - Colocar tiendas en la ruta
 * - Colocar robots en la ruta
 * - Mover robots dentro de los límites
 * - Reabastecer tiendas
 * 
 * @author (Orjuela - Pineda)
 * @version 2025
 */
public class SilkRoadBasicTest {

    private SilkRoad road;

    /**
     * Inicializa la ruta antes de cada prueba.
     * Se crea una ruta de longitud 10 y se hace invisible
     * para evitar mostrar gráficos durante los tests.
     */
    
    @Before
    public void setUp() {
        road = new SilkRoad(10);
        road.makeInvisible(); 
    }

    /**
     * Prueba colocar una tienda en la ruta.
     * Verifica que:
     * - Se agregue la tienda correctamente al ArrayList de stores
     * - La ubicación de la tienda sea la esperada
     */
    
    @Test
    public void testPlaceStore() {
        road.placeStore(4, 100);
        assertEquals(1, road.stores().size());
        assertEquals(4, road.stores().get(0).getLocation());
    }

    /**
     * Prueba colocar un robot en la ruta.
     * Verifica que:
     * - Se agregue el robot correctamente al ArrayList de robots
     * - La ubicación inicial del robot sea la esperada
     */
    
    @Test
    public void testPlaceRobot() {
        road.placeRobot(2);
        assertEquals(1, road.robots().size());
        assertEquals(2, road.robots().get(0).getLocation());
    }

    /**
     * Prueba mover un robot dentro de los límites de la ruta.
     * Se mueve un robot 3 posiciones y se verifica que la nueva
     * ubicación sea correcta.
     */
    
    @Test
    public void testMoveRobot() {
        road.placeRobot(1);
         road.moveRobot(1, 3); 
        assertEquals(4, road.robots().get(0).getLocation());
    }

    /**
     * Prueba el reabastecimiento de las tiendas.
     * - Primero vacía todas las tiendas
     * - Luego llama a resupplyStores
     * - Finalmente verifica que cada tienda tenga dinero nuevamente
     */
    
    @Test
    public void testResupplyStores() {
        road.placeStore(5, 50);
        
        for (Store s : road.stores()) {
            s.withdraw(s.getTenges());
            assertEquals(0, s.getTenges());
        }

        road.resupplyStores();

        for (Store s : road.stores()) {
            assertTrue("La tienda debe tener dinero nuevamente", s.getTenges() > 0);
        }
    } 
}

