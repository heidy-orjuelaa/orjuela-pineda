package silkRoad;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.Timer;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import shapes.*;

/**
 *
 * Incluye botones de control, barra de progreso, área de registro
 * y un lienzo central para el dibujo visual de la simulación.</p>
 *
 * 
 *   Control de visibilidad del modelo</li>
 *   Interacción con botones para crear y reiniciar elementos</li>
 * 
 *
 * @author (Orjuela - Pineda)
 * @version 2025
 */
public class SilkRoadGUI extends JFrame {
    
    private final int POSITIONS = 20; 
    private final SilkRoad silkRoad;
    private final CanvasPanel canvas;
    private final JTextArea logArea;
    private final JProgressBar profitBar;
    private final JButton btnAddStore, btnAddRobot, btnSimulate, btnStep, btnStop;
    private final JButton btnResupply, btnReturnRobots, btnReboot, btnToggleVisible;

    private Timer simulationTimer;
    private boolean simulating = false;
    private final int TIMER_DELAY = 500; 

    private final Map<Store, Color> storeColors = new HashMap<>();
    private final Map<Robot, Color> robotColors = new HashMap<>();
    private final Random rnd = new Random();

    private final Map<Robot, Boolean> robotBlinkState = new HashMap<>();
    private boolean blinkOn = true; 
    
    public SilkRoadGUI() {
        super("Silk Road Simulator (Swing)");
        this.silkRoad = new SilkRoad(POSITIONS);
        silkRoad.makeVisible();

        canvas = new CanvasPanel();
        logArea = new JTextArea(6, 40);
        logArea.setEditable(false);
        profitBar = new JProgressBar(0, 100);
        profitBar.setStringPainted(false); 
        profitBar.setPreferredSize(new Dimension(400, 18));

        btnAddStore = new JButton("Agregar Tienda");
        btnAddRobot = new JButton("Agregar Robot");
        btnSimulate = new JButton("Simular");
        btnStep = new JButton("Step");
        btnStop = new JButton("Parar");
        btnResupply = new JButton("Reabastecer Tiendas");
        btnReturnRobots = new JButton("Regresar Robots");
        btnReboot = new JButton("Reiniciar");
        btnToggleVisible = new JButton("Invisible");

        setupLayout();
        setupActions();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * Configura la disposición (layout) de los componentes gráficos en la interfaz.
     * 
     * Organiza los botones en la parte superior, el área de simulación en el centro
     * y el panel de registro y progreso en el lado derecho.
     */
    
    private void setupLayout() {
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(btnAddStore);
        topPanel.add(btnAddRobot);
        topPanel.add(btnSimulate);
        topPanel.add(btnStep);
        topPanel.add(btnStop);
        topPanel.add(btnResupply);
        topPanel.add(btnReturnRobots);
        topPanel.add(btnReboot);
        topPanel.add(btnToggleVisible);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(new JLabel("Registro:"), BorderLayout.NORTH);
        rightPanel.add(new JScrollPane(logArea), BorderLayout.CENTER);
        rightPanel.add(profitBar, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(canvas, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);
    }

    /**
     * Asigna las acciones correspondientes a cada botón de la interfaz.
     * 
     *agregar una tienda o iniciar la simulación.
     */
    
    private void setupActions() {
        btnAddStore.addActionListener(e -> handleAddStore());
        btnAddRobot.addActionListener(e -> handleAddRobot());
        btnSimulate.addActionListener(e -> startSimulation());
        btnStep.addActionListener(e -> stepSimulation());
        btnStop.addActionListener(e -> stopSimulation());
        btnResupply.addActionListener(e -> handleResupply());
        btnReturnRobots.addActionListener(e -> handleReturnRobots());
        btnReboot.addActionListener(e -> handleReboot());
        btnToggleVisible.addActionListener(e -> toggleVisible());
    }

    /**
     * Maneja la acción del botón "Agregar Tienda".
     * 
     *Solicita al usuario mediante cuadros de diálogo la ubicación y la cantidad
     * inicial de tenges de la tienda. Valida que los valores sean enteros y estén
     * dentro del rango permitido. Si la posición ya está ocupada por otra tienda,
     * muestra un mensaje informativo
     * 
     * Una vez validado, crea la tienda mediante,
     * le asigna un color aleatorio y actualiza la interfaz registro, barra de progreso
     * y lienzo
     */
    
    private void handleAddStore() {
        String posStr = JOptionPane.showInputDialog(this, "Ubicación de la tienda (0-" + (POSITIONS - 1) + "):");
        if (posStr == null) return;
        String tengesStr = JOptionPane.showInputDialog(this, "Tenges iniciales (entero):");
        if (tengesStr == null) return;

        try {
            int pos = Integer.parseInt(posStr.trim());
            int tenges = Integer.parseInt(tengesStr.trim());
            if (pos < 0 || pos >= POSITIONS || tenges < 0) throw new NumberFormatException();

            for (Store s : silkRoad.stores()) {
                if (s.getLocation() == pos) {
                    showMessageIfVisible("Ya existe una tienda en la posición " + pos);
                    return;
                }
            }

            silkRoad.placeStore(pos, tenges);
            Store added = lastAddedStoreAt(pos);
            if (added != null) storeColors.put(added, randomBrightColor());

            log("Tienda añadida en " + pos + " con " + tenges + " tenges.");
            updateProfitBar();
            canvas.repaint();
        } catch (NumberFormatException ex) {
            showMessageIfVisible("Entrada inválida: ingresa enteros válidos.");
        }
    }

    /**
     * Busca la tienda más recientemente añadida en una posición específica.
     * 
     * pos posición de la tienda en el mapa.
     */
    
    private Store lastAddedStoreAt(int pos) {
        for (Store s : silkRoad.stores()) if (s.getLocation() == pos) return s;
        return null;
    }

    /**
     * acción del botón "Agregar Robot".
     * 
     * Solicita al usuario la posición donde desea colocar un nuevo robot.
     * Verifica que el valor ingresado sea un número válido y que no exista ya
     * un robot en esa posición. Si es correcto, invoca 
     *  para crearlo, asigna un color y actualiza
     * la interfaz gráfica
     */
    
    private void handleAddRobot() {
        String posStr = JOptionPane.showInputDialog(this, "Ubicación del robot (0-" + (POSITIONS - 1) + "):");
        if (posStr == null) return;
        try {
            int pos = Integer.parseInt(posStr.trim());
            if (pos < 0 || pos >= POSITIONS) throw new NumberFormatException();

            for (Robot r : silkRoad.robots()) {
                if (r.getLocation() == pos) {
                    showMessageIfVisible("Ya existe un robot en la posición " + pos);
                    return;
                }
            }

            silkRoad.placeRobot(pos);
            Robot added = lastAddedRobotAt(pos);
            if (added != null) robotColors.put(added, randomBrightColor());

            log("Robot añadido en " + pos);
            updateProfitBar();
            canvas.repaint();
        } catch (NumberFormatException ex) {
            showMessageIfVisible("Entrada inválida: ingresa un entero válido para posición.");
        }
    }

    /**
     * Busca el robot más recientemente añadido en una posición específica.
     * 
     */
    
    private Robot lastAddedRobotAt(int pos) {
        for (Robot r : silkRoad.robots()) if (r.getLocation() == pos) return r;
        return null;
    }

    /**
     * Maneja la acción del botón "Reabastecer Tiendas".
     * 
     */
    
    private void handleResupply() {
        silkRoad.resupplyStores();
        log("Tiendas reabastecidas.");
        updateProfitBar();
        canvas.repaint();
    }

    /**
     * Maneja la acción del botón "Regresar Robots".
     * 
     * <p>Devuelve todos los robots a su posición original mediante  y actualiza la interfaz
     */
    
    private void handleReturnRobots() {
        silkRoad.returnRobots();
        log("Robots regresaron a posiciones iniciales.");
        canvas.repaint();
    }

    /**
     * Maneja la acción del botón "Reiniciar".
     * 
     * Limpia completamente el estado del simulador: elimina todas las tiendas,
     * robots, colores asignados y estados de parpadeo. También actualiza el
     * registro, la barra de progreso y el lienzo.
     */
    
    private void handleReboot() {
        silkRoad.reboot();
        storeColors.clear();
        robotColors.clear();
        robotBlinkState.clear();
        log("Sistema reiniciado.");
        updateProfitBar();
        canvas.repaint();
    }

    /**
     * Alterna la visibilidad del modelo.
     * 
     * Permite ocultar o mostrar los elementos visuales de la simulación.
     * También cambia el texto del botón entre "Invisible" y "Visible"
     * para reflejar el estado actual.
     */
    
    private void toggleVisible() {
        
        if (btnToggleVisible.getText().equals("Invisible")) {
            silkRoad.makeInvisible();
            btnToggleVisible.setText("Visible");
            log("Simulador puesto en modo invisible.");
        } else {
            silkRoad.makeVisible();
            btnToggleVisible.setText("Invisible");
            log("Simulador visible.");
        }
    }
    
    /**
     * Inicia la simulación de la Ruta de la Seda.
     *
     * Verifica que haya al menos una tienda y un robot antes de comenzar. 
     * Si no se cumplen las condiciones, muestra un mensaje al usuario
     *
     */
    
    private void startSimulation() {
        if (simulating) return;
        if (silkRoad.stores().size() == 0 || silkRoad.robots().size() == 0) {
            showMessageIfVisible("Necesitas al menos 1 tienda y 1 robot para simular.");
            return;
        }
        simulating = true;
        log("\n--- Simulación iniciada ---");

        simulationTimer = new Timer(TIMER_DELAY, e -> {
            blinkOn = !blinkOn; 
            stepSimulation();
        });
        simulationTimer.start();
    }

    /**
     * Detiene la simulación actual de la Ruta de la Seda.
     *
     * Si la simulación está en curso, este método detiene el temporizador,
     * cancela el parpadeo de los robots mediante,
     * y actualiza la interfaz gráfica para reflejar el estado detenido.
     *
     * Si no hay una simulación en ejecución, no realiza ninguna acción.
     */
    
    private void stopSimulation() {
        if (!simulating) return;
        simulating = false;
        if (simulationTimer != null) {
            simulationTimer.stop();
            simulationTimer = null;
        }
        
        for (Robot r : silkRoad.robots()) r.stopBlink();
        log("--- Simulación detenida ---\n");
        canvas.repaint();
    }

    /**
     * Realiza un paso de simulación de la Ruta de la Seda.
     *
     * Durante cada paso
     * 
     *   Cada robot busca la tienda más cercana que aún tenga tenges disponibles
     *   Si encuentra una, avanza un paso hacia ella
     *   Si llega a su ubicación, recoge todos los tenges disponibles
     *       los suma a sus ganancias y vacía la tienda
     *
     * Al final, actualiza el parpadeo del robot líder (el que más ha ganado),
     * la barra de progreso de ganancias totales y repinta el lienzo
     */
    
    private void stepSimulation() {
        ArrayList<Store> stores = silkRoad.stores();
        ArrayList<Robot> robots = silkRoad.robots();

        
        boolean anyStoreHas = false;
        for (Store s : stores) if (s.getTenges() > 0) { anyStoreHas = true; break; }
        if (!anyStoreHas) {
            log("No quedan tenges en tiendas. Simulación finalizada.");
            stopSimulation();
            return;
        }

        
        for (Robot r : robots) {
            int rpos = r.getLocation();
            Store nearest = null;
            int bestDist = Integer.MAX_VALUE;
            for (Store s : stores) {
                if (s.getTenges() <= 0) continue;
                int dist = Math.abs(s.getLocation() - rpos);
                if (dist < bestDist) { bestDist = dist; nearest = s; }
            }
            if (nearest == null) continue; 

            int target = nearest.getLocation();
            int dir = Integer.compare(target, rpos); 
            if (dir != 0) {
                silkRoad.moveRobot(rpos, dir); 
                log("Robot se mueve desde " + rpos + " a " + (rpos + dir));
            }

            if (r.getLocation() == target && nearest.getTenges() > 0) {
                int gained = nearest.getTenges();
                nearest.withdraw(gained);          
                r.addProfit(gained);              
                log("Robot en " + target + " recogió " + gained + " tenges.");
            }
        }

        
        updateLeaderBlinking();
        updateProfitBar();
        canvas.repaint();
    }

    /**
     * Actualiza el parpadeo del robot líder de la simulación.
     *
     * Determina qué robot tiene la mayor cantidad de ganancias acumuladas
     * y activa su parpadeo visual (indicando que es el líder actual).
     * Todos los demás robots detienen su parpadeo.
     *
     */
    
    private void updateLeaderBlinking() {
        Robot leader = null;
        int max = Integer.MIN_VALUE;
        for (Robot r : silkRoad.robots()) {
            if (r.getProfit() > max) {
                max = r.getProfit();
                leader = r;
            }
        }
        
        for (Robot r : silkRoad.robots()) {
            if (r != leader) {
                r.stopBlink(); 
                robotBlinkState.put(r, false); 
            }
        }
        if (leader != null && max > 0) {
            leader.blink(); 
            robotBlinkState.put(leader, true);
        }
    }

    /**
     * Actualiza la barra de progreso que representa el porcentaje de ganancia total.
     *
     * Calcula la proporción entre las utilidades acumuladas por los robots
     * y el total de tenges iniciales disponibles en las tiendas. Este valor
     * se muestra en la barra de progreso como un porcentaje del 0 al 100.</p>
     *
     * <p>Si no existen tiendas o el valor máximo posible es cero, la barra
     * se reinicia a 0.
     */
    
    
    private void updateProfitBar() {
        int totalProfit = silkRoad.profit();
        int maxPossible = 0;
        for (Store s : silkRoad.stores()) maxPossible += s.getInitialTenges();
        if (maxPossible <= 0) {
            profitBar.setValue(0);
            profitBar.setMaximum(100);
            return;
        }
        int percent = (int) ((totalProfit * 100L) / maxPossible);
        percent = Math.min(100, Math.max(0, percent));
        profitBar.setValue(percent);
    }

    /**
     * Genera un color aleatorio 
     */
    
    private Color randomBrightColor() {
        float hue = rnd.nextFloat();
        float sat = 0.6f + rnd.nextFloat() * 0.4f;
        float br = 0.6f + rnd.nextFloat() * 0.4f;
        return Color.getHSBColor(hue, sat, br);
    }

    /**
     * Muestra un mensaje en pantalla solo si el modelo está en modo visible.
     *
     * Este método verifica el estado de visibilidad de la simulación basándose
     * en el texto del botón  Si el botón muestra
     * "Invisible", se asume que la interfaz es visible y se muestra el mensaje
     * al usuario mediante un cuadro de diálogo. 
     * 
     */
    
    private void showMessageIfVisible(String message) {
        if (btnToggleVisible.getText().equals("Invisible")) {
            JOptionPane.showMessageDialog(this, message);
        } else {
            log("[Mensaje oculto por modo invisible]: " + message);
        }
    }

    private void log(String s) {
        logArea.append(s + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    /**
     * CanvasPanel es un JPanel personalizado que dibuja:
     * - Una ruta con posiciones 
     * - Tiendas con indicadores de dinero
     * - Robots en la ruta, mostrando su posición y beneficio
     * 
     */
    
    private class CanvasPanel extends JPanel {
    private final int PADDING = 60;

    /**
     * Método que pinta el contenido del JPanel.
     * Se llama automáticamente cuando el panel necesita actualizarse.
     *
     */
    @Override
    
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        g.setColor(new Color(245, 245, 250));
        g.fillRect(0, 0, w, h);

        Point[] route = computeRoutePositions(POSITIONS, w, h);

        g.setColor(new Color(205, 133, 63)); 
        g.setStroke(new BasicStroke(18f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        for (int i = 0; i < route.length - 1; i++) {
            Point a = route[i], b = route[i + 1];
            g.drawLine(a.x, a.y, b.x, b.y);
        }

        g.setStroke(new BasicStroke(1f));
        g.setFont(new Font("SansSerif", Font.PLAIN, 12));
        for (int i = 0; i < route.length; i++) {
            g.setColor(Color.DARK_GRAY);
            g.fillOval(route[i].x - 4, route[i].y - 4, 8, 8);
            String lbl = Integer.toString(i);
            int strw = g.getFontMetrics().stringWidth(lbl);
            g.drawString(lbl, route[i].x - strw / 2, route[i].y + 20);
        }

        for (Store s : silkRoad.stores()) {
            int pos = s.getLocation();
            if (pos < 0 || pos >= route.length) continue;
            Point p = route[pos];
            Color c = storeColors.getOrDefault(s, new Color(34, 139, 34)); 
            if (s.getTenges() <= 0) c = Color.RED; 

            g.setColor(c);
            int wRect = 36, hRect = 28;
            g.fillRect(p.x - wRect / 2, p.y - 60, wRect, hRect);
            g.setColor(Color.WHITE);
            g.drawString("$", p.x - 5, p.y - 42);
        }

        for (Robot r : silkRoad.robots()) {
            int pos = r.getLocation();
            if (pos < 0 || pos >= route.length) continue;
            Point p = route[pos];
            Color c = robotColors.getOrDefault(r, new Color(70, 130, 255));

            boolean isLeaderBlink = robotBlinkState.getOrDefault(r, false);
            if (isLeaderBlink && !blinkOn) {
                g.setColor(c.darker().darker());
                g.fillOval(p.x - 12, p.y + 12, 24, 24);
            } else {
                g.setColor(c);
                g.fillOval(p.x - 12, p.y + 12, 24, 24);
                g.setColor(Color.BLACK);
                g.drawOval(p.x - 12, p.y + 12, 24, 24);
            }

            int profit = r.getProfit();
            if (profit > 0) {
                g.setColor(Color.BLACK);
                String pft = String.valueOf(profit);
                g.drawString(pft, p.x - g.getFontMetrics().stringWidth(pft) / 2, p.y + 10);
            }
        }
    }

    /**
     * Genera las coordenadas de las posiciones de la ruta.
     * 
     * - Si hay 10 posiciones o menos: coloca los puntos en línea recta horizontal.
     * - Si hay más de 10 posiciones: genera una espiral cuadrada centrada en el panel.
     */
    private Point[] computeRoutePositions(int count, int w, int h) {
        Point[] pts = new Point[count];
        if (count <= 10) {
            int left = PADDING;
            int right = w - PADDING;
            int y = h / 2;
            for (int i = 0; i < count; i++) {
                int x = left + (i * (right - left)) / (count - 1);
                pts[i] = new Point(x, y);
            }
        } else {
            int cx = w / 2;
            int cy = h / 2;
            int step = 60; 
            int dir = 0;   
            int len = 1;
            int idx = 0;
            int x = cx, y = cy;
            pts[idx++] = new Point(x, y);

            while (idx < count) {
                for (int r = 0; r < 2; r++) {
                    for (int i = 0; i < len && idx < count; i++) {
                        switch (dir) {
                            case 0 -> x += step;
                            case 1 -> y += step;
                            case 2 -> x -= step;
                            case 3 -> y -= step;
                        }
                        pts[idx++] = new Point(x, y);
                    }
                    dir = (dir + 1) % 4;
                }
                len++;
            }
        }
        return pts;
    }
}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SilkRoadGUI());
    }
}
