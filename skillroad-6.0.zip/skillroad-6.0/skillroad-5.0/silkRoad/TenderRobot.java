package silkRoad;

public class TenderRobot extends Robot {

    public TenderRobot(int location, String color) {
        super(location, color);
    }

    /**
     * Toma solo la mitad del dinero disponible en la tienda.
     */
    public void collectFrom(Store store) {
        int available = store.getTenges();
        int half = available / 2;
        store.setTenges(available - half);
        addProfit(half);
    }
}
