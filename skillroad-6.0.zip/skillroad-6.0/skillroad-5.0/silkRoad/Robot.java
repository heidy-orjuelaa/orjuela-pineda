package silkRoad;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.Color;
import shapes.*;

/**
 * Clase Robot que representa un personaje dentro del juego SilkRoad.
 * Cada robot tiene una ubicación, una ganancia acumulada y puede mostrarse, ocultarse o parpadear.
 * 
 * Esta clase utiliza un objeto de tipo Circle para representar visualmente al robot.
 * 
 * @author (Orjuela - Pineda)
 * @version 2025
 */

public class Robot {
    private int initialLocation;
    private int currentLocation;
    private int profit;
    private Circle shape;
    private boolean visible;
    private boolean blinking;
    private Timer blinkTimer;

    public Robot(int location) {
        this(location, "blue");
    }

    public Robot(int location, String color) {
        this.initialLocation = location;
        this.currentLocation = location;
        this.profit = 0;
        this.visible = false;
        this.blinking = false;
        this.shape = new Circle();
        this.shape.changeColor(color);
        this.shape.moveHorizontal(location);
    }

    /**
     * Mueve el robot cierta cantidad de metros en el eje horizontal.
     * 
     * @param meters distancia a mover.
     */
    
    public void move(int meters) {
        currentLocation += meters;
        shape.moveHorizontal(meters);
    }

    /**
     * Restaura al robot a su posición inicial.
     */
    
    public void resetPosition() {
        int delta = initialLocation - currentLocation;
        currentLocation = initialLocation;
        shape.moveHorizontal(delta);
    }

    /**
     * Suma una cantidad de ganancia al robot.
     * 
     * @param amount cantidad de dinero a agregar al total de ganancias.
     */
    
    public void addProfit(int amount) {
        profit += amount;
    }

    /**
     * Devuelve la ganancia total acumulada.
     * 
     * @return ganancia del robot.
     */
    
    public int getProfit() {
        return profit;
    }

    /**
     * Devuelve la ubicación actual del robot.
     * 
     * @return posición actual en el eje horizontal.
     */
    
    public int getLocation() {
        return currentLocation;
    }

    /**
     * Muestra al robot en la pantalla.
     */
    public void show() {
        visible = true;
        shape.makeVisible();
    }

    /**
     * Oculta al robot de la pantalla.
     */
    public void hide() {
        visible = false;
        shape.makeInvisible();
    }

    /**
     * Hace parpadear el robot, alternando visibilidad cada 400 milisegundos.
     * Si ya está parpadeando, no se inicia otro temporizador.
     */
    public void blink() {
        if (blinking) return; 
        blinking = true;

        blinkTimer = new Timer();
        blinkTimer.scheduleAtFixedRate(new TimerTask() {
            private boolean visibleState = true;
            @Override
            public void run() {
                if (!blinking) {
                    cancel();
                    return;
                }
                if (visibleState) {
                    shape.makeInvisible();
                } else {
                    shape.makeVisible();
                }
                visibleState = !visibleState;
            }
        }, 0, 400);
    }

    /**
     * Detiene el parpadeo y vuelve visible el robot.
     */
    public void stopBlink() {
        blinking = false;
        if (blinkTimer != null) {
            blinkTimer.cancel();
            blinkTimer = null;
        }
        shape.makeVisible();
    }

    /**
     * Indica si el robot se encuentra parpadeando.
     * 
     * @return true si el robot está parpadeando; false en caso contrario.
     */
    public boolean isBlinking() {
        return this.blinking;
    }
}
