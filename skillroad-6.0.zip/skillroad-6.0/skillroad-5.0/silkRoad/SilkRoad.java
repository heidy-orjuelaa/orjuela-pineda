package silkRoad;
import java.util.List;
import java.awt.Color;
import java.util.ArrayList;


/**
 * Clase principal que modela el simulador de la Ruta de la Seda.
 * 
 * Esta clase gestiona las tiendas y los robots que interactúan en el recorrido.
 * Permite crear, eliminar y mover robots y tiendas, así como mostrar el estado
 * gráfico del juego (visible o invisible).
 * 
 * @author (Orjuela - Pineda)
 * @version 3.0
*/

public class SilkRoad {

    private int length;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private boolean visible;

    public SilkRoad(int length) {
        this.length = length;
        stores = new ArrayList<>();
        robots = new ArrayList<>();
        visible = false;
    }
    
    public SilkRoad(int[][] days) {
        this(days.length);
    }

    /**
     * Crea una tienda en una ubicación específica con una cantidad inicial de tenges.
     * 
     * @param location ubicación horizontal de la tienda
     * @param tenges cantidad inicial de dinero en la tienda
     */
    
    public void placeStore(int location, int tenges) {
        if (location < 0 || location >= length) return;

        Store nueva = new Store(location, tenges);
        stores.add(nueva);
        

        if (visible) nueva.show();
    }

    /**
     * Elimina una tienda de una ubicación específica, si existe.
     * 
     * @param location ubicación de la tienda a eliminar
     */
    
    public void removeStore(int location) {
        stores.removeIf(store -> {
            boolean coincide = store.getLocation() == location;
            if (coincide) store.hide();
            return coincide;
        });
    }

    /**
     * Coloca un nuevo robot en la ubicación indicada, si no hay otro en la misma posición.
     * 
     * @param location ubicación inicial del robot
     */
    
    public void placeRobot(int location) {
        if (location < 0 || location >= length) return;

        
        for (Robot r : robots) {
            if (r.getLocation() == location) return;
        }

        Robot nuevo = new Robot(location, "blue");
        robots.add(nuevo);

        if (visible) nuevo.show();
    }

    /**
     * Elimina un robot ubicado en una posición específica.
     * 
     * @param location ubicación del robot a eliminar
     */
    
    public void removeRobot(int location) {
        robots.removeIf(robot -> {
            boolean coincide = robot.getLocation() == location;
            if (coincide) robot.hide();
            return coincide;
        });
    }

    /**
     * Mueve un robot desde su ubicación actual una cantidad determinada de metros.
     * 
     * @param location ubicación inicial del robot
     * @param meters cantidad de metros que debe moverse
     */
    
    public void moveRobot(int location, int meters) {
        for (Robot r : robots) {
            if (r.getLocation() == location) {
                int nuevaUbicacion = r.getLocation() + meters;
                if (nuevaUbicacion < 0) nuevaUbicacion = 0;
                if (nuevaUbicacion >= length) nuevaUbicacion = length - 1;
                r.move(nuevaUbicacion - r.getLocation());
                break;
            }
        }
    }

    /**
     * Mueve todos los robots según las reglas definidas del juego (pendiente de implementar).
     */
    
    public void moveRobots() {
        
    }


    /**
     * Devuelve la lista de robots en la simulación.
     * 
     * @return lista de robots
     */
    
    public ArrayList<Robot> robots() {
        return robots;
    }

    /**
     * Devuelve la lista de tiendas en la simulación.
     * 
     * @return lista de tiendas
     */
    
    public ArrayList<Store> stores() {
        return stores;
    }

    /**
     * Devuelve todos los robots a su posición inicial.
     */
    
    public void returnRobots() {
        for (Robot robot : robots) {
            robot.resetPosition();
        }
    }

    /**
     * Reabastece todas las tiendas a su cantidad inicial de tenges.
     */
    
    public void resupplyStores() {
        for (Store store : stores) {
            store.resupply();
        }
    }

    /**
     * Reinicia completamente la simulación, eliminando todas las tiendas y robots.
     */
    
    public void reboot() {
        for (Store s : stores) s.hide();
        for (Robot r : robots) r.hide();
        stores.clear();
        robots.clear();
    }

    /**
     * Calcula la ganancia total acumulada por todos los robots.
     * 
     * @return ganancia total
     */
    
    public int profit() {
        int total = 0;
        for (Robot robot : robots) {
            total += robot.getProfit();
        }
        return total;
    }

    /**
     * Hace visible el escenario, mostrando todas las tiendas y robots.
     */
    
    public void makeVisible() {
        visible = true;
        for (Store store : stores) store.show();
        for (Robot robot : robots) robot.show();
    }

    /**
     * Oculta todo el escenario, haciendo invisibles tiendas y robots.
     */
    
    public void makeInvisible() {
        visible = false;
        for (Store store : stores) store.hide();
        for (Robot robot : robots) robot.hide();
    }
    
    /**
     * Finaliza la simulación, limpiando los datos y ocultando todo.
     */
    
    public void finish() {
        reboot();
        visible = false;
    }

    /**
     * Verifica el estado del sistema.
     * 
     * @return siempre devuelve true si el simulador está operativo
     */
    
    public boolean ok() {
        return false;
    }
}
