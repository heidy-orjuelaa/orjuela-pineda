package silkRoad;

import java.util.Random;
import shapes.Rectangle;

/**
 * Tienda autónoma que decide su propia ubicación dentro del rango del mapa.
 * Ignora la posición que se le indica al ser creada.
 * 
 * @author (Orjuela - Pineda)
 * @version 3.1
 */
public class AutonomousStore extends Store {

    private static final int MAX_LENGTH = 100; // Ajusta según el tamaño del SilkRoad si es necesario
    private Random rand = new Random();

    public AutonomousStore(int location, int tenges) {
        // Ignora la ubicación dada y elige una aleatoria
        super(randLocation(), tenges);
    }

    private static int randLocation() {
        Random random = new Random();
        return random.nextInt(MAX_LENGTH); // número aleatorio entre 0 y MAX_LENGTH-1
    }

    @Override
    public String toString() {
        return "AutonomousStore{" +
                "location=" + getLocation() +
                ", tenges=" + getTenges() +
                '}';
    }
}
