package silkRoad;

public class NeverBackRobot extends Robot {

    public NeverBackRobot(int location, String color) {
        super(location, color);
    }

    @Override
    public void move(int meters) {
        if (meters < 0) {
            // No retrocede
            return;
        }
        super.move(meters);
    }
}
