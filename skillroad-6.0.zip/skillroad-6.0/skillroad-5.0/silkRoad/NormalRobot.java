package silkRoad;

public class NormalRobot extends Robot {

    public NormalRobot(int location, String color) {
        super(location, color);
    }

    // Usa comportamiento base
}
