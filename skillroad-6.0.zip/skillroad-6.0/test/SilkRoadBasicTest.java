package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import silkRoad.SilkRoad;

public class SilkRoadBasicTest {

    @Test
    public void testCreateSilkRoadAndPlaceStore() throws Exception {
        // Crear una ruta con longitud 10
        SilkRoad sr = new SilkRoad(10);

        // Agregar una tienda en la posición 3
        sr.placeStore(3, 100);

        // Verificar que la tienda se agregó correctamente
        assertEquals(1, sr.stores().size(), "Debe haber exactamente una tienda registrada.");
        assertEquals(3, sr.stores().get(0).getLocation(), "La tienda debe estar en la posición 3.");
    }

    @Test
    public void testPlaceRobotAndMoveIt() throws Exception {
        SilkRoad sr = new SilkRoad(10);

        // Crear un robot en la posición 2
        sr.placeRobot(2);

        // Moverlo 3 posiciones adelante
        sr.moveRobot(2, 3);

        // Verificar su nueva ubicación
        assertEquals(5, sr.robots().get(0).getLocation(), "El robot debe haberse movido correctamente a la posición 5.");
    }
}
