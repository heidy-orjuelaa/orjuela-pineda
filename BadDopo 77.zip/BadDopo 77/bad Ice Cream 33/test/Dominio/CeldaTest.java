package Dominio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CeldaTest {

    @Test
    void celdaInicialmenteNoEsBloqueante() {
        Celda celda = new Celda();

        assertFalse(celda.esBloqueante());
    }

    @Test
    void agregarYRemoverEntidadFuncionaCorrectamente() {
        Celda celda = new Celda();
        Entidad entidad = new Suelo(); 

        celda.agregarEntidad(entidad);
        assertEquals(1, celda.getEntidades().size());

        celda.removerEntidad(entidad);
        assertTrue(celda.getEntidades().isEmpty());
    }

    @Test
    void contieneDetectaEntidadPorClase() {
        Celda celda = new Celda();
        Entidad hielo = new BloqueHielo(new Posicion(0, 0));

        celda.agregarEntidad(hielo);

        assertTrue(celda.contiene(BloqueHielo.class));
        assertFalse(celda.contiene(Fruta.class));
    }

    @Test
    void getBloqueHieloRetornaHieloCuandoExiste() {
        Celda celda = new Celda();
        BloqueHielo hielo = new BloqueHielo(new Posicion(1, 1));

        celda.agregarEntidad(hielo);

        assertEquals(hielo, celda.getBloqueHielo());
    }

    @Test
    void getBloqueHieloRetornaNullCuandoNoExiste() {
        Celda celda = new Celda();

        assertNull(celda.getBloqueHielo());
    }

    @Test
    void getFrutasRetornaListaCorrecta() {
        Celda celda = new Celda();
        Fruta f1 = new Cereza(new Posicion(0, 0));
        Fruta f2 = new Cereza(new Posicion(1, 1));

        celda.agregarEntidad(f1);
        celda.agregarEntidad(f2);

        assertEquals(2, celda.getFrutas().size());
    }
}
