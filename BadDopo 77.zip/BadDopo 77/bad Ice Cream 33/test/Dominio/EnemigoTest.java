package Dominio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.List;

public class EnemigoTest {


    private static class EnemigoDummy extends Enemigo {

        public EnemigoDummy(Posicion posicion, IAEnemigo ia) {
            super(posicion, ia);
        }

        @Override
        public String getTipo() {
            return "EnemigoDummy";
        }
    }

    private static class IAEnemigoDummy implements IAEnemigo {

        private final Direccion direccion;

        public IAEnemigoDummy(Direccion direccion) {
            this.direccion = direccion;
        }

        @Override
        public Direccion calcularDireccion(Enemigo enemigo, Mapa mapa, List<Jugador> jugadores) {
            return direccion;
        }
    }

    @Test
    void enemigoSiempreEsBloqueante() {
        Enemigo enemigo = new EnemigoDummy(
                new Posicion(1, 1),
                null
        );

        assertTrue(enemigo.esBloqueante());
    }

    @Test
    void activarMataAlJugador() {
        Jugador jugador = new Jugador("J1", Jugador.TipoJugador.HUMANO);

        Enemigo enemigo = new EnemigoDummy(
                new Posicion(1, 1),
                null
        );

        enemigo.activar(jugador);

        assertTrue(jugador.estaMuerto());
    }

    @Test
    void actualizarConIANullNoLanzaExcepcion() {
        Mapa mapa = new Mapa(5, 5);

        Enemigo enemigo = new EnemigoDummy(
                new Posicion(2, 2),
                null
        );

        mapa.agregarEntidad(enemigo, enemigo.getPosicion());

        assertDoesNotThrow(() -> enemigo.actualizar(mapa));
    }

    @Test
    void actualizarConIAQueDevuelveNullNoMueve() {
        Mapa mapa = new Mapa(5, 5);

        IAEnemigo ia = new IAEnemigoDummy(null);

        Enemigo enemigo = new EnemigoDummy(
                new Posicion(2, 2),
                ia
        );

        mapa.agregarEntidad(enemigo, enemigo.getPosicion());

        Posicion inicial = enemigo.getPosicion();

        enemigo.actualizar(mapa, List.of());

        assertEquals(inicial, enemigo.getPosicion());
    }

    @Test
    void actualizarConIAQueDevuelveDireccionNoRompe() {
        Mapa mapa = new Mapa(5, 5);

        IAEnemigo ia = new IAEnemigoDummy(Direccion.ESTE);

        Enemigo enemigo = new EnemigoDummy(
                new Posicion(2, 2),
                ia
        );

        mapa.agregarEntidad(enemigo, enemigo.getPosicion());

        assertDoesNotThrow(() -> enemigo.actualizar(mapa, List.of()));
    }
}
