package Dominio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

public class CactusTest {

    @Test
    void cactusInicialmenteNoEsBloqueante() {
        Cactus cactus = new Cactus(new Posicion(1, 1));

        assertFalse(cactus.esBloqueante());
    }

    @Test
    void cactusInicialmenteEsTipoCactus() {
        Cactus cactus = new Cactus(new Posicion(0, 0));

        assertEquals("Cactus", cactus.getTipo());
    }

    @Test
    void activarEnEstadoNormalNoMataJugador() {
        Cactus cactus = new Cactus(new Posicion(1, 1));
        Jugador jugador = new Jugador("J1", Jugador.TipoJugador.HUMANO);

        cactus.activar(jugador);

        assertFalse(jugador.estaMuerto());
    }

    @Test
    void recolectarEnEstadoNormalSumaPuntos() {
        Cactus cactus = new Cactus(new Posicion(2, 2));
        Jugador jugador = new Jugador("J1", Jugador.TipoJugador.HUMANO);

        int puntosAntes = jugador.getPuntajeTotal();

        cactus.recolectar(jugador);

        assertEquals(puntosAntes + 250, jugador.getPuntajeTotal());
    }

    @Test
    void activarEnEstadoPeligrosoMataJugador() throws Exception {
        Cactus cactus = new Cactus(new Posicion(3, 3));
        Jugador jugador = new Jugador("J1", Jugador.TipoJugador.HUMANO);

        forzarEstadoPeligroso(cactus);

        cactus.activar(jugador);

        assertTrue(jugador.estaMuerto());
    }

    @Test
    void cactusPeligrosoEsBloqueante() throws Exception {
        Cactus cactus = new Cactus(new Posicion(4, 4));

        forzarEstadoPeligroso(cactus);

        assertTrue(cactus.esBloqueante());
        assertEquals("CactusPeligroso", cactus.getTipo());
    }

    private void forzarEstadoPeligroso(Cactus cactus) throws Exception {
        Field estadoField = Cactus.class.getDeclaredField("estado");
        estadoField.setAccessible(true);

        Object estadoPeligroso = estadoField.getType().getEnumConstants()[1];
        estadoField.set(cactus, estadoPeligroso);
    }
}
