package Dominio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.List;

public class JuegoTest {

    private Jugador crearJugadorHumano() {
        return new Jugador("J1", Jugador.TipoJugador.HUMANO);
    }

    @Test
    void juegoIniciaNoTerminado() {
        Juego juego = new Juego(List.of(crearJugadorHumano()));

        assertFalse(juego.estaTerminado());
        assertFalse(juego.hayVictoria());
    }

    @Test
    void tiempoInicialEsCorrecto() {
        Juego juego = new Juego(List.of(crearJugadorHumano()));

        assertEquals(180, juego.getTiempoRestante());
    }

    @Test
    void disminuirTiempoReduceCorrectamente() {
        Juego juego = new Juego(List.of(crearJugadorHumano()));

        juego.disminuirTiempo(10);

        assertEquals(170, juego.getTiempoRestante());
    }

    @Test
    void juegoTerminaCuandoTiempoLlegaACero() {
        Juego juego = new Juego(List.of(crearJugadorHumano()));

        juego.disminuirTiempo(180);

        assertTrue(juego.estaTerminado());
        assertFalse(juego.hayVictoria());
    }

    
    }

  