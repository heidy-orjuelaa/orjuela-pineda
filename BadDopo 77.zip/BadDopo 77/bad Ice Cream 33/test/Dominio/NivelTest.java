package Dominio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class NivelTest {

    @Test
    void constructorAsignaNumeroCorrecto() {
        Nivel nivel = new Nivel(3);

        assertEquals(3, nivel.getNumero());
    }

    @Test
    void tiempoMaximoPorDefectoEs180() {
        Nivel nivel = new Nivel(1);

        assertEquals(180, nivel.getTiempoMaximo());
    }

    @Test
    void sePuedeCambiarTiempoMaximo() {
        Nivel nivel = new Nivel(2);

        nivel.setTiempoMaximo(300);

        assertEquals(300, nivel.getTiempoMaximo());
    }

    @Test
    void agregarFrutaNoLanzaExcepcion() {
        Nivel nivel = new Nivel(1);

        assertDoesNotThrow(() ->
                nivel.agregarFruta(Cactus.class, 5)
        );
    }

    @Test
    void agregarEnemigoNoLanzaExcepcion() {
        Nivel nivel = new Nivel(1);

        assertDoesNotThrow(() ->
                nivel.agregarEnemigo(Enemigo.class, 3)
        );
    }

    @Test
    void agregarObstaculoNoLanzaExcepcion() {
        Nivel nivel = new Nivel(1);

        assertDoesNotThrow(() ->
                nivel.agregarObstaculo(Pared.class, 10)
        );
    }

    @Test
    void generarMapaDevuelveMapaValido() {
        Nivel nivel = new Nivel(1);

        nivel.agregarFruta(Cactus.class, 2);
        nivel.agregarEnemigo(Enemigo.class, 1);
        nivel.agregarObstaculo(Pared.class, 5);

        Mapa mapa = nivel.generarMapa(10, 8);

        assertNotNull(mapa);
        assertEquals(10, mapa.getAncho());
        assertEquals(8, mapa.getAlto());
    }

    @Test
    void generarMapaSinConfiguracionNoFalla() {
        Nivel nivel = new Nivel(5);

        assertDoesNotThrow(() -> {
            Mapa mapa = nivel.generarMapa(6, 6);
            assertNotNull(mapa);
        });
    }
}
