package Dominio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class HeladoTest {

    // IA falsa para testing
    private static class IAFake implements IAHelado {
        private final Direccion direccion;

        public IAFake(Direccion direccion) {
            this.direccion = direccion;
        }

        @Override
        public Direccion calcularMovimiento(Helado helado, Mapa mapa) {
            return direccion;
        }
    }

    private Jugador crearJugador() {
        return new Jugador("J1", Jugador.TipoJugador.HUMANO);
    }

    @Test
    void heladoSeCreaCorrectamente() {
        Helado helado = new Helado(
                new Posicion(1, 1),
                null,
                crearJugador(),
                "Chocolate"
        );

        assertNotNull(helado);
    }

    @Test
    void heladoGuardaSaborCorrectamente() {
        Helado helado = new Helado(
                new Posicion(1, 1),
                null,
                crearJugador(),
                "Fresa"
        );

        assertEquals("Fresa", helado.getSabor());
    }

    @Test
    void heladoTieneDuenoCorrecto() {
        Jugador jugador = crearJugador();

        Helado helado = new Helado(
                new Posicion(2, 2),
                null,
                jugador,
                "Vainilla"
        );

        assertEquals(jugador, helado.getDueño());
    }

    @Test
    void heladoSinIARetornaMovimientoNull() {
        Helado helado = new Helado(
                new Posicion(1, 1),
                null,
                crearJugador(),
                "Chocolate"
        );

        assertNull(helado.calcularMovimientoIA(null));
    }

    @Test
    void heladoConIADevuelveDireccion() {
        IAHelado ia = new IAFake(Direccion.SUR);

        Helado helado = new Helado(
                new Posicion(1, 1),
                ia,
                crearJugador(),
                "Chocolate"
        );

        assertEquals(Direccion.SUR, helado.calcularMovimientoIA(null));
    }

    @Test
    void direccionInicialEsNorte() {
        Helado helado = new Helado(
                new Posicion(1, 1),
                null,
                crearJugador(),
                "Chocolate"
        );

        assertEquals(Direccion.NORTE, helado.getDireccionActual());
    }

    @Test
    void setDireccionActualFunciona() {
        Helado helado = new Helado(
                new Posicion(1, 1),
                null,
                crearJugador(),
                "Chocolate"
        );

        helado.setDireccionActual(Direccion.ESTE);

        assertEquals(Direccion.ESTE, helado.getDireccionActual());
    }

    @Test
    void heladoNuncaEsBloqueante() {
        Helado helado = new Helado(
                new Posicion(1, 1),
                null,
                crearJugador(),
                "Chocolate"
        );

        assertFalse(helado.esBloqueante());
    }
}
