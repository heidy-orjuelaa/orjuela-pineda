package Dominio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PosicionTest {

    @Test
    void constructorYGettersFuncionan() {
        Posicion p = new Posicion(3, 5);

        assertEquals(3, p.getX());
        assertEquals(5, p.getY());
    }

    @Test
    void desplazarCreaNuevaPosicionCorrecta() {
        Posicion p = new Posicion(2, 2);

        Posicion desplazada = p.desplazar(1, -1);

        assertEquals(3, desplazada.getX());
        assertEquals(1, desplazada.getY());
    }

    @Test
    void desplazarNoModificaOriginal() {
        Posicion original = new Posicion(4, 4);

        Posicion nueva = original.desplazar(-2, 3);

        assertEquals(4, original.getX());
        assertEquals(4, original.getY());
        assertNotSame(original, nueva);
    }

    @Test
    void equalsConMismosValoresEsTrue() {
        Posicion p1 = new Posicion(1, 1);
        Posicion p2 = new Posicion(1, 1);

        assertEquals(p1, p2);
    }

    @Test
    void equalsConValoresDistintosEsFalse() {
        Posicion p1 = new Posicion(1, 2);
        Posicion p2 = new Posicion(2, 1);

        assertNotEquals(p1, p2);
    }

    @Test
    void equalsConNullEsFalse() {
        Posicion p = new Posicion(1, 1);

        assertNotEquals(p, null);
    }

    @Test
    void equalsConOtroTipoEsFalse() {
        Posicion p = new Posicion(1, 1);

        assertNotEquals(p, "texto");
    }

    @Test
    void hashCodeIgualParaObjetosIguales() {
        Posicion p1 = new Posicion(5, 7);
        Posicion p2 = new Posicion(5, 7);

        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    void toStringTieneFormatoCorrecto() {
        Posicion p = new Posicion(2, 9);

        assertEquals("(2, 9)", p.toString());
    }
}
