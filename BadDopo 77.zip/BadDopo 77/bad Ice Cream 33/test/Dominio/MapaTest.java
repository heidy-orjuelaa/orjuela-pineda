package Dominio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MapaTest {

    @Test
    void mapaSeCreaConDimensionesCorrectas() {
        Mapa mapa = new Mapa(10, 8);

        assertEquals(10, mapa.getAncho());
        assertEquals(8, mapa.getAlto());
    }

    @Test
    void posicionDentroDelMapaEsValida() {
        Mapa mapa = new Mapa(5, 5);

        assertTrue(mapa.dentroDelMapa(new Posicion(0, 0)));
        assertTrue(mapa.dentroDelMapa(new Posicion(4, 4)));
    }

    @Test
    void posicionFueraDelMapaNoEsValida() {
        Mapa mapa = new Mapa(5, 5);

        assertFalse(mapa.dentroDelMapa(new Posicion(-1, 0)));
        assertFalse(mapa.dentroDelMapa(new Posicion(0, -1)));
        assertFalse(mapa.dentroDelMapa(new Posicion(5, 0)));
        assertFalse(mapa.dentroDelMapa(new Posicion(0, 5)));
    }

    @Test
    void getCeldaRetornaCeldaValidaDentroDelMapa() {
        Mapa mapa = new Mapa(3, 3);
        Posicion p = new Posicion(1, 1);

        Celda celda = mapa.getCelda(p);

        assertNotNull(celda);
    }

    @Test
    void getCeldaRetornaNullFueraDelMapa() {
        Mapa mapa = new Mapa(3, 3);

        assertNull(mapa.getCelda(new Posicion(10, 10)));
    }


    @Test
    void distanciaManhattanEsCorrecta() {
        Mapa mapa = new Mapa(10, 10);

        int distancia = mapa.distancia(
                new Posicion(1, 1),
                new Posicion(4, 5)
        );

        assertEquals(7, distancia);
    }
}
