package Dominio;

import Dominio.Direccion;
import Dominio.Enemigo;
import Dominio.Mapa;
import Dominio.Pared;
import Dominio.Posicion;
import Dominio.Suelo;
import Dominio.Troll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TrollTest {

    private Mapa mapa;
    private Troll troll;
    private static final int ANCHO = 10;
    private static final int ALTO = 10;
    
    // Método auxiliar para simular la actualización de la IA del Troll
    private Direccion calcularProximaDireccion(Enemigo enemigo, Mapa mapa) {
        // Accede al método actualizar indirectamente a través de la IA
        return enemigo.ia.calcularDireccion(enemigo, mapa, null); 
    }

    /**
     * Configuración inicial: Mapa vacío con bordes de pared.
     */
    @BeforeEach
    void setUp() {
        // Inicializa un mapa de 10x10
        mapa = new Mapa(ANCHO, ALTO); 
        
        // Llena el mapa con suelo y paredes en los bordes
        for (int y = 0; y < ALTO; y++) {
            for (int x = 0; x < ANCHO; x++) {
                Posicion p = new Posicion(x, y);
                mapa.agregarEntidad(new Suelo(), p);
                if (x == 0 || x == ANCHO - 1 || y == 0 || y == ALTO - 1) {
                    mapa.agregarEntidad(new Pared(p), p);
                }
            }
        }
    }

    // --- ESCENARIO 1: Movimiento en Línea Recta (Comportamiento por defecto) ---
    @Test
    void testMoverEnLineaRecta() {
        // Troll en (5, 5), dirección inicial ESTE
        troll = new Troll(new Posicion(5, 5));
        mapa.agregarEntidad(troll, troll.getPosicion());
        
        // Simular 3 ticks de movimiento (5,5) -> (6,5) -> (7,5) -> (8,5)
        
        // Tick 1: Debe moverse a ESTE
        Direccion dir1 = calcularProximaDireccion(troll, mapa);
        assertEquals(Direccion.ESTE, dir1);
        mapa.moverEntidad(troll, dir1);
        assertEquals(new Posicion(6, 5), troll.getPosicion());

        // Tick 2: Debe seguir moviéndose a ESTE
        Direccion dir2 = calcularProximaDireccion(troll, mapa);
        assertEquals(Direccion.ESTE, dir2);
        mapa.moverEntidad(troll, dir2);
        assertEquals(new Posicion(7, 5), troll.getPosicion());
    }

    // --- ESCENARIO 2: Rebote contra el Borde del Mapa ---
    @Test
    void testReboteContraBorde() {
        // Troll cerca del borde derecho, en (8, 5), dirección inicial ESTE
        troll = new Troll(new Posicion(8, 5));
        mapa.agregarEntidad(troll, troll.getPosicion());
        
        // Tick 1: Se mueve a (9, 5). El borde (Pared) está en (9, 5).
        // NOTA: Si el mapa tiene pared en 9,5, el troll debe iniciar el giro en 8,5
        
        // Para que el troll choque en el tick siguiente, lo ponemos en (8, 5).
        
        // Tick 1: Posición actual (8, 5). Intenta ESTE (9, 5).
        // (9, 5) tiene una Pared, que es Bloqueante. 
        Direccion dir1 = calcularProximaDireccion(troll, mapa);
        
        // La IA debe detectar el bloqueo, cambiar a OESTE, y retornar OESTE.
        assertEquals(Direccion.OESTE, dir1, "Debe rebotar de ESTE a OESTE al tocar la pared.");
        
        // Ejecutar el movimiento
        mapa.moverEntidad(troll, dir1);
        assertEquals(new Posicion(7, 5), troll.getPosicion(), "La nueva posición debe ser (7, 5).");
        
        // Tick 2: Ahora se mueve a (6, 5) en dirección OESTE.
        Direccion dir2 = calcularProximaDireccion(troll, mapa);
        assertEquals(Direccion.OESTE, dir2, "Debe seguir en OESTE.");
    }
    
    // --- ESCENARIO 3: Bloqueo Total (Encerrado) ---
    @Test
    void testBloqueoTotal() {
        // Colocar paredes alrededor de (5, 5)
        mapa.agregarEntidad(new Pared(new Posicion(4, 5)), new Posicion(4, 5));
        mapa.agregarEntidad(new Pared(new Posicion(6, 5)), new Posicion(6, 5));
        mapa.agregarEntidad(new Pared(new Posicion(5, 4)), new Posicion(5, 4));
        mapa.agregarEntidad(new Pared(new Posicion(5, 6)), new Posicion(5, 6));

        // Troll en (5, 5), dirección inicial ESTE
        troll = new Troll(new Posicion(5, 5));
        mapa.agregarEntidad(troll, troll.getPosicion());

        // Tick 1: Intenta ESTE (bloqueado). Gira a OESTE. Intenta OESTE (bloqueado).
        Direccion dir1 = calcularProximaDireccion(troll, mapa);
        assertNull(dir1, "El Troll debe estar inmóvil si está rodeado.");
        
        // Verificar que la posición no cambió
        assertEquals(new Posicion(5, 5), troll.getPosicion());
    }
    
    // --- ESCENARIO 4: Colisión con Obstáculo Perpendicular (Sin Cambio de Patrón) ---
    @Test
    void testIgnorarObstaculoPerpendicular() {
        // Troll en (5, 5), dirección inicial ESTE.
        troll = new Troll(new Posicion(5, 5));
        mapa.agregarEntidad(troll, troll.getPosicion());
        
        // Colocar un obstáculo perpendicular (no debería causar giro)
        mapa.agregarEntidad(new Pared(new Posicion(5, 4)), new Posicion(5, 4)); // NORTE
        
        // Tick 1: Intenta ESTE (6, 5). Es libre.
        Direccion dir1 = calcularProximaDireccion(troll, mapa);
        assertEquals(Direccion.ESTE, dir1, "El obstáculo perpendicular no debe afectar el movimiento horizontal.");
    }
}