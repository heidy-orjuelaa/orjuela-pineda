package Dominio;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class JugadorTest {

    @Test
    void jugadorSeCreaConPuntajeCeroYVivo() {
        Jugador j = new Jugador("Juan", Jugador.TipoJugador.HUMANO, "Vainilla");

        assertEquals(0, j.getPuntajeTotal());
        assertFalse(j.estaMuerto());
    }

    @Test
    void sumarPuntosIncrementaElPuntaje() {
        Jugador j = new Jugador("Ana", Jugador.TipoJugador.HUMANO, "Chocolate");

        j.sumarPuntos(10);
        j.sumarPuntos(5);

        assertEquals(15, j.getPuntajeTotal());
    }

    @Test
    void jugadorPuedeMorir() {
        Jugador j = new Jugador("Pedro", Jugador.TipoJugador.HUMANO, "Fresa");

        j.morir();

        assertTrue(j.estaMuerto());
    }

    @Test
    void jugadorPuedeRevivir() {
        Jugador j = new Jugador("Luis", Jugador.TipoJugador.HUMANO, "Vainilla");

        j.morir();
        j.revivir();

        assertFalse(j.estaMuerto());
    }

    @Test
    void seAsignaCorrectamenteElTipoDeJugador() {
        Jugador j = new Jugador("CPU", Jugador.TipoJugador.MAQUINA_HUNGRY);

        assertEquals(Jugador.TipoJugador.MAQUINA_HUNGRY, j.getTipoJugador());
    }

    @Test
    void seAsignaCorrectamenteElNombre() {
        Jugador j = new Jugador("Carlos", Jugador.TipoJugador.HUMANO, "Chocolate");

        assertEquals("Carlos", j.getNombre());
    }

}
