package Presentacion;

import Dominio.Juego;
import Dominio.Direccion;

import javax.swing.JPanel;
import javax.swing.InputMap;
import javax.swing.ActionMap;
import javax.swing.KeyStroke;
import javax.swing.AbstractAction;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

/**
 * Panel principal de Swing donde se renderiza el estado del juego (Mapa, Entidades).
 * * También es responsable de mapear las pulsaciones de teclas (KeyStroke) a acciones
 * del juego mediante los mecanismos de InputMap y ActionMap de Swing.
 */
public class PanelJuego extends JPanel {

    private final Renderizador renderizador;
    private ControladorJuego controlador;
    private static final int TILE_SIZE = 32;
    private static final int ANCHO_CELDAS = 25;
    private static final int ALTO_CELDAS = 18;
    private static final int ANCHO_PANEL = ANCHO_CELDAS * TILE_SIZE;
    private static final int ALTO_PANEL = ALTO_CELDAS * TILE_SIZE;

    /**
     * Constructor por defecto, inicializa el panel sin un controlador.
     */
    
    public PanelJuego() {
        this(null);
    }

    /**
     * Constructor que inicializa el panel y le asigna un controlador de juego.
     *
     * @param controlador El ControladorJuego asociado a este panel.
     */
    
    public PanelJuego(ControladorJuego controlador) {
        this.renderizador = new Renderizador();
        this.controlador = controlador;

        setBackground(Color.BLACK);
        setPreferredSize(new Dimension(ANCHO_PANEL, ALTO_PANEL));
        setFocusable(true);

        if (controlador != null) configurarTeclado(controlador);
    }

    /**
     * Establece o cambia el controlador y reconfigura los bindings del teclado.
     *
     * @param controlador El nuevo ControladorJuego.
     */
    
    public void setControlador(ControladorJuego controlador) {
        this.controlador = controlador;
        if (controlador != null) configurarTeclado(controlador);
        this.requestFocusInWindow();
    }

    /**
     * Retorna el tamaño preferido del panel (ancho y alto del mapa en píxeles).
     */
    
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(ANCHO_PANEL, ALTO_PANEL);
    }

    /**
     * Método de pintado principal, invocado por Swing (generalmente por repaint()).
     * * Pide al Renderizador que dibuje el estado actual del mapa del juego.
     *
     * @param g El contexto gráfico.
     */
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (controlador == null) {
            g.setColor(Color.RED);
            g.drawString("Controlador no inicializado.", 10, 20);
            return;
        }

        Juego juego = controlador.getJuego();

        if (juego != null && juego.getMapa() != null) {
            renderizador.dibujarMapa(g, juego.getMapa());
        } else {
            g.setColor(Color.WHITE);
            g.drawString("Cargando juego...", 10, 20);
        }
    }

    /**
     * Configura el mapeo de teclas (InputMap) a acciones (ActionMap) para el Jugador 0.
     * * Utiliza AbstractAction para enlazar eventos de teclado con métodos del controlador.
     *
     * @param controlador El ControladorJuego para invocar las acciones.
     */
    
    private void configurarTeclado(ControladorJuego controlador) {
        InputMap im = this.getInputMap(WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = this.getActionMap();

        im.clear();
        am.clear();

        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "moverArriba");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "moverAbajo");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "moverIzquierda");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "moverDerecha");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0), "crearHielo");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_SHIFT, 0), "romperHielo");

        am.put("moverArriba", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (controlador != null) controlador.moverJugadorHumano(0, Direccion.NORTE);
                repaint();
            }
        });
        am.put("moverAbajo", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (controlador != null) controlador.moverJugadorHumano(0, Direccion.SUR);
                repaint();
            }
        });
        am.put("moverIzquierda", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (controlador != null) controlador.moverJugadorHumano(0, Direccion.OESTE);
                repaint();
            }
        });
        am.put("moverDerecha", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (controlador != null) controlador.moverJugadorHumano(0, Direccion.ESTE);
                repaint();
            }
        });

        am.put("crearHielo", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (controlador != null) controlador.crearHieloHumano(0);
                repaint();
            }
        });

        am.put("romperHielo", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (controlador != null) controlador.romperHieloHumano(0);
                repaint();
            }
        });

        this.requestFocusInWindow();
    }
}