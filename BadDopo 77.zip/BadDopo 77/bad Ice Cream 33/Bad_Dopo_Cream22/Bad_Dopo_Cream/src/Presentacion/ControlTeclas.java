package Presentacion;

import Dominio.Direccion;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Clase encargada de manejar las entradas del teclado.
 * 
 * Traduce las teclas presionadas en acciones del jugador humano
 * y se comunica con el controlador del juego.
 */

public class ControlTeclas extends KeyAdapter {

    private final ControladorJuego controlador;

    /**
     * Constructor de la clase ControlTeclas.
     * 
     * @param controlador controlador del juego que recibe las acciones
     */
    
    public ControlTeclas(ControladorJuego controlador) {
        this.controlador = controlador;
    }
    
    /**
     * Se ejecuta cuando el usuario presiona una tecla.
     * 
     * Asigna las teclas de movimiento y acciones especiales
     * para uno o dos jugadores humanos.
     * 
     * @param e evento de teclado
     */

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_UP) controlador.moverJugadorHumano(0, Direccion.NORTE);
        else if (key == KeyEvent.VK_DOWN) controlador.moverJugadorHumano(0, Direccion.SUR);
        else if (key == KeyEvent.VK_LEFT) controlador.moverJugadorHumano(0, Direccion.OESTE);
        else if (key == KeyEvent.VK_RIGHT) controlador.moverJugadorHumano(0, Direccion.ESTE);
        
        else if (key == KeyEvent.VK_COMMA) controlador.crearHieloHumano(0);
        else if (key == KeyEvent.VK_PERIOD) controlador.romperHieloHumano(0);


        else if (key == KeyEvent.VK_W) controlador.moverJugadorHumano(1, Direccion.NORTE);
        else if (key == KeyEvent.VK_S) controlador.moverJugadorHumano(1, Direccion.SUR);
        else if (key == KeyEvent.VK_A) controlador.moverJugadorHumano(1, Direccion.OESTE);
        else if (key == KeyEvent.VK_D) controlador.moverJugadorHumano(1, Direccion.ESTE);

        else if (key == KeyEvent.VK_Q) controlador.crearHieloHumano(1);
        else if (key == KeyEvent.VK_E) controlador.romperHieloHumano(1);
    }
}