package Presentacion;

import Dominio.*;
import Dominio.Direccion;
import Dominio.Jugador.TipoJugador;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.ArrayList;

/**
 * Clase que actúa como controlador principal del juego.
 * 
 * Se encarga de coordinar la lógica del juego con la interfaz gráfica,
 * manejar el tiempo, las entradas del usuario, la inteligencia artificial
 * y la actualización del estado del juego.
 */

public class ControladorJuego implements ActionListener {

    private final Juego juego;
    private final PanelJuego panelJuego;
    private final HUD hud;
    private Timer timer;
    private static final int DELAY_MS = 50;

    private static final int TIEMPO_TOTAL_SEG = 180;
    private int tiempoRestante;
    private int contadorTicks = 0;

    /**
     * Constructor del ControladorJuego.
     * 
     * @param panelJuego panel gráfico del juego
     * @param hud interfaz de información del jugador
     * @param jugadores lista de jugadores de la partida
     */
    
    public ControladorJuego(PanelJuego panelJuego, HUD hud, List<Jugador> jugadores) {
        this.juego = new Juego(jugadores);
        this.panelJuego = panelJuego;
        this.hud = hud;

        this.tiempoRestante = TIEMPO_TOTAL_SEG;

        inicializarControlador();
    }

    public ControladorJuego(PanelJuego panelJuego, HUD hud, Juego juego) {
        this.juego = juego;
        this.panelJuego = panelJuego;
        this.hud = hud;

        this.tiempoRestante = juego.getTiempoRestante();

        inicializarControlador();
    }

    private void inicializarControlador() {
        hud.actualizarTiempo(tiempoRestante);
        timer = new Timer(DELAY_MS, this);
        timer.start();
    }



    /**
     * Inicia o reinicia el nivel actual.
     */
    
    public void iniciarNivel() {
        juego.iniciarNivel(); 
        tiempoRestante = TIEMPO_TOTAL_SEG;
        actualizarHUD();

        ControladorAudio.getInstancia().iniciarMusica();
        
        if (panelJuego != null) panelJuego.repaint();
    }

    /**
     * Mueve a un jugador humano en la dirección indicada.
     * 
     * @param indice índice del jugador
     * @param dir dirección de movimiento
     */
    
    public void moverJugadorHumano(int indice, Direccion dir) {
        if (!juego.getJugadores().isEmpty() && indice >= 0 && indice < juego.getJugadores().size()) {
            juego.moverJugadorHumano(juego.getJugadores().get(indice), dir);
            actualizarHUD();
            panelJuego.repaint();
        }
    }

    /**
     * Permite a un jugador humano crear bloques de hielo.
     * 
     * @param indice índice del jugador
     */
    
    public void crearHieloHumano(int indice) {
        if (!juego.getJugadores().isEmpty() && indice >= 0 && indice < juego.getJugadores().size()) {
            juego.crearBloquesHieloHumano(juego.getJugadores().get(indice));
            actualizarHUD();
            panelJuego.repaint();
        }
    }

    /**
     * Permite a un jugador humano romper bloques de hielo.
     * 
     * @param indice índice del jugador
     */
    
    public void romperHieloHumano(int indice) {
        if (!juego.getJugadores().isEmpty() && indice >= 0 && indice < juego.getJugadores().size()) {
            juego.romperBloquesHieloHumano(juego.getJugadores().get(indice));
            actualizarHUD();
            panelJuego.repaint();
        }
    }

    /**
     * Actualiza el comportamiento de los jugadores controlados por IA.
     */
    
    private void actualizarIA() {
        for (Jugador j : juego.getJugadores()) {
            if (j.getTipoJugador() != TipoJugador.HUMANO && !j.estaMuerto()) {
                Helado h = j.getHelado();
                if (h != null && h.getIA() != null) {
                    Direccion mov = h.getIA().calcularMovimiento(h, juego.getMapa());
                    if (mov != null) {
                        juego.getMapa().moverEntidad(h, mov);
                    }
                }
            }
        }
    }
    
    /**
     * Verifica las colisiones entre helados, frutas y enemigos.
     */

    public void verificarColisiones() {
        for (Jugador j : juego.getJugadores()) {
            Helado h = j.getHelado();
            if (h == null) continue;

            List<Fruta> frutas = juego.getMapa().getFrutas();
            for (Fruta f : frutas.toArray(new Fruta[0])) {
                if (h.getPosicion().equals(f.getPosicion())) {
                    f.recolectar(j);
                    frutas.remove(f);
                }
            }

            for (Enemigo e : juego.getMapa().getEnemigos()) {
                if (h.getPosicion().equals(e.getPosicion())) {
                    j.morir();
                }
            }
        }

        actualizarHUD();

        boolean todosMuertos = juego.getJugadores().stream()
                .filter(p -> p.getTipoJugador() == TipoJugador.HUMANO)
                .allMatch(Jugador::estaMuerto);

        if (todosMuertos || juego.getMapa().getFrutas().isEmpty()) {
            terminarNivel();
        }
    }

    /**
     * Verifica las colisiones entre helados, frutas y enemigos.
     */
    
    private void actualizarHUD() {
        for (int i = 0; i < juego.getJugadores().size(); i++) {
            Jugador j = juego.getJugadores().get(i);
            hud.actualizarPuntos(i, j.getPuntajeTotal());
            hud.actualizarVidas(i, j.getHelado() != null ? (j.estaMuerto() ? 0 : 1) : 0);
        }
    }
    
    /**
     * Método ejecutado periódicamente por el temporizador.
     * Controla el tiempo del nivel y actualiza el juego.
     * 
     * @param e evento del temporizador
     */

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!juego.estaTerminado()) {
            contadorTicks++;
            if (contadorTicks >= 20) { 
                tiempoRestante--;
                hud.actualizarTiempo(tiempoRestante);
                contadorTicks = 0;

                if (tiempoRestante <= 0) {
                    juegoTerminadoPorTiempo();
                }
            }

            actualizarIA();
            verificarColisiones();
            panelJuego.repaint();
        }
    }

    /**
     * Finaliza el juego cuando se acaba el tiempo.
     */
    
    private void juegoTerminadoPorTiempo() {
        timer.stop();
        ControladorAudio.getInstancia().detenerMusica();
        JOptionPane.showMessageDialog(panelJuego, "¡Se acabó el tiempo! Puntaje: " + juego.getJugadores().get(0).getPuntajeTotal());
        terminarNivel();
        timer.start();
    }

    /**
     * Finaliza el nivel actual y lo reinicia.
     */
    
    private void terminarNivel() {
        juego.iniciarNivel();
        tiempoRestante = TIEMPO_TOTAL_SEG;
        actualizarHUD();
        panelJuego.repaint();
    }

    /**
     * @return instancia del juego
     */
    
    public void pausar() {
        if (timer != null) {
            timer.stop();
        }
    }

    public void reanudar() {
        if (timer != null) {
            timer.start();
        }
    }

    public Juego getJuego() {
        return juego;
    }

    /**
     * @return tiempo restante del nivel
     */
    
    public int getTiempoRestante() {
        return tiempoRestante;
    }
}