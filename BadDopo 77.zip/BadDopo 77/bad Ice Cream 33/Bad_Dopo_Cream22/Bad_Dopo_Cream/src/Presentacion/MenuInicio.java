package Presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Representa el panel principal del Menú de Inicio de la aplicación.
 * * Configura la interfaz de usuario con un título y botones para las opciones principales del juego.
 */
public class MenuInicio extends JPanel {
    private JButton btnNuevoJuego;
    private JButton btnSeleccionPerfil;
    private JButton btnModoJuego;
    private JButton btnSalir;
    private JLabel lblTitulo;

    /**
     * Constructor que inicializa los componentes del menú y asigna los listeners a cada botón.
     *
     * @param listenerNuevo ActionListener para el botón Nuevo Juego.
     * @param listenerPerfil ActionListener para el botón Seleccionar Perfil IA.
     * @param listenerModo ActionListener para el botón Modo de Juego.
     * @param listenerSalir ActionListener para el botón Salir.
     */
    public MenuInicio(ActionListener listenerNuevo, ActionListener listenerPerfil, ActionListener listenerModo, ActionListener listenerSalir) {
        setLayout(new BorderLayout());

        lblTitulo = new JLabel("BAD ICE CREAM", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 36));
        lblTitulo.setForeground(Color.ORANGE);
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(4, 1, 20, 20)); 
        panelBotones.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        btnNuevoJuego = new JButton("Nuevo Juego");
        btnSeleccionPerfil = new JButton("Seleccionar Perfil IA");
        btnModoJuego = new JButton("Modo de Juego");
        btnSalir = new JButton("Salir");

        btnNuevoJuego.setFont(new Font("Arial", Font.BOLD, 20));
        btnSeleccionPerfil.setFont(new Font("Arial", Font.BOLD, 20));
        btnModoJuego.setFont(new Font("Arial", Font.BOLD, 20));
        btnSalir.setFont(new Font("Arial", Font.BOLD, 20));

        panelBotones.add(btnNuevoJuego);
        panelBotones.add(btnSeleccionPerfil);
        panelBotones.add(btnModoJuego);
        panelBotones.add(btnSalir);

        add(panelBotones, BorderLayout.CENTER);


        btnNuevoJuego.addActionListener(listenerNuevo);
        btnSeleccionPerfil.addActionListener(listenerPerfil);
        btnModoJuego.addActionListener(listenerModo);
        btnSalir.addActionListener(listenerSalir);
    }

    /** Retorna el botón para iniciar un nuevo juego. */
    
    public JButton getBtnNuevoJuego() { return btnNuevoJuego; }
    
    /** Retorna el botón para seleccionar perfiles de IA. */
    
    public JButton getBtnSeleccionPerfil() { return btnSeleccionPerfil; }
    
    /** Retorna el botón para cambiar el modo de juego. */
    
    public JButton getBtnModoJuego() { return btnModoJuego; }
    
    /** Retorna el botón para salir de la aplicación. */
    
    public JButton getBtnSalir() { return btnSalir; }
}