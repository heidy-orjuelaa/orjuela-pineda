package Presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Panel gráfico que permite seleccionar el modo de juego.
 * 
 * Contiene botones para los distintos tipos de juego disponibles
 * y se encarga únicamente de la parte visual y de interacción.
 */

public class SelectorModoJuego extends JPanel {

    private JButton btnPlayer;
    private JButton btnPvsP;
    private JButton btnPvsM;
    private JButton btnMvsM;

    /**
     * Constructor del panel SelectorModoJuego.
     * Inicializa los botones y define la disposición visual del panel.
     */
    
    public SelectorModoJuego() {
        setLayout(new GridLayout(4, 1, 20, 20));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        btnPlayer = new JButton("Player (Modo Clásico)");
        btnPvsP = new JButton("Player vs Player");
        btnPvsM = new JButton("Player vs Machine");
        btnMvsM = new JButton("Machine vs Machine");

        add(btnPlayer);
        add(btnPvsP);
        add(btnPvsM);
        add(btnMvsM);
    }
    
    /**
     * Asigna un mismo ActionListener a todos los botones del panel.
     * 
     * @param listener acción que se ejecutará al presionar un botón
     */

    public void setActionListeners(ActionListener listener) {
        btnPlayer.addActionListener(listener);
        btnPvsP.addActionListener(listener);
        btnPvsM.addActionListener(listener);
        btnMvsM.addActionListener(listener);
    }

    public JButton getBtnPlayer() { return btnPlayer; }
    public JButton getBtnPvsP() { return btnPvsP; }
    public JButton getBtnPvsM() { return btnPvsM; }
    public JButton getBtnMvsM() { return btnMvsM; }
}



