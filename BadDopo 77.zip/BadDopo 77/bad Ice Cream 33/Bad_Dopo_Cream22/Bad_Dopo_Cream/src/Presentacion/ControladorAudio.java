package Presentacion;

import javax.sound.sampled.*;
import java.io.BufferedInputStream; 
import java.io.IOException;
import java.io.InputStream;

public class ControladorAudio {

    private Clip musicaFondoClip;
    private static ControladorAudio instancia;


    private static final String RUTA_MUSICA = "/audio/retro-game-arcade-short-236130(1).wav"; 

    private ControladorAudio() {
    }

    public static ControladorAudio getInstancia() {
        if (instancia == null) {
            instancia = new ControladorAudio();
            instancia.cargarMusica();
        }
        return instancia;
    }

    /**
     * Carga el archivo de audio usando el ClassLoader (robusto para archivos JAR).
     */
    
    private void cargarMusica() {
    	if (musicaFondoClip == null) {
            System.out.println("DEBUG AUDIO: ¡FALLÓ LA CARGA DEL CLIP! Revisar formato y path.");
        } else {
            System.out.println("DEBUG AUDIO: ¡CLIP CARGADO EXITOSAMENTE! El formato y path son correctos.");
        }
    }

    /**
     * Inicia la reproducción de la música de fondo en bucle.
     */
    
    public void iniciarMusica() {
        if (musicaFondoClip != null) {
            musicaFondoClip.stop(); 
            musicaFondoClip.setFramePosition(0); 
            musicaFondoClip.loop(Clip.LOOP_CONTINUOUSLY); 
        }
    }

    /**
     * Detiene la reproducción de la música.
     */
    
    public void detenerMusica() {
        if (musicaFondoClip != null && musicaFondoClip.isRunning()) {
            musicaFondoClip.stop();
        }
    }
    
    
}