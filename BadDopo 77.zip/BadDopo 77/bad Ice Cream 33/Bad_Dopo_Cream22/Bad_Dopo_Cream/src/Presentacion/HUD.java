package Presentacion;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Representa el Head-Up Display (HUD) del juego.
 * * Este es un panel de Swing (JPanel) que muestra información vital del juego
 * como el tiempo restante, puntajes y vidas de los jugadores, y cantidades de frutas.
 */

public class HUD extends JPanel {

    private JLabel lblTiempo;
    private JLabel lblPuntosJugador1;
    private JLabel lblPuntosJugador2;
    private JLabel lblVidasJugador1;
    private JLabel lblVidasJugador2;
    private Map<String, JLabel> frutas;

    public HUD() {
        setLayout(new FlowLayout(FlowLayout.LEFT, 20, 5));

        lblTiempo = new JLabel("Tiempo: 0");
        lblPuntosJugador1 = new JLabel("Jugador 1 - Puntos: 0");
        lblPuntosJugador2 = new JLabel("Jugador 2 - Puntos: 0");
        lblVidasJugador1 = new JLabel("Vidas: 3");
        lblVidasJugador2 = new JLabel("Vidas: 3");

        add(lblTiempo);
        add(lblPuntosJugador1);
        add(lblPuntosJugador2);
        add(lblVidasJugador1);
        add(lblVidasJugador2);

        frutas = new HashMap<>();
        String[] tipos = {"Uva", "Platano", "Cereza", "Pina", "Cactus"};
        for (String tipo : tipos) {
            JLabel lbl = new JLabel(tipo + ": 0");
            frutas.put(tipo, lbl);
            add(lbl);
        }
    }

    public void actualizarTiempo(int tiempo) {
        lblTiempo.setText("Tiempo: " + tiempo);
    }

    public void actualizarPuntos(int jugador, int puntos) {
        if (jugador == 0) lblPuntosJugador1.setText("Jugador 1 - Puntos: " + puntos);
        if (jugador == 1) lblPuntosJugador2.setText("Jugador 2 - Puntos: " + puntos);
    }

    public void actualizarVidas(int jugador, int vidas) {
        if (jugador == 0) lblVidasJugador1.setText("Vidas: " + vidas);
        if (jugador == 1) lblVidasJugador2.setText("Vidas: " + vidas);
    }

    public void actualizarFruta(String tipo, int cantidad) {
        JLabel lbl = frutas.get(tipo);
        if (lbl != null) lbl.setText(tipo + ": " + cantidad);
    }
}


