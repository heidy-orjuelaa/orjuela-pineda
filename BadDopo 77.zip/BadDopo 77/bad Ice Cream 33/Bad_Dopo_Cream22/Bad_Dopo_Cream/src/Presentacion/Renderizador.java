package Presentacion;

import Dominio.Mapa;
import Dominio.Posicion;
import Dominio.Celda;
import Dominio.Entidad;
import Dominio.Helado;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.util.List;

/**
 * Clase encargada de dibujar gráficamente el mapa del juego.
 * 
 * Se encarga de renderizar el fondo y todas las entidades
 * según su tipo y su capa visual.
 */

public class Renderizador {

    private static final int TILE_SIZE = 32;
    private final RecursosGraficos recursos = RecursosGraficos.getInstancia();

    /**
     * Determina la capa de dibujo de una entidad.
     * 
     * Las capas permiten controlar el orden en el que se
     * dibujan los elementos.
     * 
     * @param e entidad a evaluar
     * @return número de capa
     */
    
    private int obtenerCapa(Entidad e) {
        String tipo = e.getTipo();
        if ("Suelo".equals(tipo)) return 0;
        if ("Pared".equals(tipo) || "BloqueHielo".equals(tipo) || "Fogata".equals(tipo)) return 1;
        if ("Fruta".equals(tipo) || "Meta".equals(tipo) || "Bonus".equals(tipo)) return 2;
        if (tipo != null && tipo.startsWith("Enemigo")) return 3;
        if (e instanceof Helado) return 4;
        return 2;
    }

    /**
     * Dibuja todo el mapa del juego.
     * 
     * Incluye el fondo, las entidades y respeta el orden
     * de capas para una correcta visualización.
     * 
     * @param g contexto gráfico
     * @param mapa mapa del juego a dibujar
     */
    
    public void dibujarMapa(Graphics g, Mapa mapa) {
        if (mapa == null) return; 

        dibujarFondo(g, mapa);

        for (int y = 0; y < mapa.getAlto(); y++) {
            for (int x = 0; x < mapa.getAncho(); x++) {

                Posicion cellPos = new Posicion(x, y);
                Celda celda = mapa.getCelda(cellPos);
                if (celda == null) continue;

                List<Entidad> entidades = celda.getEntidades();
                Entidad[] capas = new Entidad[5];

                for (Entidad e : entidades) {
                    int capa = obtenerCapa(e);
                    if (capa < 0 || capa >= capas.length) capa = capas.length - 1;
                    capas[capa] = e;
                }

                for (Entidad e : capas) {
                    if (e != null) {
                        dibujarEntidad(g, e, e.getPosicion());
                    }
                }
            }
        }
    }

    /**
     * Dibuja el fondo del mapa utilizando una baldosa repetida.
     * 
     * @param g contexto gráfico
     * @param mapa mapa del juego
     */
    
    private void dibujarFondo(Graphics g, Mapa mapa) {
        Image fondo = recursos.getImagen("BaldosaNormal");
        for (int y = 0; y < mapa.getAlto(); y++) {
            for (int x = 0; x < mapa.getAncho(); x++) {
                if (fondo != null) {
                    g.drawImage(fondo, x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);
                } else {
                    g.setColor(new Color(200, 230, 250));
                    g.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                }
            }
        }
    }

    /**
     * Dibuja una entidad específica en el mapa.
     * 
     * Determina la imagen a usar según el tipo de entidad
     * o el sabor del helado.
     * 
     * @param g contexto gráfico
     * @param e entidad a dibujar
     * @param pos posición de la entidad
     */
    
    private void dibujarEntidad(Graphics g, Entidad e, Posicion pos) {
        if (pos == null) return;

        Image img = null;

        if (e instanceof Helado) {
            Helado h = (Helado) e;
            String sabor = h.getSabor(); 
            if (sabor != null) {
                img = recursos.getImagen("Helado" + sabor);
                if (img == null) img = recursos.getImagen(sabor);
            }

            if (img == null) img = recursos.getImagen("Helado");
        } else {
            img = recursos.getImagen(e.getTipo());
        }

        if (img != null) {
            g.drawImage(img, pos.getX() * TILE_SIZE, pos.getY() * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);
        } else {
            g.setColor(Color.MAGENTA);
            g.fillRect(pos.getX() * TILE_SIZE + 4, pos.getY() * TILE_SIZE + 4, TILE_SIZE - 8, TILE_SIZE - 8);
            g.setColor(Color.BLACK);
            String tipo = e.getTipo() == null ? "?" : e.getTipo();
            g.drawString(tipo, pos.getX() * TILE_SIZE + 2, pos.getY() * TILE_SIZE + 12);
        }
    }
}
