package Presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Panel gráfico que se muestra al finalizar un nivel.
 * 
 * Informa al jugador si ganó o perdió, muestra el puntaje obtenido
 * y permite continuar al siguiente nivel o volver al menú principal.
 */

public class PantallaNivelCompletado extends JPanel {

    private JLabel lblMensaje;
    private JLabel lblPuntaje;
    private JButton btnSiguienteNivel;
    private JButton btnMenu;

    /**
     * Constructor del panel PantallaNivelCompletado.
     * 
     * @param victoria indica si el jugador completó el nivel exitosamente
     * @param puntaje puntaje obtenido en el nivel
     * @param siguienteNivelListener acción para continuar al siguiente nivel
     * @param volverMenuListener acción para volver al menú principal
     */
    
    public PantallaNivelCompletado(boolean victoria, int puntaje,
                                   ActionListener siguienteNivelListener,
                                   ActionListener volverMenuListener) {
        setLayout(new GridLayout(4, 1, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        lblMensaje = new JLabel(victoria ? "¡Nivel Completado!" : "¡Perdiste!", SwingConstants.CENTER);
        lblMensaje.setFont(new Font("Arial", Font.BOLD, 24));
        lblMensaje.setForeground(victoria ? Color.GREEN.darker() : Color.RED);

        lblPuntaje = new JLabel("Puntaje: " + puntaje, SwingConstants.CENTER);
        lblPuntaje.setFont(new Font("Arial", Font.PLAIN, 20));

        btnSiguienteNivel = new JButton("Siguiente Nivel");
        btnMenu = new JButton("Volver al Menú");

        btnSiguienteNivel.addActionListener(siguienteNivelListener);
        btnMenu.addActionListener(volverMenuListener);

        add(lblMensaje);
        add(lblPuntaje);
        add(btnSiguienteNivel);
        add(btnMenu);
    }

    /**
     * Actualiza el mensaje y el puntaje mostrado en pantalla.
     * 
     * @param victoria indica si el nivel fue completado con éxito
     * @param puntaje puntaje obtenido
     */
    
    public void actualizarMensaje(boolean victoria, int puntaje) {
        lblMensaje.setText(victoria ? "¡Nivel Completado!" : "¡Perdiste!");
        lblMensaje.setForeground(victoria ? Color.GREEN.darker() : Color.RED);
        lblPuntaje.setText("Puntaje: " + puntaje);
    }
}


