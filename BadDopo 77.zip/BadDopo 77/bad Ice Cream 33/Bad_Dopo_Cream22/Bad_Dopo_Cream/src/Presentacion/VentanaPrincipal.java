package Presentacion;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList; 
import java.util.List;

import Dominio.Jugador;
import Dominio.Jugador.TipoJugador; 
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import Dominio.Juego;
import java.io.File;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Enumeración que define los modos de juego disponibles.
 */

enum ModoJuego { PVP, PVM, MVM, SOLO }

/**
 * Ventana principal del juego Bad Ice Cream.
 * 
 * Esta clase se encarga de gestionar toda la interfaz gráfica principal,
 * el flujo entre pantallas (menús, selectores y juego),
 * y la inicialización del controlador del juego.
 */

public class VentanaPrincipal extends JFrame {

    private CardLayout cardLayout;
    private JPanel contenedor;
    private MenuInicio menuInicio;
    private SelectorModoJuego selectorModo;
    private SelectorPerfilIA selectorIA;
    private SelectorNivel selectorNivel;
    private PanelJuego panelJuego;
    private HUD hud;
    private ControladorJuego controlador;
    
    
    private List<Jugador> jugadoresSeleccionados; 
    private ModoJuego modoActual; 

    private static final int TILE_SIZE = 32;
    private static final int ANCHO_CELDAS = 25;
    private static final int ALTO_CELDAS = 18;
    private static final int ANCHO_PANEL = ANCHO_CELDAS * TILE_SIZE;
    private static final int ALTO_PANEL = ALTO_CELDAS * TILE_SIZE;
    private static final int HUD_ALTO = 50;

    /**
     * Constructor de la ventana principal.
     * Inicializa la interfaz gráfica, los paneles
     * y configura los listeners principales.
     */
    
    public VentanaPrincipal() {
    	super("Bad Ice Cream");
    	
        try {

            cardLayout = new CardLayout();
            contenedor = new JPanel(cardLayout);

            menuInicio = new MenuInicio(
                    e -> iniciarNuevoJuego(),
                    e -> seleccionarPerfil(),
                    e -> cambiarModoJuego(),
                    e -> salirJuego()
            );
            selectorModo = new SelectorModoJuego();
            selectorIA = new SelectorPerfilIA();
            selectorNivel = new SelectorNivel();
            hud = new HUD();

            contenedor.add(menuInicio, "MenuInicio");
            contenedor.add(selectorModo, "SelectorModo");
            contenedor.add(selectorIA, "SelectorIA");
            contenedor.add(selectorNivel, "SelectorNivel");

            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLayout(new BorderLayout());
            
            setJMenuBar(crearBarraMenu());
            
            add(contenedor, BorderLayout.CENTER);
            setSize(ANCHO_PANEL, ALTO_PANEL + HUD_ALTO);
            setResizable(true);
            setLocationRelativeTo(null);
            
            setVisible(true);

            configurarMenu();
            configurarSelectorModo();
            configurarSelectorIA();
            configurarSelectorNivel();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error al iniciar la aplicación.",
                    "Error crítico",
                    JOptionPane.ERROR_MESSAGE
            );
            System.exit(1);
        }
    }


    /**
     * Configura las acciones del menú principal.
     */
    
    private void configurarMenu() {
        menuInicio.getBtnNuevoJuego().addActionListener(e -> cardLayout.show(contenedor, "SelectorModo"));
        menuInicio.getBtnSeleccionPerfil().addActionListener(e ->
                JOptionPane.showMessageDialog(this, "Primero seleccione una modalidad"));
        menuInicio.getBtnModoJuego().addActionListener(e -> cardLayout.show(contenedor, "SelectorModo"));
        menuInicio.getBtnSalir().addActionListener(e -> System.exit(0));
    }
    
    /**
     * Configura los botones del selector de modo de juego.
     */

    private void configurarSelectorModo() {
        selectorModo.getBtnPlayer().addActionListener(e -> seleccionarModo(ModoJuego.SOLO));
        selectorModo.getBtnPvsP().addActionListener(e -> seleccionarModo(ModoJuego.PVP));
        selectorModo.getBtnPvsM().addActionListener(e -> seleccionarModo(ModoJuego.PVM)); 
        selectorModo.getBtnMvsM().addActionListener(e -> seleccionarModo(ModoJuego.MVM)); 
    }

    /**
     * Selecciona el modo de juego y crea los jugadores
     * correspondientes según el modo.
     *
     * @param modo modo de juego elegido
     */
    
    private void seleccionarModo(ModoJuego modo) {
        if (modo == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Debe seleccionar una modalidad de juego válida.",
                    "Modalidad no seleccionada",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        jugadoresSeleccionados = new ArrayList<>();
        modoActual = modo;

        switch (modo) {
            case SOLO:
                jugadoresSeleccionados.add(new Jugador("P1", TipoJugador.HUMANO, "Vainilla"));
                break;
            case PVP:
                jugadoresSeleccionados.add(new Jugador("P1", TipoJugador.HUMANO, "Vainilla"));
                jugadoresSeleccionados.add(new Jugador("P2", TipoJugador.HUMANO, "Fresa"));
                break;
            case PVM:
                jugadoresSeleccionados.add(new Jugador("P1", TipoJugador.HUMANO, "Vainilla"));
                jugadoresSeleccionados.add(new Jugador("M1", TipoJugador.MAQUINA_HUNGRY));
                break;
            case MVM:
                jugadoresSeleccionados.add(new Jugador("M1", TipoJugador.MAQUINA_HUNGRY));
                jugadoresSeleccionados.add(new Jugador("M2", TipoJugador.MAQUINA_FEARFUL));
                break;
        }

        selectorIA.setCantidadJugadores(jugadoresSeleccionados.size());
        cardLayout.show(contenedor, "SelectorIA");
    }

    /**
     * Configura el selector de perfiles e IA.
     */
    
    private void configurarSelectorIA() {
        selectorIA.getBtnIniciar().addActionListener(e -> {
            
            if (jugadoresSeleccionados != null && !jugadoresSeleccionados.isEmpty()) { 
                pedirNombresYSabores();
            } else {
                JOptionPane.showMessageDialog(this, "Error al seleccionar jugadores.");
            }
        });
    }

    /**
     * Solicita al usuario los nombres y sabores
     * de los jugadores humanos.
     */
    
    private void pedirNombresYSabores() {
        int numHumanos = (int) jugadoresSeleccionados.stream()
                .filter(j -> j.getTipoJugador() == Jugador.TipoJugador.HUMANO).count();

        if (numHumanos > 0) {
            JPanel panel = new JPanel(new GridLayout(numHumanos, 4, 5, 5));
            JTextField[] camposNombre = new JTextField[numHumanos];
            JComboBox<String>[] combosSabor = new JComboBox[numHumanos];

            int idx = 0;
            for (int i = 0; i < jugadoresSeleccionados.size(); i++) {
                Jugador j = jugadoresSeleccionados.get(i);
                if (j.getTipoJugador() == Jugador.TipoJugador.HUMANO) {
                    panel.add(new JLabel("Nombre jugador " + (idx + 1) + ":"));
                    JTextField nombreField = new JTextField(j.getNombre());
                    panel.add(nombreField);
                    camposNombre[idx] = nombreField;

                    panel.add(new JLabel("Sabor del helado:"));
                    String[] opcionesSabores = {"Vainilla", "Fresa", "Chocolate"};
                    JComboBox<String> saborBox = new JComboBox<>(opcionesSabores);
                    saborBox.setSelectedItem(j.getSaborElegido());
                    panel.add(saborBox);
                    combosSabor[idx] = saborBox;

                    idx++;
                }
            }

            int result = JOptionPane.showConfirmDialog(
                    this,
                    panel,
                    "Información jugadores humanos",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );
            
            if (result != JOptionPane.OK_OPTION) {
                JOptionPane.showMessageDialog(
                        this,
                        "Debe completar la información para continuar.",
                        "Acción cancelada",
                        JOptionPane.INFORMATION_MESSAGE
                );
                return;
            }
            
            idx = 0;
            for (int i = 0; i < jugadoresSeleccionados.size(); i++) {
                Jugador j = jugadoresSeleccionados.get(i);
                if (j.getTipoJugador() == Jugador.TipoJugador.HUMANO) {
                    String nombre = j.getNombre();
                    String sabor = j.getSaborElegido();

                    if (result == JOptionPane.OK_OPTION) {
                        String textoNombre = camposNombre[idx].getText();

                        if (textoNombre == null || textoNombre.trim().isEmpty()) {
                            JOptionPane.showMessageDialog(
                                    this,
                                    "El nombre del jugador es obligatorio.",
                                    "Nombre inválido",
                                    JOptionPane.WARNING_MESSAGE
                            );
                            return;
                        }

                        nombre = textoNombre.trim();
                        sabor = (String) combosSabor[idx].getSelectedItem();
                    }


                    jugadoresSeleccionados.set(i, new Jugador(nombre, j.getTipoJugador(), sabor));
                    idx++;
                }
            }
        }

        cardLayout.show(contenedor, "SelectorNivel");
    }

    /**
     * Configura el selector de nivel.
     */
    
    private void configurarSelectorNivel() {
        selectorNivel.getBtnAceptar().addActionListener(e -> iniciarJuegoConNivel());
    }

    /**
     * Inicia el juego con la configuración de nivel seleccionada.
     */
    
    private void iniciarJuegoConNivel() {
        if (jugadoresSeleccionados == null || jugadoresSeleccionados.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "No hay jugadores configurados.\nDebe seleccionar una modalidad primero.",
                    "Error al iniciar el juego",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try {
            List<String> frutas = selectorNivel.obtenerFrutasSeleccionadas();
            List<String> enemigos = selectorNivel.obtenerEnemigosSeleccionados();
            int oleadas = selectorNivel.obtenerCantidadOleadas();

            if (frutas == null || frutas.size() < 2) {
                JOptionPane.showMessageDialog(
                        this,
                        "Debe seleccionar al menos DOS tipos de frutas para iniciar el nivel.",
                        "Configuración inválida",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            if (enemigos == null || enemigos.size() < 1) {
                JOptionPane.showMessageDialog(
                        this,
                        "Debe seleccionar al menos UN enemigo para iniciar el nivel.",
                        "Configuración inválida",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            panelJuego = new PanelJuego();
            controlador = new ControladorJuego(panelJuego, hud, jugadoresSeleccionados);

            controlador.getJuego().configurarNivel(frutas, enemigos, oleadas);

            panelJuego.setControlador(controlador);

            getContentPane().removeAll();
            setLayout(new BorderLayout());
            add(hud, BorderLayout.NORTH);
            add(panelJuego, BorderLayout.CENTER);

            panelJuego.setFocusable(true);
            panelJuego.requestFocusInWindow();
            panelJuego.addKeyListener(new ControlTeclas(controlador));

            revalidate();
            repaint();

            controlador.iniciarNivel();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Ocurrió un error inesperado al iniciar el nivel.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    /** Inicia un nuevo juego */

    private void iniciarNuevoJuego() {
        cardLayout.show(contenedor, "SelectorModo");
    }

    /** Muestra mensaje de funcionalidad no implementada */
    
    private void seleccionarPerfil() {
        JOptionPane.showMessageDialog(this, "Funcionalidad de seleccionar perfil aún no implementada.");
    }

    /** Permite cambiar el modo de juego */
    
    private void cambiarModoJuego() {
        cardLayout.show(contenedor, "SelectorModo");
    }


    private JMenuBar crearBarraMenu() {
        JMenuBar barra = new JMenuBar();

        JMenu menuJuego = new JMenu("Juego");

        JMenuItem itemAbrir = new JMenuItem("Abrir partida");
        JMenuItem itemGuardar = new JMenuItem("Guardar partida");
        JMenuItem itemPausar = new JMenuItem("Pausar");
        JMenuItem itemSalir = new JMenuItem("Salir");

        itemAbrir.addActionListener(e -> abrirPartida());
        itemGuardar.addActionListener(e -> guardarPartida());
        itemPausar.addActionListener(e -> pausarJuego());
        itemSalir.addActionListener(e -> salirJuego());

        menuJuego.add(itemAbrir);
        menuJuego.add(itemGuardar);
        menuJuego.addSeparator();
        menuJuego.add(itemPausar);
        menuJuego.addSeparator();
        menuJuego.add(itemSalir);

        barra.add(menuJuego);

        return barra;
    }

    private void abrirPartida() {
        JFileChooser chooser = new JFileChooser();
        int opcion = chooser.showOpenDialog(this);

        if (opcion == JFileChooser.APPROVE_OPTION) {
            try (ObjectInputStream in = new ObjectInputStream(
                    new FileInputStream(chooser.getSelectedFile()))) {

                Juego juegoCargado = (Juego) in.readObject();

                panelJuego = new PanelJuego();
                hud = new HUD();
                controlador = new ControladorJuego(panelJuego, hud, juegoCargado);

                panelJuego.setControlador(controlador);

                getContentPane().removeAll();
                setLayout(new BorderLayout());
                add(hud, BorderLayout.NORTH);
                add(panelJuego, BorderLayout.CENTER);

                panelJuego.setFocusable(true);
                panelJuego.requestFocusInWindow();
                panelJuego.addKeyListener(new ControlTeclas(controlador));

                revalidate();
                repaint();

                controlador.reanudar();

                JOptionPane.showMessageDialog(
                        this,
                        "Partida cargada correctamente.",
                        "Abrir",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (Exception e) {
                JOptionPane.showMessageDialog(
                        this,
                        "Error al abrir la partida.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }


    private void guardarPartida() {
        if (controlador == null || controlador.getJuego() == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "No hay una partida activa para guardar.",
                    "Guardar",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        JFileChooser chooser = new JFileChooser();
        int opcion = chooser.showSaveDialog(this);

        if (opcion == JFileChooser.APPROVE_OPTION) {

            File archivo = new File(
                    chooser.getSelectedFile().getAbsolutePath() + ".dat"
            );

            try (ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream(archivo))) {

                out.writeObject(controlador.getJuego());

                JOptionPane.showMessageDialog(
                        this,
                        "Partida guardada correctamente.",
                        "Guardar",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (IOException e) {

                e.printStackTrace(); 

                JOptionPane.showMessageDialog(
                        this,
                        "Error al guardar la partida:\n" + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }



    
    private void pausarJuego() {
        if (controlador == null) return;

        controlador.pausar();

        JOptionPane.showMessageDialog(
                this,
                "Juego en pausa.\nPresione Aceptar para continuar.",
                "Pausa",
                JOptionPane.INFORMATION_MESSAGE
        );

        controlador.reanudar();
    }

    private void salirJuego() {
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Desea salir del juego?",
                "Salir",
                JOptionPane.YES_NO_OPTION
        );

        if (opcion == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    /**
     * Método principal del programa.
     *
     * @param args argumentos de línea de comandos
     */
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(VentanaPrincipal::new);
    }
}