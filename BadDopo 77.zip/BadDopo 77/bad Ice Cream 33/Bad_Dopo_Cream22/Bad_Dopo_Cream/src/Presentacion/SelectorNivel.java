package Presentacion;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Panel gráfico que permite configurar el nivel del juego.
 * 
 * El usuario puede seleccionar las frutas, los enemigos
 * y la cantidad de oleadas que aparecerán en el nivel.
 */

public class SelectorNivel extends JPanel {

    private List<JCheckBox> frutasChecks;
    private List<JCheckBox> enemigosChecks;
    private JSpinner spinnerOleadas;
    private JButton btnAceptar;

    /**
     * Constructor del panel SelectorNivel.
     * Inicializa todos los componentes gráficos del panel.
     */
    
    public SelectorNivel() {
        setLayout(new BorderLayout());

        
        JPanel panelFrutas = new JPanel(new GridLayout(0, 1));
        panelFrutas.setBorder(BorderFactory.createTitledBorder("Selecciona las frutas"));
        String[] frutas = {"Uva", "Platano", "Cereza", "Pina", "Cactus"};
        frutasChecks = new ArrayList<>();
        for (String fruta : frutas) {
            JCheckBox cb = new JCheckBox(fruta);
            frutasChecks.add(cb);
            panelFrutas.add(cb);
        }

        
        JPanel panelEnemigos = new JPanel(new GridLayout(0, 1));
        panelEnemigos.setBorder(BorderFactory.createTitledBorder("Selecciona los enemigos"));
        String[] enemigos = {"Troll", "Maceta", "CalamarNaranja", "Narval"};
        enemigosChecks = new ArrayList<>();
        for (String enemigo : enemigos) {
            JCheckBox cb = new JCheckBox(enemigo);
            enemigosChecks.add(cb);
            panelEnemigos.add(cb);
        }

       
        JPanel panelOleadas = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelOleadas.setBorder(BorderFactory.createTitledBorder("Cantidad de oleadas de frutas"));
        spinnerOleadas = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        panelOleadas.add(new JLabel("Oleadas:"));
        panelOleadas.add(spinnerOleadas);

   
        btnAceptar = new JButton("Aceptar");

     
        JPanel panelCentro = new JPanel(new GridLayout(1, 3));
        panelCentro.add(panelFrutas);
        panelCentro.add(panelEnemigos);
        panelCentro.add(panelOleadas);

        add(panelCentro, BorderLayout.CENTER);
        add(btnAceptar, BorderLayout.SOUTH);
    }

    /**
     * @return botón para aceptar la configuración del nivel
     */
    
    public JButton getBtnAceptar() {
        return btnAceptar;
    }

    /**
     * Obtiene la lista de frutas seleccionadas por el usuario.
     * 
     * @return lista de nombres de frutas
     */
    
    public List<String> obtenerFrutasSeleccionadas() {
        List<String> seleccion = new ArrayList<>();
        for (JCheckBox cb : frutasChecks) {
            if (cb.isSelected()) seleccion.add(cb.getText());
        }
        return seleccion;
    }

    /**
     * Obtiene la lista de enemigos seleccionados por el usuario.
     * 
     * @return lista de nombres de enemigos
     */
    
    public List<String> obtenerEnemigosSeleccionados() {
        List<String> seleccion = new ArrayList<>();
        for (JCheckBox cb : enemigosChecks) {
            if (cb.isSelected()) seleccion.add(cb.getText());
        }
        return seleccion;
    }
    
    /**
     * Obtiene la cantidad de oleadas seleccionadas.
     * 
     * @return número de oleadas
     */

    public int obtenerCantidadOleadas() {
        return (int) spinnerOleadas.getValue();
    }
}


