package Presentacion;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;

/**
 * Clase encargada de cargar y administrar los recursos gráficos del juego.
 * 
 * Utiliza el patrón Singleton para asegurar que exista una única instancia
 * que maneje todas las imágenes del proyecto.
 */

public class RecursosGraficos {

    private static RecursosGraficos instancia;
    private final Map<String, Image> imagenes;

    /**
     * Constructor privado.
     * Inicializa el mapa de imágenes y carga todos los recursos gráficos.
     */
    
    private RecursosGraficos() {
        imagenes = new HashMap<>();
        cargarImagenes();
    }

    /**
     * Devuelve la instancia única de RecursosGraficos.
     * Si no existe, la crea.
     * 
     * @return instancia única de RecursosGraficos
     */
    
    public static RecursosGraficos getInstancia() {
        if (instancia == null) {
            instancia = new RecursosGraficos();
        }
        return instancia;
    }

    /**
     * Carga todas las imágenes necesarias para el juego
     * y las asocia a una clave para su posterior uso.
     */
    
    private void cargarImagenes() {
        cargar("HeladoVainilla", "vainilla.png");
        cargar("HeladoFresa", "fresa.png");
        cargar("HeladoChocolate", "chocolate.png");

        cargar("Vainilla", "vainilla.png");
        cargar("Fresa", "fresa.png");
        cargar("Chocolate", "chocolate.png");

        cargar("Uva", "Uva.png");
        cargar("Platano", "Platano.png");
        cargar("Pina", "Pina.png");
        cargar("Cereza", "Cereza.png");
        cargar("Cactus", "Cactus.png");

        cargar("Troll", "Troll.png");
        cargar("Maceta", "Maceta.png");
        cargar("CalamarNaranja", "CalamarNaranja.png");
        cargar("Narval", "Narval.png");

        cargar("Pared", "pared.png");
        cargar("Suelo", "suelo.png");
        cargar("BaldosaNormal", "suelo.png");
        cargar("BloqueHielo", "BloqueHielo.png");
        cargar("Meta", "meta.png");
        cargar("BaldosaCaliente", "BaldosaCaliente.png");
        cargar("FogataEncendida", "FogataEncendida.png");
        cargar("FogataApagada", "FogataApagada.png");

        
        if (!imagenes.containsKey("Helado")) {
         
        }
    }


    /**
     * Carga una imagen desde los recursos del proyecto o desde el sistema
     * de archivos y la guarda en el mapa de imágenes.
     * 
     * @param key nombre con el que se identificará la imagen
     * @param fileName nombre del archivo de imagen
     */
    
    private void cargar(String key, String fileName) {
        String ruta = "/assets/images/" + fileName;
        Image img = null;

        try {
            URL res = getClass().getResource(ruta);
            if (res != null) {
                img = ImageIO.read(res);
            }
        } catch (IOException ignored) {}

        if (img == null) {
            try {
                File f = new File("assets/images/" + fileName);
                if (f.exists()) {
                    img = ImageIO.read(f);
                }
            } catch (IOException ignored) {}
        }

        if (img == null) {
            System.err.println("advertencia: no se pudo cargar imagen para key='" + key + "' (probó: " + ruta + " y assets/images/" + fileName + ")");
        } else {
            imagenes.put(key, img);
        }
    }

    /**
     * Devuelve la imagen registrada para la clave dada (exact match).
     * No intenta hacer fallbacks que confundan (ese trabajo lo hace el Renderizador).
     */
    
    public Image getImagen(String tipoEntidad) {
        if (tipoEntidad == null) return null;
        return imagenes.get(tipoEntidad);
    }
}
