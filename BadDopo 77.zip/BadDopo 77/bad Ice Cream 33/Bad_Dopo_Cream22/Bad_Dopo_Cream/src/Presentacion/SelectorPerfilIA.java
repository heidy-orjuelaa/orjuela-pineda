package Presentacion;

import Dominio.Jugador;
import Dominio.Jugador.TipoJugador;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Panel gráfico que permite seleccionar el perfil de los jugadores,
 * ya sea humanos o controlados por inteligencia artificial.
 * 
 * Se adapta dinámicamente para uno o dos jugadores.
 */

public class SelectorPerfilIA extends JPanel {

    private int cantidadJugadores = 1; 

    private JLabel lblJugador1;
    private JComboBox<String> cmbJugador1;

    private JLabel lblJugador2;
    private JComboBox<String> cmbJugador2;

    private JButton btnIniciar;

    /**
     * Constructor del panel SelectorPerfilIA.
     * Inicializa los componentes gráficos y configura el diseño.
     */
    
    public SelectorPerfilIA() {
        setLayout(new GridLayout(3, 2, 10, 10));

        lblJugador1 = new JLabel("Jugador 1:");
        cmbJugador1 = new JComboBox<>(new String[]{ "HUMANO","IA Hungry", "IA Fearful", "IA Expert"});

        lblJugador2 = new JLabel("Jugador 2:");
        cmbJugador2 = new JComboBox<>(new String[]{"HUMANO","IA Hungry", "IA Fearful", "IA Expert"});

        btnIniciar = new JButton("Iniciar Juego");

        add(lblJugador1);
        add(cmbJugador1);
        add(lblJugador2);
        add(cmbJugador2);
        add(new JLabel()); 
        add(btnIniciar);

        lblJugador2.setVisible(false);
        cmbJugador2.setVisible(false);
    }

    /**
     * Define la cantidad de jugadores y ajusta la visibilidad
     * de los controles del segundo jugador.
     * 
     * @param cantidad número de jugadores (1 o 2)
     */
    
    public void setCantidadJugadores(int cantidad) {
        this.cantidadJugadores = cantidad;
        lblJugador2.setVisible(cantidad == 2);
        cmbJugador2.setVisible(cantidad == 2);
    }
    
    /**
     * Crea y devuelve la lista de jugadores según la selección realizada
     * en la interfaz gráfica.
     * 
     * @return lista de jugadores configurados
     */

    public List<Jugador> obtenerJugadoresSeleccionados() {
        List<Jugador> jugadores = new ArrayList<>();

        jugadores.add(crearJugador(0, cmbJugador1.getSelectedItem().toString()));
        if (cantidadJugadores == 2) {
            jugadores.add(crearJugador(1, cmbJugador2.getSelectedItem().toString()));
        }

        return jugadores;
    }

    /**
     * Crea un jugador según el perfil seleccionado.
     * 
     * @param id identificador del jugador
     * @param seleccion perfil elegido en el combo box
     * @return objeto Jugador configurado
     */
    
    private Jugador crearJugador(int id, String seleccion) {
        switch (seleccion) {
            case "Humano":
                return new Jugador("Player" + (id + 1), TipoJugador.HUMANO);
            case "IA Hungry":
                return new Jugador("IA Hungry" + (id + 1), TipoJugador.MAQUINA_HUNGRY);
            case "IA Fearful":
                return new Jugador("IA Fearful" + (id + 1), TipoJugador.MAQUINA_FEARFUL);
            case "IA Expert":
                return new Jugador("IA Expert" + (id + 1), TipoJugador.MAQUINA_EXPERT);
            default:
                return new Jugador("Player" + (id + 1), TipoJugador.HUMANO);
        }
    }

    public JButton getBtnIniciar() {
        return btnIniciar;
    }
}




