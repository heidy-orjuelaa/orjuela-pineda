package Dominio;

import java.io.*;
import java.util.Properties;

/**
 * Maneja la configuración persistente del juego utilizando un archivo
 * de propiedades. Permite cargar valores al iniciar el juego y
 * guardarlos cuando se realizan cambios.
 */

public class ConfiguracionDelJuego {

    
    private static final String ARCHIVO = "configuracion.properties";
    private final Properties props = new Properties();

    /**
     * Crea la configuración del juego e intenta cargar
     * los valores almacenados previamente.
     */
    
    public ConfiguracionDelJuego() {
        cargar();
    }

    /**
     * Carga la configuración desde el archivo.
     * Si el archivo no existe, se utilizan los valores por defecto.
     */
    
    public void cargar() {
        try (FileInputStream fis = new FileInputStream(ARCHIVO)) {
            props.load(fis);
        } catch (IOException e) {
            System.out.println("No hay configuración previa, se usarán valores por defecto.");
        }
    }

    /**
     * Guarda la configuración actual en el archivo.
     */
    
    public void guardar() {
        try (FileOutputStream fos = new FileOutputStream(ARCHIVO)) {
            props.store(fos, "Configuración del Juego");
        } catch (IOException e) {
            LoggerError.log("Error guardando configuración: " + e.getMessage());
        }
    }

    /**
     * Obtiene un valor entero de la configuración.
     * Si la clave no existe, se devuelve el valor por defecto.
     */
    
    public int getEntero(String clave, int defecto) {
        return Integer.parseInt(
            props.getProperty(clave, String.valueOf(defecto))
        );
    }

    /**
     * Asigna un valor entero a una clave de configuración.
     */
    
    public void setEntero(String clave, int valor) {
        props.setProperty(clave, String.valueOf(valor));
    }

    /**
     * Obtiene un valor de texto de la configuración.
     * Si la clave no existe, se devuelve el valor por defecto.
     */
    
    public String getString(String clave, String defecto) {
        return props.getProperty(clave, defecto);
    }

    /**
     * Asigna un valor de texto a una clave de configuración.
     */
    
    public void setString(String clave, String valor) {
        props.setProperty(clave, valor);
    }
}
