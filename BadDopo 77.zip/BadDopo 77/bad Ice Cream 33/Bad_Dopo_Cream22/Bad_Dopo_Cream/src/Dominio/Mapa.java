package Dominio;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa el mapa del juego.
 * 
 * El mapa está compuesto por una matriz de celdas y se encarga de:
 * - Gestionar las entidades del juego.
 * - Validar y ejecutar movimientos.
 * - Controlar colisiones e interacciones.
 * - Actualizar el estado del juego en cada ciclo.
 */

public class Mapa implements Serializable {
    private static final long serialVersionUID = 1L; 

    private int ancho;
    private int alto;
    private Celda[][] matriz;

    private List<Jugador> jugadores = new ArrayList<>();
    private List<Enemigo> enemigos = new ArrayList<>();
    private List<Fruta> frutas = new ArrayList<>();

    /**
     * Constructor del mapa.
     * 
     * Inicializa el mapa con el tamaño indicado y crea una celda vacía
     * en cada posición de la matriz.
     *
     * @param ancho número de columnas del mapa
     * @param alto  número de filas del mapa
     */
    
    public Mapa(int ancho, int alto) {
        this.ancho = ancho;
        this.alto = alto;
        this.matriz = new Celda[alto][ancho];
        for (int y = 0; y < alto; y++) {
            for (int x = 0; x < ancho; x++) {
                matriz[y][x] = new Celda();
            }
        }
    }


    /**
     * Agrega una entidad en una posición específica del mapa.
     *
     * @param entidad entidad a agregar
     * @param pos     posición donde se ubicará
     */
    
    public void agregarEntidad(Entidad entidad, Posicion pos) {
        entidad.setPosicion(pos);
        this.agregarEntidad(entidad);
    }

    /**
     * Agrega una entidad al mapa en su posición actual y la registra
     * en la lista correspondiente según su tipo.
     *
     * @param e entidad a agregar
     */
    
    public void agregarEntidad(Entidad e) {
        Posicion p = e.getPosicion();

        if (!dentroDelMapa(p)) return;

        matriz[p.getY()][p.getX()].agregarEntidad(e);

        if (e instanceof Helado helado) {
            if (!jugadores.contains(helado.getDueño())) {
                jugadores.add(helado.getDueño());
            }
        }
        else if (e instanceof Enemigo enemigo) enemigos.add(enemigo);
        else if (e instanceof Fruta fruta) frutas.add(fruta);
    }

    /**
     * Elimina una entidad del mapa y de las listas internas.
     *
     * @param e entidad a eliminar
     */
    
    public void eliminarEntidad(Entidad e) {
        Posicion p = e.getPosicion();
        if (dentroDelMapa(p)) {
            matriz[p.getY()][p.getX()].removerEntidad(e);
        }

        enemigos.remove(e);
        frutas.remove(e);
    }

    /**
     * Intenta mover una entidad en la dirección indicada.
     *
     * @param entidad entidad que se desea mover
     * @param dir     dirección del movimiento
     * @return true si el movimiento fue exitoso, false en caso contrario
     */
    
    public boolean moverEntidad(Entidad entidad, Direccion dir) {
        Posicion origen = entidad.getPosicion();
        Posicion destino = origen.desplazar(dir.getDX(), dir.getDY());

        if (!dentroDelMapa(destino)) return false;

        Celda celdaDestino = matriz[destino.getY()][destino.getX()];


        if (celdaDestino.esBloqueante()) return false;


        if (entidad instanceof Helado helado) {

            Jugador jugador = helado.getDueño();


            for (Entidad e : celdaDestino.getEntidades()) {

                
                if (e == entidad) continue;

                e.activar(jugador);

                if (jugador.estaMuerto()) return false;
            }
        }

        if (entidad instanceof Enemigo enemigo) {
            Helado heladoEnCelda = celdaDestino.getHelado();
            if (heladoEnCelda != null) {
                heladoEnCelda.getDueño().morir();
            }
        }

  
        matriz[origen.getY()][origen.getX()].removerEntidad(entidad);
        matriz[destino.getY()][destino.getX()].agregarEntidad(entidad);
        entidad.setPosicion(destino);

        return true;
    }

    /**
     * Actualiza todas las entidades del mapa en un ciclo de juego.
     *
     * @param mapa     referencia al mapa
     * @param jugadores lista de jugadores activos
     */
    
    public void actualizarTodasEntidades(Mapa mapa, List<Jugador> jugadores) {

        for (Jugador j : jugadores) {
            Helado h = j.getHelado();
            if (h != null && h.getIA() != null && j.getTipoJugador() != Jugador.TipoJugador.HUMANO) {
                h.actualizar(this);
            }
        }

        for (Enemigo enemigo : new ArrayList<>(enemigos)) {
            enemigo.actualizar(mapa, jugadores);	
        }

        for (Fruta fruta : new ArrayList<>(frutas)) {
            fruta.actualizar(mapa);
        }

        for (int y = 0; y < alto; y++) {
            for (int x = 0; x < ancho; x++) {
                Celda celda = matriz[y][x];
                for (Entidad e : new ArrayList<>(celda.getEntidades())) {
                    if (e instanceof Obstaculo obstaculo) {
                        obstaculo.actualizar(this);
                    }
                }
            }
        }
    }

    public void recolectarFrutasEn(Posicion posicion, Jugador jugador) {
        Celda celda = getCelda(posicion);
        if (celda == null) return;

        List<Fruta> frutas = celda.getFrutas();

        for (Fruta fruta : frutas) {
            if (!fruta.estaAtrapadaEnHielo() && !fruta.fueRecolectada()) {
                fruta.recolectar(jugador);
                celda.removerEntidad(fruta); // 🔥 AQUÍ DESAPARECE DEL MAPA
            }
        }
    }

    /**
     * Verifica si en la posición indicada existe un bloque de hielo.
     *
     * @param p posición a evaluar
     * @return true si la celda contiene un BloqueHielo, false en caso contrario
     */
    
    public boolean esHielo(Posicion p) {
        if (!dentroDelMapa(p)) return false;
        return matriz[p.getY()][p.getX()].contiene(BloqueHielo.class);
    }
    
    /**
     * Destruye el bloque de hielo ubicado en la posición indicada,
     * si existe uno.
     *
     * @param p posición donde se desea destruir el bloque
     */
    
    public void destruirBloque(Posicion p) {
        if (!dentroDelMapa(p)) return;
        BloqueHielo hielo = matriz[p.getY()][p.getX()].getBloqueHielo();
        if (hielo != null) {
            eliminarEntidad(hielo);
        }
    }

    /**
     * Retorna el ancho del mapa.
     *
     * @return número de columnas del mapa
     */
    
    public int getAncho() { 
        return ancho; 
    }
    
    /**
     * Retorna el alto del mapa.
     *
     * @return número de filas del mapa
     */
    
    public int getAlto() { 
        return alto; 
    }
    
    /**
     * Verifica si una posición es válida dentro de los límites del mapa.
     *
     * @param p posición a evaluar
     * @return true si la posición es válida
     */
    
    public boolean esPosicionValida(Posicion p) {
        return dentroDelMapa(p);
    }
    
    /**
     * Verifica si un movimiento desde una posición en una dirección
     * específica es válido.
     *
     * @param origen posición inicial
     * @param dir    dirección del movimiento
     * @return true si el movimiento es permitido
     */
    
    public boolean movimientoValido(Posicion origen, Direccion dir) {
        if (origen == null || dir == null) return false;
        Posicion destino = origen.desplazar(dir.getDX(), dir.getDY());
        if (!dentroDelMapa(destino)) return false;

        Celda celdaDestino = getCelda(destino);
        if (celdaDestino == null) return false;

        return !celdaDestino.esBloqueante();
    }

    /**
     * Verifica si la posición indicada contiene un obstáculo.
     *
     * @param p posición a evaluar
     * @return true si la celda es bloqueante
     */

    public boolean esObstaculo(Posicion p) {
        if (!dentroDelMapa(p)) return true;
        return matriz[p.getY()][p.getX()].esBloqueante();
    }
    
    /**
     * Calcula la distancia Manhattan entre dos posiciones.
     *
     * @param p1 primera posición
     * @param p2 segunda posición
     * @return distancia Manhattan entre ambas posiciones
     */
    
    public int distancia(Posicion p1, Posicion p2) {
        return Math.abs(p1.getX() - p2.getX()) + Math.abs(p1.getY() - p2.getY());
    }
    
    /**
     * Retorna el enemigo más cercano a una posición.
     *
     * @param p posición de referencia
     * @return enemigo más cercano o null si no hay enemigos
     */

    public Enemigo enemigoMasCercano(Posicion p) {
        if (enemigos.isEmpty()) return null;
        return enemigos.get(0); 
    }
    
    /**
     * Retorna la fruta más cercana a una posición.
     *
     * @param p posición de referencia
     * @return fruta más cercana o null si no hay frutas
     */
    
    public Fruta frutaMasCercana(Posicion p) {
        if (frutas.isEmpty()) return null;
        return frutas.get(0);
    }

    /**
     * Mueve una cereza a una posición aleatoria válida del mapa.
     *
     * @param cereza cereza que se desea mover
     */
    
    public void moverCereza(Cereza cereza) {

        Posicion origen = cereza.getPosicion();
        Posicion nuevaPos = null;

        int intentos = 0;
        int maxIntentos = 200; 

        while (intentos < maxIntentos) {
            intentos++;

            int x = (int)(Math.random() * ancho);
            int y = (int)(Math.random() * alto);
            Posicion candidata = new Posicion(x, y);

            if (candidata.equals(origen)) continue;

            if (!dentroDelMapa(candidata)) continue;

            Celda celda = getCelda(candidata);

            if (celda.contiene(BloqueHielo.class)) continue;

            if (celda.esBloqueante()) continue;

            if (!celda.getEnemigos().isEmpty()) continue;

            if (celda.getHelado() != null) continue;

            nuevaPos = candidata;
            break;
        }

        if (nuevaPos == null) return;

        matriz[origen.getY()][origen.getX()].removerEntidad(cereza);
        matriz[nuevaPos.getY()][nuevaPos.getX()].agregarEntidad(cereza);
        cereza.setPosicion(nuevaPos);
    }

    /**
     * Coloca una entidad aleatoriamente en el mapa.
     *
     * @param tipo clase de la entidad a colocar
     */

    public void colocarEntidadAleatoria(Class<?> tipo) {
    }
    
    /**
     * Reinicia completamente el mapa.
     * 
     * Elimina todas las entidades, limpia las listas internas
     * y vuelve a crear paredes y suelo.
     */
    
    public void reiniciar() {
        
        for (int y = 0; y < alto; y++) {
            for (int x = 0; x < ancho; x++) {
                matriz[y][x] = new Celda();
            }
        }

        enemigos.clear();
        frutas.clear();
        
        
        for (int y = 0; y < alto; y++) {
            for (int x = 0; x < ancho; x++) {
                Posicion p = new Posicion(x, y);
                if (x == 0 || x == ancho - 1 || y == 0 || y == alto - 1) {
                    agregarEntidad(new Pared(p), p);
                } else {
                    agregarEntidad(new Suelo(), p);
                }
            }
        }
    }


    /**
     * Crea bloques de hielo desde una posición en una dirección,
     * hasta encontrar un obstáculo no rompible.
     *
     * @param origen posición inicial
     * @param dir    dirección de creación
     */
    
    public void crearBloquesDesde(Posicion origen, Direccion dir) {
        Posicion p = origen.desplazar(dir.getDX(), dir.getDY());

        while (dentroDelMapa(p)) {

            Celda celda = getCelda(p);

            boolean bloque = celda.esBloqueante() && !esHielo(p);
            if (bloque) break;

            if (!esHielo(p)) {
                agregarEntidad(new BloqueHielo(new Posicion(p.getX(), p.getY())));
            }

            p = p.desplazar(dir.getDX(), dir.getDY());
        }
    }
    
    /**
     * Rompe los bloques de hielo desde una posición en una dirección
     * hasta encontrar un obstáculo no rompible.
     *
     * @param origen posición inicial
     * @param dir    dirección de ruptura
     */
    
    public void romperBloquesDesde(Posicion origen, Direccion dir) {
        Posicion p = origen.desplazar(dir.getDX(), dir.getDY());

        while (dentroDelMapa(p)) {

            Celda celda = getCelda(p);

            for (Entidad e : celda.getEntidades()) {
                if (e instanceof Obstaculo obst) {
                    if (!obst.esRompible()) return; 
                }
            }

            BloqueHielo hielo = celda.getBloqueHielo();
            if (hielo != null) {
                eliminarEntidad(hielo);
            }

            p = p.desplazar(dir.getDX(), dir.getDY());
        }
    }
    
    /**
     * Verifica si una posición se encuentra dentro de los límites del mapa.
     *
     * @param p posición a evaluar
     * @return true si la posición está dentro del mapa, false en caso contrario
     */
    
    public boolean dentroDelMapa(Posicion p) {
        return p.getX() >= 0 && p.getX() < ancho &&
               p.getY() >= 0 && p.getY() < alto;
    }

    /**
     * Retorna la celda correspondiente a una posición del mapa.
     *
     * @param p posición solicitada
     * @return la celda asociada a la posición o null si la posición no es válida
     */
    
    public Celda getCelda(Posicion p) {
        if (!dentroDelMapa(p)) return null;
        return matriz[p.getY()][p.getX()];
    }
    
    /**
     * Retorna la lista de jugadores presentes en el mapa.
     *
     * @return lista de jugadores
     */
    
    public List<Jugador> getJugadores() { return jugadores; }
    
    /**
     * Retorna la lista de frutas presentes en el mapa.
     *
     * @return lista de frutas
     */
    
    public List<Fruta> getFrutas() { return frutas; }
    
    /**
     * Retorna la lista de enemigos presentes en el mapa.
     *
     * @return lista de enemigos
     */
    
    public List<Enemigo> getEnemigos() {
        return enemigos;
    }

}