package Dominio;

/**
 * Inteligencia artificial para helados que prioriza huir de los enemigos.
 * Su comportamiento consiste en identificar el enemigo más cercano
 * y moverse en la dirección opuesta siempre que sea posible.
 */
public class FearfulIA implements IAHelado {

    /**
     * Calcula el movimiento del helado intentando alejarse
     * del enemigo más cercano.
     *
     * La IA evalúa primero la dirección con mayor distancia al enemigo
     * y luego una alternativa secundaria. Si ninguna es válida,
     * intenta cualquier movimiento posible.
     *
     * @param helado helado controlado por esta IA
     * @param mapa   mapa del juego
     * @return dirección de movimiento null si no puede moverse
     */
    @Override
    public Direccion calcularMovimiento(Helado helado, Mapa mapa) {

        Posicion pos = helado.getPosicion();
        Enemigo enemigo = mapa.enemigoMasCercano(pos);

        if (enemigo == null) {
            return Direccion.NORTE;
        }

        Posicion pe = enemigo.getPosicion();

        int dx = pos.getX() - pe.getX();
        int dy = pos.getY() - pe.getY();

        Direccion prioridad1;
        Direccion prioridad2;
        
        if (Math.abs(dx) > Math.abs(dy)) {
            prioridad1 = (dx > 0) ? Direccion.ESTE : Direccion.OESTE;
            prioridad2 = (dy > 0) ? Direccion.SUR : Direccion.NORTE;
        } else {
            prioridad1 = (dy > 0) ? Direccion.SUR : Direccion.NORTE;
            prioridad2 = (dx > 0) ? Direccion.ESTE : Direccion.OESTE;
        }

        if (mapa.movimientoValido(pos, prioridad1)) {
            return prioridad1;
        }

        if (mapa.movimientoValido(pos, prioridad2)) {
            return prioridad2;
        }

        for (Direccion d : Direccion.values()) {
            if (mapa.movimientoValido(pos, d)) {
                return d;
            }
        }

        return null;
    }
}
