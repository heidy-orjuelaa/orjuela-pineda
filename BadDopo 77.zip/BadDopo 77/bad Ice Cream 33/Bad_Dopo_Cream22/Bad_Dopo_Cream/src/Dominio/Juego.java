package Dominio;

import java.util.List;
import Dominio.Jugador.TipoJugador;
import java.io.Serializable;

/**
 * Clase que representa la lógica principal del juego.
 * 
 * Se encarga de administrar el mapa, los jugadores, el tiempo del nivel
 * y las condiciones de victoria o derrota.
 */

public class Juego implements Serializable {
    private static final long serialVersionUID = 1L;

    private int tiempoRestante;
    private Mapa mapa;
    private List<Jugador> jugadores;
    
    private static final int ANCHO_MAPA = 25;
    private static final int ALTO_MAPA = 18;

    private boolean terminado;
    private boolean victoria;
    private static final int TIEMPO_NIVEL = 180;

    
    private List<String> nivelFrutasSeleccionadas;
    private List<String> nivelEnemigosSeleccionados;
    private int oleadasFrutas;


    /**
     * Constructor del juego.
     * Inicializa el mapa, los jugadores y genera el suelo y las paredes
     * del nivel.
     *
     * @param jugadores lista de jugadores que participarán en el juego
     */
    
    public Juego(List<Jugador> jugadores) {
        this.jugadores = jugadores;
        this.mapa = new Mapa(ANCHO_MAPA, ALTO_MAPA); 
        this.terminado = false;
        this.victoria = false;
        this.tiempoRestante = TIEMPO_NIVEL;
     
        
        for (int y = 0; y < mapa.getAlto(); y++) {
            for (int x = 0; x < mapa.getAncho(); x++) {
                Posicion p = new Posicion(x, y);
                mapa.agregarEntidad(new Suelo(), p);
                if (x == 0 || x == mapa.getAncho() - 1 || y == 0 || y == mapa.getAlto() - 1) {
                    mapa.agregarEntidad(new Pared(p), p);
                }
            }
        }
    }
    
    /**
     * Configura los elementos del nivel actual.
     *
     * @param frutas lista de tipos de frutas
     * @param enemigos lista de tipos de enemigos
     * @param oleadas número de oleadas de frutas
     */

    public void configurarNivel(List<String> frutas, List<String> enemigos, int oleadas) {
        this.nivelFrutasSeleccionadas = frutas;
        this.nivelEnemigosSeleccionados = enemigos;
        this.oleadasFrutas = oleadas;
    }


    /**
     * Inicia o reinicia el nivel.
     * Coloca jugadores, enemigos y frutas en posiciones aleatorias válidas
     * y reinicia el estado del juego.
     */
    
    public void iniciarNivel() {
        
        mapa.reiniciar();

        
        for (Jugador j : jugadores) {
            Posicion pos;
            do {
                int x = (int) (Math.random() * mapa.getAncho());
                int y = (int) (Math.random() * mapa.getAlto());
                pos = new Posicion(x, y);
            } while (mapa.getCelda(pos).esBloqueante() || mapa.getCelda(pos).getHelado() != null);

            
            Helado helado;
            if (j.getTipoJugador() == TipoJugador.HUMANO) {
                helado = FactoryHelados.crearHelado(j, pos, j.getSaborElegido()); 
            } else {
                helado = FactoryHelados.crearHelado(j, pos); 
            }
            

            j.asignarHelado(helado);
            mapa.agregarEntidad(helado, pos);
        }

        
        for (String tipoEnemigo : nivelEnemigosSeleccionados) {
            int cantidad = 1; 
            for (int i = 0; i < cantidad; i++) {
                Posicion pos;
                do {
                    int x = (int) (Math.random() * mapa.getAncho());
                    int y = (int) (Math.random() * mapa.getAlto());
                    pos = new Posicion(x, y);
                } while (mapa.getCelda(pos).esBloqueante() || mapa.getCelda(pos).getEnemigos().size() > 0);

                Enemigo enemigo = FactoryEnemigos.crearEnemigo(tipoEnemigo, pos); 
                mapa.agregarEntidad(enemigo, pos);
            }
        }

        
        for (int oleada = 0; oleada < oleadasFrutas; oleada++) {
            for (String tipoFruta : nivelFrutasSeleccionadas) {
                Posicion pos;
                do {
                    int x = (int) (Math.random() * mapa.getAncho());
                    int y = (int) (Math.random() * mapa.getAlto());
                    pos = new Posicion(x, y);
                } while (mapa.getCelda(pos).esBloqueante() || mapa.getCelda(pos).getFrutas().size() > 0);

                Fruta fruta = FactoryFrutas.crearFruta(tipoFruta, pos); 
                mapa.agregarEntidad(fruta, pos);
            }
        }

        
        terminado = false;
        victoria = false;
        tiempoRestante = TIEMPO_NIVEL;
    }

    /**
     * Mueve un jugador humano en la dirección indicada.
     *
     * @param jugador jugador humano
     * @param dir dirección de movimiento
     */

    public void moverJugadorHumano(Jugador jugador, Direccion dir) {
        if (terminado || jugador.estaMuerto()) return;

        jugador.getHelado().setDireccionActual(dir);

        mapa.moverEntidad(jugador.getHelado(), dir);

        mapa.recolectarFrutasEn(
            jugador.getHelado().getPosicion(),
            jugador
        );

        verificarEstado();
    }

    /**
     * Permite a un jugador humano crear bloques de hielo.
     *
     * @param jugador jugador humano
     */
    
    public void crearBloquesHieloHumano(Jugador jugador) {
        jugador.crearHielo(mapa);
    }

    /**
     * Permite a un jugador humano romper bloques de hielo.
     *
     * @param jugador jugador humano
     */
    
    public void romperBloquesHieloHumano(Jugador jugador) {
        jugador.romperHielo(mapa);
    }

    /**
     * Actualiza la lógica del juego, incluyendo IA, entidades y tiempo.
     */
    
    public void actualizarLogica() {
        if (terminado) return;

        for (Jugador j : jugadores) {
            if (j.getTipoJugador() != TipoJugador.HUMANO && !j.estaMuerto()) {
                Helado h = j.getHelado();
                if (h != null && h.getIA() != null) {
                    Direccion dir = h.getIA().calcularMovimiento(h, mapa);
                    if (dir != null) {
                        mapa.moverEntidad(h, dir);
                    }
                }
            }
        }

        mapa.actualizarTodasEntidades(mapa, jugadores);

        disminuirTiempo(1);

        verificarEstado();
    }

    /**
     * Verifica las condiciones de victoria o derrota del juego.
     */
    
    private void verificarEstado() {
        boolean todosMuertos = jugadores.stream()
                .filter(j -> j.getTipoJugador() == TipoJugador.HUMANO)
                .allMatch(Jugador::estaMuerto);

        if (todosMuertos || tiempoRestante <= 0) {
            terminarJuego(false);
            return;
        }

        if (mapa.getFrutas().isEmpty()) {
            terminarJuego(true);
        }
    }

    /**
     * Finaliza el juego indicando si hubo victoria o derrota.
     *
     * @param victoria true si el jugador ganó, false si perdió
     */
    
    private void terminarJuego(boolean victoria) {
        this.terminado = true;
        this.victoria = victoria;
    }

    /** @return tiempo restante del nivel */
    
    public int getTiempoRestante() {
        return tiempoRestante;
    }

    /**
     * Reduce el tiempo restante del nivel.
     *
     * @param segundos cantidad de segundos a disminuir
     */
    
    public void disminuirTiempo(int segundos) {
        tiempoRestante -= segundos;
        if (tiempoRestante < 0) tiempoRestante = 0;
        if (tiempoRestante == 0) {
            terminarJuego(false);
        }
    }

    /** @return true si el juego terminó */
    
    public boolean estaTerminado() {
        return terminado;
    }

    /** @return true si el jugador ganó el nivel */
    
    public boolean hayVictoria() {
        return victoria;
    }

    /** @return mapa del juego */
    
    public Mapa getMapa() {
        return mapa;
    }

    /** @return lista de jugadores */
    
    public List<Jugador> getJugadores() {
        return jugadores;
    }
    
    public void setTiempoRestante(int tiempoRestante) {
        this.tiempoRestante = tiempoRestante;
    }
}
