package Dominio;
import java.io.Serializable;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase de utilidad responsable de la lectura y escritura
 * de los puntajes de los jugadores en un archivo persistente .
 */

public class PersistenciaPuntajes implements Serializable {
    private static final long serialVersionUID = 1L; 

    private static final String ARCHIVO = "puntajes.csv";

    /**
     * Guarda el puntaje de un jugador en el archivo.
     *
     * @param nombreJugador el nombre del jugador.
     * @param puntaje el puntaje obtenido.
     */
    public static void guardarPuntaje(String nombreJugador, int puntaje) {
        try (FileWriter fw = new FileWriter(ARCHIVO, true)) {
            fw.write(nombreJugador + ";" + puntaje + "\n");
        } catch (IOException e) {
            LoggerError.log("Error guardando puntaje: " + e.getMessage());
        }
    }

    /**
     * Carga todos los puntajes registrados en el archivo.
     * * Cada elemento de la lista devuelta es una línea (un registro de puntaje) del archivo.
     */
    public static List<String> cargarPuntajes() {
        List<String> lista = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lista.add(linea);
            }
        } catch (IOException e) {
            LoggerError.log("Error leyendo puntajes: " + e.getMessage());
        }

        return lista;
    }
}