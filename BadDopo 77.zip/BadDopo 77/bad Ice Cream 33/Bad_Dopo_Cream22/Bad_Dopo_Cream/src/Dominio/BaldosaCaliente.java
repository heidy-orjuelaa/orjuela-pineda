package Dominio;
import java.io.Serializable;
/**
 * Obstáculo que representa una baldosa caliente.
 * Cualquier jugador que la pise muere inmediatamente.
 * Además, destruye bloques de hielo que se formen sobre ella.
 */
public class BaldosaCaliente extends Obstaculo implements Serializable {
    private static final long serialVersionUID = 1L; 

    /**
     * Crea una baldosa caliente en la posición indicada.
     */
	
    public BaldosaCaliente(Posicion posicion) {
        super(posicion);
    }

    /**
     * Se activa cuando un jugador entra en contacto con la baldosa.
     * El jugador muere al instante.
     */
    
    @Override
    public void activar(Jugador jugador) {
        jugador.morir();
    }

    /**
     * Actualiza el estado de la baldosa.
     * Si hay un bloque de hielo en su posición, lo destruye.
     */
    
    @Override
    public void actualizar(Mapa mapa) {
        if (mapa.esHielo(posicion)) {
            mapa.destruirBloque(posicion);
        }
    }

    /**
     * Devuelve el tipo identificador de la entidad.
     */
    
    @Override
    public String getTipo() {
        return "BaldosaCaliente";
    }
}
