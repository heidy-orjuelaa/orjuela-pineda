package Dominio;

import java.util.List;

/**
 * Interfaz que define el comportamiento de la inteligencia artificial
 * de los enemigos del juego.
 * 
 * Cada implementación decide la dirección de movimiento del enemigo
 * según el estado del mapa y los jugadores.
 */

public interface IAEnemigo {
    Direccion calcularDireccion(Enemigo enemigo, Mapa mapa, List<Jugador> jugadores);
    
}
 
 







