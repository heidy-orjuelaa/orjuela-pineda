package Dominio;
import java.io.Serializable;
import java.util.List;

/**
 * Representa la entidad Enemigo "Narval".
 * La IA del Narval tiene dos estados: Normal (buscando alineación) y Embestida.
 * Solo ataca con una embestida si está alineado horizontal o verticalmente con el Helado del jugador.
 */

public class Narval extends Enemigo implements Serializable {
    private static final long serialVersionUID = 1L; 

    private transient Runnable comportamientoIA;
    private boolean enEmbestida = false;
    private Direccion direccionEmbestida = Direccion.ESTE;

    /**
     * Constructor para crear un Narval en la posición especificada.
     * Inicializa la IA interna del Enemigo para usar el método local calcular direecion.
     *
     * @param posicion posición inicial del Narval
     */
    
    public Narval(Posicion posicion) {
        super(posicion, null);
        this.ia = this::calcularDireccion;
    }

    /**
     * Lógica de Inteligencia Artificial (IA) para determinar el próximo movimiento del Narval.
     * @param e El Narval (Entidad Enemigo) que se está moviendo.
     * @param mapa El mapa del juego para verificar obstáculos.
     * @param jugadores La lista de jugadores activos (solo usa el primero).
     * @return La direccion del movimiento (embestida), o null si está esperando alineación o bloqueado.
     */
    private Direccion calcularDireccion(Enemigo e, Mapa mapa, List<Jugador> jugadores) { 
        
        Jugador jugador = jugadores.isEmpty() ? null : jugadores.get(0);
        if (jugador == null || jugador.estaMuerto()) return null; 
        
        Posicion posJ = jugador.getHelado().getPosicion(); 
        if (enEmbestida) {
            Posicion sig = posicion.desplazar(
                direccionEmbestida.getDX(),
                direccionEmbestida.getDY()
            );

            if (!mapa.dentroDelMapa(sig) ||
                mapa.getCelda(sig).esObstaculoFijo()) { 
                
                enEmbestida = false;
                return null; 
            }

            if (mapa.esHielo(sig)) mapa.destruirBloque(sig);

            return direccionEmbestida;
        }


        if (posicion.getX() == posJ.getX()) {
            enEmbestida = true;
            direccionEmbestida = (posJ.getY() > posicion.getY()) ? Direccion.SUR : Direccion.NORTE;
            return direccionEmbestida;
        }

        if (posicion.getY() == posJ.getY()) {
            enEmbestida = true;
            direccionEmbestida = (posJ.getX() > posicion.getX()) ? Direccion.ESTE : Direccion.OESTE;
            return direccionEmbestida; 
        }

        return null; 
    }

    /**
     * Retorna la cadena de identificación del tipo de entidad.
     * @return "Narval"
     */
    
    @Override
    public String getTipo() {
        return "Narval";
    }
}