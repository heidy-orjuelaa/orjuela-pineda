package Dominio;
import java.io.Serializable;
/**
 * Representa una Pared, el obstáculo más básico y permanente en el mapa.
 * * Una Pared siempre es bloqueante y no puede ser destruida o activada.
 */

public class Pared extends Obstaculo implements Serializable {
    private static final long serialVersionUID = 1L; 

    /**
     * Constructor para crear una Pared en la posición dada.
     *
     * @param pos la posición inicial de la Pared.
     */
    public Pared(Posicion pos) { 
        super(pos); 
    }

    /**
     * Indica que la Pared siempre bloquea el movimiento.
     */
    
    @Override 
    public boolean esBloqueante() { 
        return true; 
    }

    /**
     * Retorna la cadena de identificación del tipo de entidad.
     */
    
    @Override 
    public String getTipo() { 
        return "Pared"; 
    }
    
    /**
     * Define la acción cuando un jugador intenta interactuar con la Pared.
     * No tiene ningún efecto, ya que es un obstáculo fijo e inerte.
     *
     * @param jugador El jugador que interactúa.
     */
    
	@Override
	public void activar(Jugador jugador) {
	}
}