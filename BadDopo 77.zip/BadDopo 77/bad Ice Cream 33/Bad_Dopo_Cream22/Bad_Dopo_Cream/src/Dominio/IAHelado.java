package Dominio;

/**
 * Interfaz que define el comportamiento de la inteligencia artificial
 * de los helados controlados por la máquina.
 * 
 * Permite calcular el movimiento del helado según el estado del mapa.
 */

public interface IAHelado {

    Direccion calcularMovimiento(Helado helado, Mapa mapa);
}
