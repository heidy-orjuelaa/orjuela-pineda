package Dominio;
import java.io.Serializable;
/**
 * Representa una coordenada inmutable (X, Y) dentro del mapa del juego.
 * Una Posicion se utiliza para ubicar a las Entidades y Obstaculos.
 */
public class Posicion implements Serializable {
    private static final long serialVersionUID = 1L; 

    private final int x;
    private final int y;

    /**
     * Constructor para inicializar una nueva Posicion.
     *
     * @param x la coordenada X.
     * @param y la coordenada Y.
     */
    
    public Posicion(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    /**
     * Crea una nueva Posicion que resulta del desplazamiento.
     * La instancia actual no se modifica.
     *
     * @param dx el delta de movimiento en el eje X.
     * @param dy el delta de movimiento en el eje Y.
     * @return una nueva Posicion con las coordenadas desplazadas.
     */
    
    public Posicion desplazar(int dx, int dy) {
        return new Posicion(x + dx, y + dy);
    }

    /**
     * Compara si esta Posicion es igual a otro objeto.
     * Dos Posicion son iguales si tienen las mismas coordenadas X e Y.
     *
     * @param obj el objeto a comparar.
     * @return true si las coordenadas son idénticas.
     */
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Posicion)) return false;

        Posicion other = (Posicion) obj;
        return this.x == other.x && this.y == other.y;
    }

    /**
     * Genera un código hash basado en las coordenadas X e Y.
     * @return el código hash.
     */
    
    @Override
    public int hashCode() {
        return 31 * x + y;
    }

    /**
     * Retorna la representación en cadena de la posición.
     * @return la cadena en formato "(x, y)".
     */
    
    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}