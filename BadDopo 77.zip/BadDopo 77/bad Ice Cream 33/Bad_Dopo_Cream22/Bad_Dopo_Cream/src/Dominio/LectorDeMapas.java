package Dominio;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase de utilidad (estática) responsable de la lectura de archivos de texto
 * que representan la estructura de un mapa del juego.
 */
public class LectorDeMapas {

    /**
     * Carga las líneas de un archivo de texto para representar el mapa.
     */
	
    public static List<String> cargarMapa(String archivo) {
        List<String> lineas = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lineas.add(linea);
            }
        } catch (IOException e) {
            LoggerError.log("Error cargando mapa " + archivo + ": " + e.getMessage());
        }

        return lineas;
    }
}