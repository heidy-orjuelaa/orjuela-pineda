package Dominio;
import java.io.Serializable;
/**
 * Representa un Plátano, un tipo de Fruta coleccionable en el mapa.
 * * Los Plátanos otorgan 100 puntos al ser activados por un jugador.
 */

public class Platano extends Fruta implements Serializable {
    private static final long serialVersionUID = 1L; 

    /**
     * Constructor para crear un Plátano en la posición dada, inicializando su valor.
     *
     * @param posicion la posición inicial del Plátano.
     */
	
    public Platano(Posicion posicion) {
        super(posicion, 100); 
    }

    /**
     * Método llamado en cada ciclo para actualizar el estado del Plátano.
     * Actualmente no realiza ninguna acción ya que es una fruta estática.
     *
     * @param mapa El mapa actual del juego.
     */
    
    @Override
    public void actualizar(Mapa mapa) {
    }

    /**
     * Retorna la cadena de identificación del tipo de entidad.
     * @return "Platano".
     */
    
    @Override
    public String getTipo() {
        return "Platano";
    }
}