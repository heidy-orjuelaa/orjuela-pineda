package Dominio;

/**
 * Fábrica responsable de crear obstáculos del juego.
 * Encapsula la lógica de construcción de cada tipo de obstáculo
 * a partir de un identificador de texto.
 */
public class FactoryObstaculos {

    /**
     * Crea un obstáculo del tipo indicado en la posición dada.
     *
     * @param tipo identificador del obstáculo (por ejemplo: "pared", "hielo")
     * @param pos  posición donde se ubicará el obstáculo
     * @return obstáculo creado
     * @throws IllegalArgumentException si el tipo no es reconocido
     */
    public static Obstaculo crearObstaculo(String tipo, Posicion pos) {
        tipo = tipo.toLowerCase();

        return switch (tipo) {
            case "pared" -> new Pared(pos);
            case "hielo" -> new BloqueHielo(pos);
            default -> throw new IllegalArgumentException("Obstáculo desconocido: " + tipo);
        };
    }
}
