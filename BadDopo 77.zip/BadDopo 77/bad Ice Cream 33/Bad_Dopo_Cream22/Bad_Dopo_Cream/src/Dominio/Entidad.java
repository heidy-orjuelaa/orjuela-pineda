package Dominio;
import java.io.Serializable;

/**
 * Representa cualquier elemento que puede existir dentro del mapa del juego.
 * Todas las entidades tienen una posición y pueden interactuar con el entorno
 * y con los jugadores.
 */

public abstract class Entidad implements Serializable {
    private static final long serialVersionUID = 1L; 

    protected Posicion posicion;

    /**
     * Crea una entidad en una posición determinada.
     */
    
    public Entidad(Posicion posicion) {
        this.posicion = posicion;
    }

    /**
     * Retorna la posición actual de la entidad.
     */
    
    public Posicion getPosicion() {
        return posicion;
    }

    /**
     * Actualiza la posición de la entidad.
     */
    
    public void setPosicion(Posicion nuevaPosicion) {
        this.posicion = nuevaPosicion;
    }

    /**
     * Indica si la entidad bloquea el movimiento sobre la celda
     * en la que se encuentra.
     */
    
    public abstract boolean esBloqueante();

    /**
     * Actualiza el estado interno de la entidad.
     */
    
    public void actualizar(Mapa mapa) {
    }

    /**
     * Permite a la entidad interactuar con el mapa si su comportamiento
     * lo requiere. 
     */
    public void interactuarConMapa(Mapa mapa) {
    }

    /**
     * Retorna el tipo de entidad como una cadena identificadora.
     */
    
    public abstract String getTipo();

    /**
     * Acción que se ejecuta cuando un jugador interactúa con la entidad.
     */
    
    public abstract void activar(Jugador jugador);
}
