package Dominio;
import java.io.Serializable;
import java.util.List;

/**
 * Representa un enemigo dentro del juego.
 * Un enemigo es una entidad bloqueante que se mueve de forma autónoma
 * utilizando una estrategia de inteligencia artificial.
 */

public abstract class Enemigo extends Entidad implements Serializable {
    private static final long serialVersionUID = 1L; 

    protected IAEnemigo ia;

    /**
     * Crea un enemigo en una posición determinada con una IA asociada.
     */
    
    public Enemigo(Posicion posicion, IAEnemigo ia) {
        super(posicion);
        this.ia = ia;
    }

    /**
     * Los enemigos siempre bloquean el movimiento de otras entidades.
     */
    
    @Override
    public boolean esBloqueante() {
        return true;
    }

    /**
     * Actualiza el comportamiento del enemigo en función del estado del mapa
     * y de los jugadores presentes. La dirección de movimiento es determinada
     * por la IA asociada.
     */
    
    public void actualizar(Mapa mapa, List<Jugador> jugadores) {

        if (ia == null) {
            return;
        }

        Direccion dir;
        try {
            dir = ia.calcularDireccion(this, mapa, jugadores);
        } catch (Exception ex) {
            return;
        }

        if (dir != null) {
            mapa.moverEntidad(this, dir);
        }
    }

    /**
     * Actualización del enemigo sin recibir explícitamente la lista de jugadores.
     * Se utiliza para mantener compatibilidad con el ciclo de actualización del mapa.
     */
    
    @Override
    public void actualizar(Mapa mapa) {
        List<Jugador> jugadores = mapa.getJugadores();
        actualizar(mapa, jugadores);
    }

    /**
     * Acción que se ejecuta cuando un jugador entra en contacto con el enemigo.
     * Por defecto, el jugador muere.
     */
    
    @Override
    public void activar(Jugador jugador) {
        jugador.morir();
    }
}
