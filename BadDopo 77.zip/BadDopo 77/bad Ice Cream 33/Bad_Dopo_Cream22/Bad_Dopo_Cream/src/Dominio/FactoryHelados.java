package Dominio;

import java.util.Random;

/**
 * Fábrica encargada de crear instancias de Helado.
 * Centraliza la asignación de IA y el sabor según el tipo de jugador,
 * evitando que esta lógica se repita en otras partes del sistema.
 */

public class FactoryHelados {

    private static final String[] SABORES_IA = {"Vainilla", "Fresa", "Chocolate"};
    private static final Random random = new Random();

    /**
     * Crea un helado para un jugador en la posición indicada.
     * El tipo de IA y el sabor se asignan automáticamente
     * según el tipo de jugador.
     *
     * @param jugador jugador dueño del helado
     * @param pos     posición inicial en el mapa
     * @return helado creado y asignado al jugador
     */
    public static Helado crearHelado(Jugador jugador, Posicion pos) {
        IAHelado ia = null;
        String sabor;

        switch (jugador.getTipoJugador()) {
            case HUMANO -> ia = null;
            case MAQUINA_HUNGRY -> ia = new HungryIA();
            case MAQUINA_FEARFUL -> ia = new FearfulIA();
            case MAQUINA_EXPERT -> ia = new ExpertIA();
        }

        if (jugador.getTipoJugador() == Jugador.TipoJugador.HUMANO) {
            sabor = "Vainilla";
        } else {
            sabor = SABORES_IA[random.nextInt(SABORES_IA.length)];
        }

        Helado helado = new Helado(pos, ia, jugador, sabor);
        jugador.asignarHelado(helado);
        return helado;
    }

    /**
     * Crea un helado para un jugador humano con un sabor elegido.
     * El tipo de IA se asigna automáticamente según el tipo de jugador.
     *
     * @param jugador       jugador dueño del helado
     * @param pos           posición inicial en el mapa
     * @param saborElegido  sabor seleccionado por el jugador
     * @return helado creado y asignado al jugador
     */
    public static Helado crearHelado(Jugador jugador, Posicion pos, String saborElegido) {
        IAHelado ia = null;

        switch (jugador.getTipoJugador()) {
            case HUMANO -> ia = null;
            case MAQUINA_HUNGRY -> ia = new HungryIA();
            case MAQUINA_FEARFUL -> ia = new FearfulIA();
            case MAQUINA_EXPERT -> ia = new ExpertIA();
        }

        Helado helado = new Helado(pos, ia, jugador, saborElegido);
        jugador.asignarHelado(helado);
        return helado;
    }
}
