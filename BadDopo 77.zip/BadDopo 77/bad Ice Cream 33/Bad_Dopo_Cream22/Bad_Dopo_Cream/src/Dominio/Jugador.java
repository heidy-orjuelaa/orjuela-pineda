package Dominio;
import java.io.Serializable;


/**
 * Representa a un jugador en el juego. Puede ser controlado por un humano
 * o por una de las tres implementaciones de Inteligencia Artificial (IA).
 * Cada jugador está asociado a un Helado y tiene un puntaje.
 */
public class Jugador extends Entidad implements Serializable {
    private static final long serialVersionUID = 1L;


    private final String nombre;
    private final TipoJugador tipo;
    private Helado helado; 
    private int puntajeTotal = 0;
    private boolean estaMuerto = false;
    private IAHelado ia; 
    private String saborElegido; 
    public enum TipoJugador {
        HUMANO,
        MAQUINA_HUNGRY,
        MAQUINA_FEARFUL,
        MAQUINA_EXPERT
    }

    
    /**
     * Constructor usado cuando el sabor de Helado es especificado.
     * Inicializa la IA basada en el TipoJugador.
     *
     * @param nombre nombre del jugador
     * @param tipo tipo de jugador (HUMANO o MAQUINA)
     * @param saborElegido el sabor deseado para el Helado asociado
     */
    public Jugador(String nombre, TipoJugador tipo, String saborElegido) {
        super(null);
        this.nombre = nombre;
        this.tipo = tipo;
        this.saborElegido = saborElegido;

        switch (tipo) {
            case MAQUINA_HUNGRY -> this.ia = new HungryIA();
            case MAQUINA_FEARFUL -> this.ia = new FearfulIA();
            case MAQUINA_EXPERT -> this.ia = new ExpertIA();
            default -> this.ia = null; 
        }
    }

   
    /**
     * Constructor usado cuando el sabor de Helado no es especificado (se asigna aleatoriamente).
     * Inicializa la IA basada en el TipoJugador.
     *
     * @param nombre nombre del jugador
     * @param tipo tipo de jugador (HUMANO o MAQUINA)
     */
    public Jugador(String nombre, TipoJugador tipo) {
        super(null);
        this.nombre = nombre;
        this.tipo = tipo;
        this.saborElegido = asignarSaborIA(); 

        switch (tipo) {
            case MAQUINA_HUNGRY -> this.ia = new HungryIA();
            case MAQUINA_FEARFUL -> this.ia = new FearfulIA();
            case MAQUINA_EXPERT -> this.ia = new ExpertIA();
            default -> this.ia = null; 
        }
    }

    /** Asigna un sabor de Helado aleatorio si el jugador es MAQUINA. */
    
    private String asignarSaborIA() {
        String[] sabores = {"Vainilla", "Fresa", "Chocolate"};
        int idx = (int) (Math.random() * sabores.length);
        return sabores[idx];
    }

    /**
     * Retorna el sabor de Helado asociado.
     * @return el sabor elegido
     */
    
    public String getSaborElegido() {
        return saborElegido;
    }

    /**
     * Incrementa el puntaje total del jugador.
     * @param puntos cantidad de puntos a sumar
     */
    
    public void sumarPuntos(int puntos) {
        this.puntajeTotal += puntos;
    }

    /**
     * Marca al jugador como muerto.
     */
    
    public void morir() {
        this.estaMuerto = true;
    }

    /**
     * Marca al jugador como vivo.
     */
    
    public void revivir() {
        this.estaMuerto = false;
    }

    /**
     * Indica si el jugador está actualmente fuera de juego.
     * @return true si está muerto
     */
    
    public boolean estaMuerto() {
        return estaMuerto;
    }

    /**
     * Intenta crear bloques de hielo en la dirección actual del Helado.
     * Solo funciona si el jugador tiene un Helado asignado.
     * @param mapa el mapa del juego para ejecutar la acción
     */
    
    public void crearHielo(Mapa mapa) {
        if (helado != null) mapa.crearBloquesDesde(helado.getPosicion(), helado.getDireccionActual());
    }

    /**
     * Intenta romper bloques de hielo en la dirección actual del Helado.
     * Solo funciona si el jugador tiene un Helado asignado.
     * @param mapa el mapa del juego para ejecutar la acción
     */
    
    public void romperHielo(Mapa mapa) {
        if (helado != null) mapa.romperBloquesDesde(helado.getPosicion(), helado.getDireccionActual());
    }

    /**
     * Actualiza el estado del jugador.
     * Si es una MAQUINA, usa la IA para calcular el movimiento del Helado
     * asociado y lo ejecuta si el jugador está vivo.
     * @param mapa el mapa del juego
     */
    
    public void actualizar(Mapa mapa) {
        if (tipo != TipoJugador.HUMANO && !estaMuerto && helado != null) {
            Direccion mov = ia.calcularMovimiento(helado, mapa);
            if (mov != null) mapa.moverEntidad(helado, mov);
        }
    }

    /**
     * Retorna el puntaje acumulado.
     * @return el puntaje total
     */
    
    public int getPuntajeTotal() { 
        return puntajeTotal; 
    }

    /**
     * Asocia un Helado a este jugador.
     * @param helado el Helado a asignar
     */
    
    public void asignarHelado(Helado helado) { 
        this.helado = helado;
    }

    /**
     * Retorna el Helado que controla este jugador.
     * @return el Helado asociado
     */
    
    public Helado getHelado() { 
        return helado;
    }

    /**
     * Retorna el tipo de control (Humano o IA).
     * @return el TipoJugador
     */
    
    public TipoJugador getTipoJugador() {  
        return tipo;
    }

    /**
     * Retorna el nombre del jugador.
     * @return el nombre
     */
    
    public String getNombre() {
        return nombre;
    }

    /**
     * Indica que el Jugador no es una entidad que bloquee el paso.
     * @return false
     */
    
    @Override
    public boolean esBloqueante() {
        return false;
    }

    /**
     * Define la acción al ser activado (tocado) por otro jugador.
     * Actualmente no tiene efecto.
     * @param jugador el jugador que activa
     */
    
    @Override
    public void activar(Jugador jugador) {}

    /**
     * Retorna la cadena de identificación del tipo de entidad.
     * @return "Jugador"
     */
    
    @Override
    public String getTipo() {
        return "Jugador";
    }
}