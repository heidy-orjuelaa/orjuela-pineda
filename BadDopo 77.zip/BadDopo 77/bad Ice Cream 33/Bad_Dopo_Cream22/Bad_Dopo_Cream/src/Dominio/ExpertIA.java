package Dominio;
import java.io.Serializable;

/**
 * Implementación avanzada de IA para el helado.
 * Combina distintos comportamientos según la situación del entorno.
 *
 * Si existe un enemigo cercano, prioriza huir.
 * 
 */

public class ExpertIA implements IAHelado {

    private HungryIA hungry = new HungryIA();
    private FearfulIA fearful = new FearfulIA();

    /**
     * Decide el movimiento del helado en función del peligro cercano.
     * Si un enemigo se encuentra a corta distancia, se intenta huir;
     * de lo contrario, se busca avanzar hacia objetivos beneficiosos.
     */
    
    @Override
    public Direccion calcularMovimiento(Helado helado, Mapa mapa) {

        Posicion pos = helado.getPosicion();
        Enemigo cercano = mapa.enemigoMasCercano(pos);

        boolean peligro =
                cercano != null &&
                mapa.distancia(pos, cercano.getPosicion()) <= 3;

        if (peligro) {
            return fearful.calcularMovimiento(helado, mapa);
        }

        return hungry.calcularMovimiento(helado, mapa);
    }
}
