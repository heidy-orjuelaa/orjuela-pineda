package Dominio;
import java.io.Serializable;
/**
 * Clase base abstracta para todas las entidades en el mapa que representan
 * barreras, peligros o elementos interactivos que no son móviles.
 */

public abstract class Obstaculo extends Entidad implements Serializable {
    private static final long serialVersionUID = 1L; 

    /**
     * Constructor para inicializar el Obstaculo en una posición dada.
     *
     * @param posicion la posición inicial del obstáculo.
     */
	
    public Obstaculo(Posicion posicion) {
        super(posicion);
    }

    /**
     * Indica si este obstáculo bloquea el paso a otras entidades.
     */
    
    @Override
    public boolean esBloqueante() {
        return true; 
    }

    /**
     * Define el efecto que ocurre cuando un jugador entra en contacto con el obstáculo.
     * * Las subclases deben implementar la lógica específica 
     *
     * @param jugador jugador que activa o interactúa con el obstáculo.
     */
    
    public abstract void activar(Jugador jugador);

    /**
     * Define la acción a ejecutar cuando un Jugador intenta romper este obstáculo.
     *
     * @param jugador El jugador que intenta romper el obstáculo.
     * @param mapa El mapa actual del juego.
     */
    
    public void serRoto(Jugador jugador, Mapa mapa) {
    }

    /**
     * Método llamado en cada ciclo para actualizar el estado del obstáculo.
     * Las subclases deben implementar la lógica de actualización temporal si es necesaria.
     *
     * @param mapa El mapa actual del juego.
     */
    
    @Override
    public void actualizar(Mapa mapa) {
    }

    /**
     * Indica si el obstáculo puede ser destruido o eliminado por una acción del jugador 
     * @return false por defecto. Las subclases rompibles deben sobrescribirlo.
     */
    
    public boolean esRompible() {
        return false;
    }
}