package Dominio;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;
/**
 * Representa una celda del mapa.
 * Una celda puede contener múltiples entidades al mismo tiempo
 *
 * Es responsable de consultar qué tipo de entidades contiene
 * y si alguna de ellas bloquea el paso.
 */
public class Celda implements Serializable {
    private static final long serialVersionUID = 1L; 

    private List<Entidad> entidades = new ArrayList<>();

    /**
     * Agrega una entidad a la celda.
     */
    
    public void agregarEntidad(Entidad e) {
        entidades.add(e);
    }

    /**
     * Remueve una entidad de la celda.
     */
    
    public void removerEntidad(Entidad e) {
        entidades.remove(e);
    }

    /**
     * Devuelve todas las entidades que se encuentran en la celda.
     */
    
    public List<Entidad> getEntidades() {
        return entidades;
    }

    /**
     * Devuelve el bloque de hielo presente en la celda, si existe.
     * Si no hay hielo, retorna null.
     */
    
    public BloqueHielo getBloqueHielo() {
        for (Entidad e : entidades) {
            if (e instanceof BloqueHielo) {
                return (BloqueHielo) e;
            }
        }
        return null;
    }

    /**
     * Devuelve la lista de frutas presentes en la celda.
     */
    
    public List<Fruta> getFrutas() {
        List<Fruta> lista = new ArrayList<>();
        for (Entidad e : entidades) {
            if (e instanceof Fruta) {
                lista.add((Fruta) e);
            }
        }
        return lista;
    }

    /**
     * Indica si la celda contiene algún obstáculo fijo.
     */
    
    public boolean esObstaculoFijo() {
        for (Entidad e : entidades) {
            if (e instanceof Obstaculo) {
                return true;
            }
        }
        return false;
    }

    /**
     * Indica si la celda contiene una entidad del tipo indicado.
     */
    
    public boolean contiene(Class<?> tipo) {
        for (Entidad e : entidades) {
            if (tipo.isInstance(e)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Indica si la celda bloquea el paso.
     * Una celda es bloqueante si alguna de sus entidades lo es.
     */
    
    public boolean esBloqueante() {
        for (Entidad e : entidades) {
            if (e.esBloqueante()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Devuelve el jugador presente en la celda, si existe.
     * En caso contrario retorna null.
     */
    
    public Jugador getJugador() {
        for (Entidad e : entidades) {
            if (e instanceof Jugador) {
                return (Jugador) e;
            }
        }
        return null;
    }

    /**
     * Devuelve el helado presente en la celda, si existe.
     */
    
    public Helado getHelado() {
        for (Entidad e : entidades) {
            if (e instanceof Helado helado) {
                return helado;
            }
        }
        return null;
    }

    /**
     * Devuelve la lista de enemigos presentes en la celda.
     */
    
    public List<Enemigo> getEnemigos() {
        List<Enemigo> lista = new ArrayList<>();
        for (Entidad e : entidades) {
            if (e instanceof Enemigo) {
                lista.add((Enemigo) e);
            }
        }
        return lista;
    }

    /**
     * Indica si la celda contiene un obstáculo irrompible.
     * Se utiliza para impedir acciones como romper hielo.
     */
    
    public boolean contieneObstaculoIrrompible() {
        for (Entidad e : entidades) {
            if (e instanceof Obstaculo obst) {
                if (!obst.esRompible()) {
                    return true;
                }
            }
        }
        return false;
    }
}
