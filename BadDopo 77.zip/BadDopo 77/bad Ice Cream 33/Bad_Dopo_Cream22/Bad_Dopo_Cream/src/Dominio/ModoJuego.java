package Dominio;

/**
 * Enumeración que define los diferentes modos de juego disponibles.
 * 
 * Se utiliza para identificar cómo se desarrolla la partida
 * y el tipo de interacción entre jugadores.
 */

public enum ModoJuego {
    PLAYER,         
    PVS_P,           
    PVS_M,           
    MVS_M;           
}
