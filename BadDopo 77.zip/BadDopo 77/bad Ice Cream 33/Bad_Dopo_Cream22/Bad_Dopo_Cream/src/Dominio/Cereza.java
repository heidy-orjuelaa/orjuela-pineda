package Dominio;
import java.io.Serializable;

/**
 * Fruta que se teletransporta periódicamente a otra posición del mapa.
 * La cereza deja de moverse mientras se encuentra atrapada en hielo.
 */

public class Cereza extends Fruta implements Serializable {
    private static final long serialVersionUID = 1L; 

    private long ultimoTeleport;
    private static final int TIEMPO_TELEPORT_MS = 20_000;

    /**
     * Crea una cereza en la posición indicada.
     */
    
    public Cereza(Posicion posicion) {
        super(posicion, 150);
        this.ultimoTeleport = System.currentTimeMillis();
    }

    /**
     * Actualiza el estado de la cereza.
     * Si ha pasado el tiempo suficiente y no está congelada,
     * se teletransporta a otra posición válida del mapa.
     */
    
    @Override
    public void actualizar(Mapa mapa) {
        if (estaAtrapadaEnHielo()) return;

        long ahora = System.currentTimeMillis();

        if (ahora - ultimoTeleport >= TIEMPO_TELEPORT_MS) {
            ultimoTeleport = ahora;
            mapa.moverCereza(this);
        }
    }

    /**
     * Devuelve el identificador del tipo de fruta.
     */
    
    @Override
    public String getTipo() {
        return "Cereza";
    }
}
