package Dominio;
import java.io.Serializable;
/**
 * Representa una fogata dentro del mapa del juego.
 * 
 * La fogata puede estar encendida o apagada. Mientras está encendida,
 * es peligrosa para los jugadores que la tocan. Si se apaga, deja de
 * ser peligrosa temporalmente y se vuelve a encender automáticamente
 * después de un tiempo.
 */
public class Fogata extends Obstaculo implements Serializable {
    private static final long serialVersionUID = 1L; 

    
    private boolean encendida = true;
    private long tiempoApagada = 0;
    private static final int TIEMPO_REENCENDIDO_MS = 10_000;

    /**
     * Crea una fogata en la posición indicada.
     *
     * @param posicion posición inicial de la fogata
     */
    
    public Fogata(Posicion posicion) {
        super(posicion);
    }

    /**
     * Activa el efecto de la fogata sobre un jugador.
     * Si la fogata está encendida, el jugador muere.
     */
    
    @Override
    public void activar(Jugador jugador) {
        if (encendida) {
            jugador.morir();
        }
    }

    /**
     * Apaga la fogata si está encendida.
     * Al apagarse, comienza a contar el tiempo para volver a encenderse.
     */
    
    public void apagar() {
        if (encendida) {
            encendida = false;
            tiempoApagada = System.currentTimeMillis();
        }
    }

    /**
     * Indica si la fogata se encuentra apagada.
     */
    
    public boolean estaApagada() {
        return !encendida;
    }

    /**
     * Actualiza el estado de la fogata.
     * Si está apagada y ha pasado el tiempo suficiente,
     * se vuelve a encender automáticamente.
     */
    
    @Override
    public void actualizar(Mapa mapa) {
        if (!encendida) {
            long ahora = System.currentTimeMillis();
            if (ahora - tiempoApagada >= TIEMPO_REENCENDIDO_MS) {
                encendida = true;
            }
        }
    }

    /**
     * Retorna el tipo de la entidad según su estado actual.
     *
     * @return "Fogata" si está encendida, "FogataApagada" si no lo está
     */
    
    @Override
    public String getTipo() {
        return encendida ? "Fogata" : "FogataApagada";
    }

    /**
     * Indica si la fogata bloquea el movimiento.
     * En este caso, nunca bloquea el paso.
     */
    
    @Override
    public boolean esBloqueante() {
        return false;
    }
}
