package Dominio;
import java.io.Serializable;

/**
 * La clase Helado representa un helado jugador
 * dentro del mapa del juego. A diferencia de otras Entidades, un Helado tiene un Jugador
 * asociado como 'dueño' y su movimiento está regido por una Inteligencia Artificial (IA).

 */
public class Helado extends Entidad implements Serializable {
    private static final long serialVersionUID = 1L; 

    private final Jugador dueño;
    private final IAHelado ia;
    private final String sabor;
    private Direccion direccionActual = Direccion.NORTE;

    /**
     * Constructor para crear una nueva instancia de Helado en el mapa.
     * * @param posicion donde inicia el Helado al ser generado.
     * @param ia El objeto que define la estrategia de movimiento. Puede ser null.
     * @param dueño El jugador asociado a este Helado. Es un campo obligatorio.
     * @param sabor Una  tipo de Helado.
     */
    public Helado(Posicion posicion, IAHelado ia, Jugador dueño, String sabor) {
        super(posicion);
        this.dueño = dueño;
        this.ia = ia;
        this.sabor = sabor;
    }

    /**
     * Devuelve el sabor del Helado. Útil para mostrar información al jugador
     * o determinar reglas específicas del Helado.
     * * @return El nombre del sabor del Helado.
     */
    
    public String getSabor() {
        return sabor;
    }

    /**
     * Calcula la próxima dirección de movimiento utilizando la IA asignada.
     * @return La direccion a la que debe moverse el Helado, o null si no hay IA.
     */
    
    public Direccion calcularMovimientoIA(Mapa mapa) {
        if (ia != null) {
           
            return ia.calcularMovimiento(this, mapa);
        }
        return null;
    }

    /**
     * Método principal de actualización llamado en cada ciclo del juego.
     * @param mapa El mapa del juego donde reside el Helado.
     */
    @Override
    public void actualizar(Mapa mapa) {
        Direccion dir = calcularMovimientoIA(mapa);
        if (dir != null) {
            this.direccionActual = dir;
            mapa.moverEntidad(this, dir);
        }
    }

    /**
     * Indica si esta entidad bloquea el paso de otras entidades (ej: jugadores, otros Helados).
     *  @return Siempre false, ya que un Helado no es un obstáculo sólido.
     */
    @Override
    public boolean esBloqueante() {
        return false;
    }

    /**
     * Proporciona una cadena de texto para identificar el tipo de entidad.
     * Es útil para interfaces de usuario o depuración.
     * @return La cadena "Helado".
     */
    
    @Override
    public String getTipo() {
        return "Helado";
    }

    /**
     * Define la acción que ocurre cuando un Jugador interactúa o 'activa' este Helado.
     * * @param jugador que está activando esta entidad.
     */
    @Override
    public void activar(Jugador jugador) {
        
    }


    /**
     * Obtiene el dueño original de este Helado.
     * @return El jugador dueño.
     */
    public Jugador getDueño() {
        return dueño;
    }

    /**
     * Obtiene el objeto de Inteligencia Artificial que controla el movimiento del Helado.
     * @return La IAHelado asignada (puede ser null).
     */
    
    public IAHelado getIA() {
        return ia;
    }

    /**
     * Obtiene la última dirección calculada o hacia dónde está mirando actualmente.
     * @return La Direccion actual del Helado.
     */
    public Direccion getDireccionActual() {
        return direccionActual;
    }

    /**
     * Establece manualmente la dirección actual del Helado.
     * Útil para forzar una dirección después de una colisión o un evento especial.
     * @param nuevaDireccion La nueva direccion a establecer.
     */
    public void setDireccionActual(Direccion nuevaDireccion) {
        this.direccionActual = nuevaDireccion;
    }
}