package Dominio;
import java.io.Serializable;

/**
 * Representa la superficie del mapa por donde las entidades pueden moverse.
 * * Es la entidad más básica, no es bloqueante y no tiene efecto de activación.
 */
public class Suelo extends Entidad implements Serializable {
    private static final long serialVersionUID = 1L; 
    
    /**
     * Constructor para crear la entidad Suelo.
     */
    public Suelo() { 
        super(null); 
    }

    /**
     * Indica que el Suelo no impide el movimiento de otras entidades.
     */
    
    @Override 
    public boolean esBloqueante() { 
        return false; 
    }
    
    /**
     * Retorna la cadena de identificación del tipo de entidad.
     */
    @Override 
    public String getTipo() { 
        return "Suelo"; 
    }

    
    /**
     * Define la acción cuando un jugador pasa sobre el Suelo.
     */
    @Override 
    public void activar(Jugador jugador) { 
    }
}