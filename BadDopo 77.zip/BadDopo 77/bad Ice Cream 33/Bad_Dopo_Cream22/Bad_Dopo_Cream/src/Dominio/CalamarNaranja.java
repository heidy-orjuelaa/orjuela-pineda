package Dominio;

import java.util.List;
import java.io.Serializable;

/**
 * Enemigo que persigue directamente al primer jugador disponible.
 * Se mueve priorizando el eje donde la distancia es mayor
 * y es capaz de romper bloques de hielo que encuentre en su camino.
 */

public class CalamarNaranja extends Enemigo implements Serializable {
    private static final long serialVersionUID = 1L; 

    /**
     * Crea un calamar naranja en la posición indicada.
     * Su IA se asigna usando una referencia al método de cálculo
     * de dirección propio de esta clase.
     */
	
    public CalamarNaranja(Posicion posicion) {
        super(posicion, null);
        this.ia = this::calcularDireccion;
    }

    /**
     * Calcula la dirección de movimiento del enemigo.
     * El calamar intenta acercarse al jugador humano más cercano
     *
     * Prioriza el movimiento horizontal o vertical según
     * la mayor diferencia de distancia.
     *
     * Si encuentra un bloque de hielo en su camino, lo destruye
     * y no se mueve en ese turno.
     */
    private Direccion calcularDireccion(Enemigo e, Mapa mapa, List<Jugador> jugadores) {

        if (jugadores.isEmpty() || jugadores.get(0).getHelado() == null) {
            return Direccion.NORTE;
        }

        Jugador jugador = jugadores.get(0);
        Posicion posJugador = jugador.getHelado().getPosicion();
        Posicion posEnemigo = e.getPosicion();

        int dx = posJugador.getX() - posEnemigo.getX();
        int dy = posJugador.getY() - posEnemigo.getY();

        Direccion dir = (Math.abs(dx) > Math.abs(dy))
                ? (dx > 0 ? Direccion.ESTE : Direccion.OESTE)
                : (dy > 0 ? Direccion.SUR : Direccion.NORTE);

        Posicion siguiente = posEnemigo.desplazar(dir.getDX(), dir.getDY());

        if (mapa.esHielo(siguiente)) {
            mapa.destruirBloque(siguiente);
            return null;
        }

        Celda celda = mapa.getCelda(siguiente);
        if (celda != null && celda.esBloqueante()) {
            return null;
        }

        return dir;
    }

    /**
     * Devuelve el identificador del tipo de enemigo.
     */
    
    @Override
    public String getTipo() {
        return "CalamarNaranja";
    }
}
