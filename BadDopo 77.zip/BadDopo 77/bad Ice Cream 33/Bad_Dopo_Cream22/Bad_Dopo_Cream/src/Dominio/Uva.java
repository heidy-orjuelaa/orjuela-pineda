package Dominio;
import java.io.Serializable;

/**
 * Representa una Uva, un tipo de Fruta coleccionable en el mapa.
 * * Las Uvas otorgan 50 puntos al ser activadas por un jugador.
 */
public class Uva extends Fruta implements Serializable {
    private static final long serialVersionUID = 1L; 

    /**
     * Constructor para crear una Uva en la posición dada, inicializando su valor.
     *
     * @param posicion la posición inicial de la Uva.
     */
    public Uva(Posicion posicion) {
        super(posicion, 50); 
    }

    /**
     * Método llamado en cada ciclo para actualizar el estado de la Uva.
     * * Actualmente no realiza ninguna acción ya que es una fruta estática.
     *
     * @param mapa El mapa actual del juego.
     */
    @Override
    public void actualizar(Mapa mapa) {
    }

    /**
     * Retorna la cadena de identificación del tipo de entidad.
     * @return "Uva".
     */
    @Override
    public String getTipo() {
        return "Uva";
    }
}