package Dominio;
import java.io.Serializable;
/**
 * Representa una Piña, un tipo de fruta coleccionable en el mapa.
 * * Las Piñas otorgan 200 puntos al ser activadas por un jugador.
 */

public class Pina extends Fruta implements Serializable {
    private static final long serialVersionUID = 1L; 

    /**
     * Constructor para crear una Piña en la posición dada, inicializando su valor.
     */
	
    public Pina(Posicion posicion) {
        super(posicion, 200); // Valor asignado: 200 puntos.
    }

    /**
     * Método llamado en cada ciclo para actualizar el estado de la Piña.
     * Actualmente no realiza ninguna acción ya que es una fruta estática.
     */
    
    @Override
    public void actualizar(Mapa mapa) {
    }

    /**
     * Método placeholder para la lógica de movimiento específica de la Piña.
     * Actualmente no realiza ninguna acción.
     *
     * @param mapa El mapa actual del juego.
     */
    
    public void moverSegunJugador(Mapa mapa) {
    }

    /**
     * Retorna la cadena de identificación del tipo de entidad.
     * @return "Pina".
     */
    
    @Override
    public String getTipo() {
        return "Pina";
    }
}