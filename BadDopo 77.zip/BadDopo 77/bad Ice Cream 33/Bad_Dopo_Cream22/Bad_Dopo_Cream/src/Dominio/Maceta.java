package Dominio;

import java.util.List;
import java.io.Serializable;

/**
 * Representa la entidad Enemigo "Maceta".
 * * La Maceta implementa una IA simple de persecución: se mueve intentando
 * acercarse al Helado del primer jugador vivo que encuentra.
 */
public class Maceta extends Enemigo implements Serializable {
    private static final long serialVersionUID = 1L; 

    /**
     * Constructor para crear una Maceta en la posición especificada.
     * Inicializa la IA interna del Enemigo para usar el método local
     *
     * @param posicion posición inicial de la Maceta
     */
	
    public Maceta(Posicion posicion) {
        super(posicion, null);
        this.ia = this::calcularDireccion; 
    }

    /**
     * Lógica de Inteligencia Artificial (IA) para determinar el próximo movimiento de la Maceta.
     *
     * @param e La Maceta (Entidad Enemigo) que se está moviendo.
     * @param mapa El mapa del juego para verificar obstáculos.
     * @param jugadores La lista de jugadores activos.
     * @return La direccion del movimiento óptimo, o null si está bloqueada.
     */
    private Direccion calcularDireccion(Enemigo e, Mapa mapa, List<Jugador> jugadores) {

        Jugador jugador = jugadores.isEmpty() ? null : jugadores.get(0);
        
        if (jugador == null || jugador.estaMuerto()) {
            return null; 
        }
        
        Posicion posJ = jugador.getHelado().getPosicion();
        Posicion posE = e.getPosicion();

        int dx = posJ.getX() - posE.getX();
        int dy = posJ.getY() - posE.getY();

        Direccion dir;

        if (Math.abs(dx) > Math.abs(dy)) {
            dir = dx > 0 ? Direccion.ESTE : Direccion.OESTE;
        } else {
            dir = dy > 0 ? Direccion.SUR : Direccion.NORTE;
        }
        
        Posicion siguiente = posE.desplazar(dir.getDX(), dir.getDY());
 
        if (mapa.esObstaculo(siguiente)) {
            Direccion dirAlternativa = (Math.abs(dx) > Math.abs(dy)) 
                ? (dy > 0 ? Direccion.SUR : Direccion.NORTE) 
                : (dx > 0 ? Direccion.ESTE : Direccion.OESTE);
            
            Posicion siguienteAlt = posE.desplazar(dirAlternativa.getDX(), dirAlternativa.getDY());
            
            if (!mapa.esObstaculo(siguienteAlt)) {
                return dirAlternativa;
            }
            return null; 
        }

        return dir;
    }

    /**
     * Retorna la cadena de identificación del tipo de entidad.
     * @return "Maceta"
     */
    
    @Override
    public String getTipo() {
        return "Maceta";
    }
}