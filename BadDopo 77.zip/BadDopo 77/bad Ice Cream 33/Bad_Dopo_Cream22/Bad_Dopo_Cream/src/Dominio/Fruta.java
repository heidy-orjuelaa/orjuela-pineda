package Dominio;
import java.io.Serializable;
import java.util.List;

/**
 * Representa una fruta dentro del juego.
 * 
 * Las frutas son entidades recolectables que otorgan puntos al jugador
 * cuando se activan. Pueden quedar atrapadas en hielo, en cuyo caso no
 * pueden ser recolectadas ni atravesadas hasta liberarse.
 * 
 * Cada tipo concreto de fruta define su propio comportamiento adicional
 */
public abstract class Fruta extends Entidad implements Serializable {
    private static final long serialVersionUID = 1L; 

    protected int puntos;
    protected boolean recolectada = false;
    protected boolean atrapadaEnHielo = false;

    /**
     * Crea una fruta en la posición indicada con un valor de puntos.
     *
     * @param posicion posición inicial de la fruta
     * @param puntos   puntos que otorga al jugador
     */
    
    public Fruta(Posicion posicion, int puntos) {
        super(posicion);
        this.puntos = puntos;
    }

    /**
     * Indica si la fruta bloquea el movimiento.
     * 
     * Una fruta solo bloquea cuando está atrapada en hielo
     * y aún no ha sido recolectada.
     */
    
    @Override
    public boolean esBloqueante() {
        return atrapadaEnHielo && !recolectada;
    }

    /**
     * Actualización lógica de la fruta.
     * 
     */
    
    @Override
    public void actualizar(Mapa mapa) {
       
    }

    /**
     * Activa la fruta cuando un jugador interactúa con ella.
     */
    
    @Override
    public void activar(Jugador jugador) {
        recolectar(jugador);
    }

    /**
     * Recolecta la fruta y suma sus puntos al jugador.
     * 
     * La recolección solo ocurre si la fruta no ha sido recolectada
     * previamente y no está atrapada en hielo.
     */
    
    public void recolectar(Jugador jugador) {
        if (!recolectada && !atrapadaEnHielo) {
            jugador.sumarPuntos(puntos);
            recolectada = true;
        }
    }

    /**
     * Define si la fruta queda atrapada o liberada del hielo.
     */
    
    public void setAtrapadaEnHielo(boolean atrapada) {
        this.atrapadaEnHielo = atrapada;
    }

    /**
     * Indica si la fruta está atrapada en hielo.
     */
    
    public boolean estaAtrapadaEnHielo() {
        return atrapadaEnHielo;
    }

    /**
     * Retorna la cantidad de puntos que otorga la fruta.
     */
    
    public int getPuntos() {
        return puntos;
    }

    /**
     * Indica si la fruta ya fue recolectada.
     */
    
    public boolean fueRecolectada() {
        return recolectada;
    }
}
