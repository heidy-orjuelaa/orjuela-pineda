package Dominio;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Clase de configuración que define los parámetros de un nivel de juego.
 * * Almacena el número del nivel, el tiempo máximo permitido y las cantidades
 * de {@code Fruta}, {@code Enemigo} y {@code Obstaculo} que deben poblar el mapa.
 */
public class Nivel implements Serializable {
    private static final long serialVersionUID = 1L; 

    private int numero;
    private int tiempoMaximoSegundos = 180; 
    private Map<Class<? extends Fruta>, Integer> frutas = new HashMap<>();
    private Map<Class<? extends Enemigo>, Integer> enemigos = new HashMap<>();
    private Map<Class<? extends Entidad>, Integer> obstaculos = new HashMap<>();

    /**
     * Constructor que inicializa el nivel con un número de identificación.
     * @param numero El número del nivel.
     */
    
    public Nivel(int numero) {
        this.numero = numero;
    }

    /** Retorna el número identificador del nivel. */
    
    public int getNumero() {
        return numero;
    }

    /**
     * Establece el límite de tiempo para este nivel.
     * @param segundos el nuevo tiempo máximo en segundos.
     */
    
    public void setTiempoMaximo(int segundos) {
        this.tiempoMaximoSegundos = segundos;
    }

    /** Retorna el tiempo máximo en segundos para el nivel. */
    
    public int getTiempoMaximo() {
        return tiempoMaximoSegundos;
    }


    /**
     * Agrega o actualiza la cantidad de un tipo específico de Fruta requerida para el nivel.
     * @param tipo La Clase de la Fruta 
     * @param cantidad El número de veces que debe aparecer.
     */
    
    public void agregarFruta(Class<? extends Fruta> tipo, int cantidad) {
        frutas.put(tipo, cantidad);
    }

    /**
     * Agrega o actualiza la cantidad de un tipo específico de Enemigo requerida para el nivel.
     * @param tipo La Clase del Enemigo.
     * @param cantidad El número de veces que debe aparecer.
     */
    
    public void agregarEnemigo(Class<? extends Enemigo> tipo, int cantidad) {
        enemigos.put(tipo, cantidad);
    }

    /**
     * Agrega o actualiza la cantidad de un tipo específico de Obstaculo requerida para el nivel.
     * @param tipo La Clase del Obstaculo.
     * @param cantidad El número de veces que debe aparecer.
     */
    
    public void agregarObstaculo(Class<? extends Entidad> tipo, int cantidad) {
        obstaculos.put(tipo, cantidad);
    }


    /**
     * Crea y devuelve una nueva instancia de {@code Mapa} poblándola con las
     * Frutas, Enemigos y Obstáculos definidos en esta configuración de Nivel.
     *
     * @param ancho El ancho que debe tener el mapa.
     * @param alto El alto que debe tener el mapa.
     * @return El mapa recién generado y poblado.
     */
    public Mapa generarMapa(int ancho, int alto) {
        Mapa mapa = new Mapa(ancho, alto);

        for (var entry : frutas.entrySet()) {
            Class<? extends Fruta> tipo = entry.getKey();
            int cantidad = entry.getValue();
            for (int i = 0; i < cantidad; i++) {
                mapa.colocarEntidadAleatoria(tipo);
            }
        }

        for (var entry : enemigos.entrySet()) {
            Class<? extends Enemigo> tipo = entry.getKey();
            int cantidad = entry.getValue();
            for (int i = 0; i < cantidad; i++) {
                mapa.colocarEntidadAleatoria(tipo);
            }
        }
        
        for (var entry : obstaculos.entrySet()) {
            Class<? extends Entidad> tipo = entry.getKey();
            int cantidad = entry.getValue();
            for (int i = 0; i < cantidad; i++) {
                mapa.colocarEntidadAleatoria(tipo);
            }
        }

        return mapa;
    }
}