package Dominio;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

/**
 * Clase de utilidad (estática) para registrar mensajes de error en un archivo
 * de log persistente.
 */
public class LoggerError {

    private static final String ARCHIVO = "errores.log";

    /**
     * Registra un mensaje de error en el archivo de log.
     * @param mensaje el mensaje de error a registrar
     */
    
    public static void log(String mensaje) {
        try (FileWriter fw = new FileWriter(ARCHIVO, true)) {
            fw.write(LocalDateTime.now() + " - " + mensaje + "\n");
        } catch (IOException e) {
            System.err.println("No se pudo escribir en el log.");
        }
    }
}