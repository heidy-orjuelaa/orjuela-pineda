package Dominio;
import java.io.Serializable;

/**
 * Representa una fruta especial que alterna su comportamiento con el tiempo.
 * El cactus puede estar en estado normal (recolectable) o peligroso
 * (letal para el jugador).
 */
public class Cactus extends Fruta implements Serializable {
    private static final long serialVersionUID = 1L; 
	
    private enum Estado {
        NORMAL,
        PELIGROSO
    }
    private Estado estado = Estado.NORMAL;
    private long ultimoCambioEstado;    
    private static final int TIEMPO_CAMBIO_MS = 30_000;

    /**
     * Crea un cactus en la posición indicada.
     * Por defecto comienza en estado NORMAL.
     */
    
    public Cactus(Posicion posicion) {
        super(posicion, 250);
        this.ultimoCambioEstado = System.currentTimeMillis();
    }

    /**
     * Actualiza el estado del cactus.
     * Cada cierto tiempo alterna entre estado normal y peligroso,
     * siempre que no esté atrapado en hielo.
     */
    
    @Override
    public void actualizar(Mapa mapa) {
        if (estaAtrapadaEnHielo()) return;

        long ahora = System.currentTimeMillis();

        if (ahora - ultimoCambioEstado >= TIEMPO_CAMBIO_MS) {
            estado = (estado == Estado.NORMAL) ? Estado.PELIGROSO : Estado.NORMAL;
            ultimoCambioEstado = ahora;
        }
    }

    /**
     * Indica si el cactus bloquea el paso.
     * Es bloqueante cuando está en estado peligroso
     * o cuando se encuentra atrapado en hielo.
     */
    
    @Override
    public boolean esBloqueante() {
        return estado == Estado.PELIGROSO || atrapadaEnHielo;
    }

    /**
     * Permite recolectar el cactus solo si se encuentra
     * en estado NORMAL.
     */
    
    @Override
    public void recolectar(Jugador jugador) {
        if (estado == Estado.NORMAL) {
            super.recolectar(jugador);
        }
    }

    /**
     * Activa el comportamiento del cactus al interactuar con un jugador.
     * Si está peligroso, el jugador muere; si no, se recolecta.
     */
    
    @Override
    public void activar(Jugador jugador) {
        if (estado == Estado.PELIGROSO) {
            jugador.morir();
        } else {
            recolectar(jugador);
        }
    }

    /**
     * Devuelve el tipo del cactus según su estado actual.
     */
    
    @Override
    public String getTipo() {
        return (estado == Estado.PELIGROSO) ? "CactusPeligroso" : "Cactus";
    }
}
