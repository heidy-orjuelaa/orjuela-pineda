package Dominio;
import java.io.Serializable;
/**
 * Representa un bloque de hielo creado por los jugadores.
 * Funciona como un obstáculo rompible dentro del mapa.
 */

public class BloqueHielo extends Obstaculo implements Serializable {
    private static final long serialVersionUID = 1L; 

    /**
     * Crea un bloque de hielo en la posición indicada.
     */
	
    public BloqueHielo(Posicion posicion) {
        super(posicion);
    }

    /**
     * El bloque de hielo no tiene efecto directo al ser activado
     * por un jugador solo bloquea el movimiento.
     */
    
    @Override
    public void activar(Jugador jugador) {
    }

    /**
     * Rompe el bloque de hielo y lo elimina del mapa.
     */
    
    @Override
    public void serRoto(Jugador jugador, Mapa mapa) {
        mapa.eliminarEntidad(this);
    }

    /**
     * Indica que el bloque de hielo puede romperse.
     */
    
    @Override
    public boolean esRompible() {
        return true;
    }

    /**
     * Devuelve el tipo identificador de la entidad.
     */
    
    @Override
    public String getTipo() {
        return "BloqueHielo";
    }
}
