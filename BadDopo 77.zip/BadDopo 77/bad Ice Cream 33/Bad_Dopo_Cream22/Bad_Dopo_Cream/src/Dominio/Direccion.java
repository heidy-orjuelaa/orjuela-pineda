package Dominio;

/**
 * Representa las direcciones posibles de movimiento dentro del mapa.
 * Cada dirección tiene asociado un desplazamiento en el eje X y Y.
 */
public enum Direccion {

    NORTE(0, -1),
    SUR(0, 1),
    ESTE(1, 0),
    OESTE(-1, 0);

    private final int dx;
    private final int dy;

    Direccion(int dx, int dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * Retorna el desplazamiento en el eje X.
     */
    
    public int getDX() {
        return dx;
    }

    /**
     * Retorna el desplazamiento en el eje Y.
     */
    
    public int getDY() {
        return dy;
    }

    /**
     * Obtiene la dirección opuesta a la actual.
     */
    
    public Direccion opuesta() {
        switch (this) {
            case NORTE: return SUR;
            case SUR: return NORTE;
            case ESTE: return OESTE;
            case OESTE: return ESTE;
        }
        return null;
    }
}
