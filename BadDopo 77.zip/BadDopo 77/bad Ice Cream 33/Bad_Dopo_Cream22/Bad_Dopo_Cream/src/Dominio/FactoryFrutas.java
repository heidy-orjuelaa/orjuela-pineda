package Dominio;

/**
 * Fábrica responsable de crear frutas según el tipo solicitado.
 * Permite desacoplar la creación de frutas del resto del sistema
 * y centraliza la lógica de instanciación.
 */

public class FactoryFrutas {

    /**
     * Crea una fruta del tipo indicado en la posición dada.
     *
     * @param tipo nombre de la fruta
     * @param pos  posición inicial en el mapa
     * @return instancia de la fruta correspondiente
     * @throws IllegalArgumentException si el tipo no es válido
     */
    public static Fruta crearFruta(String tipo, Posicion pos) {
        tipo = tipo.toLowerCase();

        return switch (tipo) {
            case "uva"      -> new Uva(pos);
            case "platano"  -> new Platano(pos);
            case "pina"     -> new Pina(pos);
            case "cereza"   -> new Cereza(pos);
            case "cactus"   -> new Cactus(pos);
            default -> throw new IllegalArgumentException(
                    "Tipo de fruta desconocido: " + tipo
            );
        };
    }
}
