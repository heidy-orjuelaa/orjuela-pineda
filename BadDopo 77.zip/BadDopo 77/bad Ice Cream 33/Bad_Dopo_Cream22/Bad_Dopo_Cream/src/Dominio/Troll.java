package Dominio;
import java.io.Serializable;
import java.util.List;
import Dominio.Direccion; // Aseguramos la importación de Direccion

/**
 * Representa la entidad Enemigo "Troll".
 * El Troll se mueve en línea recta y cambia de dirección (gira 180 grados) 
 * inmediatamente al chocar con un obstáculo o límite del mapa.
 */
public class Troll extends Enemigo implements Serializable {
    private static final long serialVersionUID = 1L; 

    private Direccion direccionActual = Direccion.ESTE; 

    /**
     * Constructor para crear un Troll en la posición especificada.
     * Asigna el método local 'calcularDireccion' como la Inteligencia Artificial (IA)
     * del enemigo.
     *
     * @param posicion posición inicial del Troll.
     */
    public Troll(Posicion posicion) {
        super(posicion, null); 
        this.ia = this::calcularDireccion;
    }

    /**
     * Lógica de Inteligencia Artificial (IA) para determinar el próximo movimiento del Troll.
     */
    private Direccion calcularDireccion(Enemigo e, Mapa mapa, List<Jugador> jugadores) {
        

        Posicion posActual = getPosicion(); 
        Posicion siguiente = posActual.desplazar(
                direccionActual.getDX(),
                direccionActual.getDY()
        );

        if (mapa.esPosicionValida(siguiente) && !mapa.esObstaculo(siguiente)) {
            return direccionActual;
        }

        cambiarDireccion();
        Posicion siguienteGiro = posActual.desplazar( 
            direccionActual.getDX(),
            direccionActual.getDY()
        );
        
        if (mapa.esPosicionValida(siguienteGiro) && !mapa.esObstaculo(siguienteGiro)) {
            return direccionActual;
        }
        
        return null;
    }

    /**
     * Invierte la direccionActual del Troll (gira 180 grados).
     */
    
    private void cambiarDireccion() {
        switch (direccionActual) {
            case ESTE -> direccionActual = Direccion.OESTE;
            case OESTE -> direccionActual = Direccion.ESTE;
            case NORTE -> direccionActual = Direccion.SUR;
            case SUR -> direccionActual = Direccion.NORTE;
        }
    }

    /**
     * Retorna la cadena de identificación del tipo de entidad.
     * @return "Troll".
     */
    
    @Override
    public String getTipo() {
        return "Troll";
    }
}