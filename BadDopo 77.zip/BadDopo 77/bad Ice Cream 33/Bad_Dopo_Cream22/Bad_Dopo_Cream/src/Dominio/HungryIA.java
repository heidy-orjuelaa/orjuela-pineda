package Dominio;

/**
 * Implementación de IA que mueve el Helado hacia la Fruta más cercana.
 * Prioriza el movimiento en la dimensión (X o Y) con mayor distancia restante.
 */
public class HungryIA implements IAHelado {

    /**
     * Calcula la próxima dirección de movimiento del Helado.
     *
     * @param helado la entidad Helado que se va a mover
     * @param mapa el mapa del juego para evaluar movimientos válidos y la posición de la Fruta
     * @return la calculada, o null si no es posible moverse
     */
    @Override
    public Direccion calcularMovimiento(Helado helado, Mapa mapa) {

        Posicion pos = helado.getPosicion();
        Fruta objetivo = mapa.frutaMasCercana(pos);
        if (objetivo == null) {
            for (Direccion d : Direccion.values()) {
                if (mapa.movimientoValido(pos, d)) {
                    return d;
                }
            }
            return null; 
        }

        Posicion pf = objetivo.getPosicion();

        int dx = pf.getX() - pos.getX();
        int dy = pf.getY() - pos.getY();

        Direccion prioridad1;
        Direccion prioridad2;

        if (Math.abs(dx) > Math.abs(dy)) {
            prioridad1 = (dx > 0) ? Direccion.ESTE : Direccion.OESTE;
            prioridad2 = (dy > 0) ? Direccion.SUR : Direccion.NORTE;
        } else {
            prioridad1 = (dy > 0) ? Direccion.SUR : Direccion.NORTE;
            prioridad2 = (dx > 0) ? Direccion.ESTE : Direccion.OESTE;
        }

        if (mapa.movimientoValido(pos, prioridad1)) {
            return prioridad1;
        }

        if (mapa.movimientoValido(pos, prioridad2)) {
            return prioridad2;
        }

        for (Direccion d : Direccion.values()) {
            if (mapa.movimientoValido(pos, d)) {
                return d;
            }
        }

        return null;
    }
}