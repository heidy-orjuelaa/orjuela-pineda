package Dominio;

/**
 * Fábrica encargada de crear enemigos según su tipo.
 * Centraliza la lógica de instanciación y evita dependencias directas
 * con las clases concretas de enemigos en el resto del sistema.
 */

public class FactoryEnemigos {

    /**
     * Crea una instancia de enemigo según el tipo indicado.
     * @param tipo nombre del enemigo
     * @param pos  posición inicial en el mapa
     * @return instancia del enemigo correspondiente
     * @throws IllegalArgumentException si el tipo no es válido
     */
    public static Enemigo crearEnemigo(String tipo, Posicion pos) {
        return switch (tipo) {
            case "Troll" -> new Troll(pos);
            case "Maceta" -> new Maceta(pos);
            case "CalamarNaranja" -> new CalamarNaranja(pos);
            case "Narval" -> new Narval(pos);
            default -> null;
        };
    }
}
