import java.util.Random;

/**
 * Tienda autónoma: escoge su propia posición aleatoria al crearse.
 */
public class AutonomousStore extends Store {

    public AutonomousStore(int ignoredLocation, int tenges) {
        super(0, tenges); // ubicación temporal
        Random random = new Random();
        this.location = random.nextInt(400); // decide su propia posición
        shape.moveHorizontal(location);
    }
}
