/**
 * Robot que nunca se devuelve.
 * Solo avanza hacia adelante (ignora movimientos negativos).
 */
public class NeverBackRobot extends Robot {

    public NeverBackRobot(int location) {
        super(location, "orange");
    }

    @Override
    public void move(int meters) {
        if (meters > 0) {
            super.move(meters); // solo avanza
        }
    }
}
