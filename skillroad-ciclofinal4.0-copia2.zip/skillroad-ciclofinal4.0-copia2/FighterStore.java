/**
 * Tienda luchadora: solo puede ser robada por robots
 * que tengan más dinero acumulado que ella.
 */
public class FighterStore extends Store {

    public FighterStore(int location, int tenges) {
        super(location, tenges);
        shape.changeColor("yellow");
    }

    @Override
    public boolean canBeRobbedBy(Robot robot) {
        return robot.getProfit() > this.tenges;
    }
}
