/**
 * Clase que modela un concurso de simulación de la Ruta de la Seda.
 * <p>
 * Permite calcular las utilidades máximas diarias de una matriz de datos
 * y simular su evolución día a día con pausas configurables.
 * </p>
 *
 * <p>Contiene:</p>
 * <ul>
 *   <li>{@link #solve(int[][])} → calcula máximos diarios y guarda los datos</li>
 *   <li>{@link #simulate(int[][])} → simula mostrando resultados</li>
 *   <li>{@link #simulate()} → simula usando los últimos datos pasados</li>
 *   <li>{@link #setSlow(long)} / {@link #slow()} → control de velocidad</li>
 * </ul>
 *
 * @author Orjuela - Pineda
 * @version 3.0
 */

public class SilkRoadContest {

    private long slow = 1000;
    private int[][] lastDays = null;

    public SilkRoadContest() { }

     /**
     * Establece la velocidad (tiempo de espera en milisegundos)
     * entre los pasos de la simulación.
     *
     * @param millis tiempo en milisegundos. Si es negativo, se toma como 0.
     */
    
    public void setSlow(long millis) {
        if (millis < 0) millis = 0;
        this.slow = millis;
    }

    /**
     * Atajo que establece una pausa estándar de 1 segundo (1000 ms)
     * entre los pasos de simulación.
     */
    
    public void slow() {
        this.slow = 1000; 
    }

    /**
     * Requisito 14: Calcula la máxima utilidad diaria.
     * <p>
     * Además, guarda los datos en {@link #lastDays} para que
     * puedan ser usados posteriormente por {@link #simulate()}.
     * </p>
     *
     * @param days matriz de utilidades (cada fila representa un día)
     * @return arreglo con la máxima utilidad por cada día
     */
    
    public int[] solve(int[][] days) {
        this.lastDays = days;

        if (days == null || days.length == 0) {
            return new int[0];
        }

        int[] maxDailyProfit = new int[days.length];

        for (int i = 0; i < days.length; i++) {
            if (days[i] == null || days[i].length == 0) {
                maxDailyProfit[i] = 0;
                continue;
            }
            int max = days[i][0];
            for (int j = 1; j < days[i].length; j++) {
                if (days[i][j] > max) {
                    max = days[i][j];
                }
            }
            maxDailyProfit[i] = max;
        }

        return maxDailyProfit;
    }

    /**
     * Requisito 15: Simula día a día usando los últimos datos cargados.
     * <p>
     * Si {@code lastDays} es {@code null} o vacío, se muestra un mensaje
     * y la simulación no se ejecuta.
     * </p>
     */
    
    public void simulate() {
        simulate(this.lastDays);
    }

    /**
     * Simula la ejecución día a día mostrando en consola cada resultado.
     * <p>
     * Si {@code days} es {@code null} o vacío, no se realiza la simulación.
     * </p>
     *
     * @param days matriz de datos a simular; cada fila representa un día.
     */
    
    public void simulate(int[][] days) {
        if (days == null || days.length == 0) {
            System.out.println("simulate(): no hay datos para simular.");
            return;
        }

        int[] profits = solve(days);

        System.out.println("=== Simulación de la Maratón de Silk Road ===");
        for (int i = 0; i < profits.length; i++) {
            System.out.println("Día " + (i + 1) + ": utilidad máxima = " + profits[i]);

            try {
                if (slow > 0) Thread.sleep(slow);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Simulación interrumpida.");
                return;
            }
        }
        System.out.println("Fin de la simulación");
    }
}
