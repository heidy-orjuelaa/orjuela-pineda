import java.util.Timer;
import java.util.TimerTask;

/**
 * Clase base Robot.
 * Representa un robot dentro del juego SilkRoad.
 * Puede ser extendida para crear robots con diferentes comportamientos
 * (NeverBack, Tender, etc.)
 * 
 * @author (Orjuela - Pineda)
 * @version 2025
 */
public class Robot {

    // Atributos protegidos para acceso desde subclases
    protected int initialLocation;
    protected int currentLocation;
    protected int profit;
    protected Circle shape;
    protected boolean visible;
    protected boolean blinking;
    protected Timer blinkTimer;

    public Robot(int location) {
        this(location, "blue");
    }

    public Robot(int location, String color) {
        this.initialLocation = location;
        this.currentLocation = location;
        this.profit = 0;
        this.visible = false;
        this.blinking = false;
        this.shape = new Circle();
        this.shape.changeColor(color);
        this.shape.moveHorizontal(location);
    }

    /** Mueve el robot cierta cantidad de metros (puede sobrescribirse). */
    public void move(int meters) {
        currentLocation += meters;
        shape.moveHorizontal(meters);
    }

    /** Restablece la posición original del robot. */
    public void resetPosition() {
        int delta = initialLocation - currentLocation;
        currentLocation = initialLocation;
        shape.moveHorizontal(delta);
    }

    /** Añade dinero al robot. */
    public void addProfit(int amount) {
        profit += amount;
    }

    /** Devuelve la ganancia acumulada. */
    public int getProfit() { return profit; }

    /** Devuelve la ubicación actual. */
    public int getLocation() { return currentLocation; }

    /** Roba una tienda (puede modificarse en subclases). */
    public void rob(Store store) {
        if (store.canBeRobbedBy(this)) {
            int taken = store.getTenges();
            store.withdraw(taken);
            addProfit(taken);
        }
    }

    /** Muestra al robot en pantalla. */
    public void show() {
        visible = true;
        shape.makeVisible();
    }

    /** Oculta al robot. */
    public void hide() {
        visible = false;
        shape.makeInvisible();
    }

    /** Hace parpadear el robot. */
    public void blink() {
        if (blinking) return;
        blinking = true;

        blinkTimer = new Timer();
        blinkTimer.scheduleAtFixedRate(new TimerTask() {
            private boolean visibleState = true;
            @Override
            public void run() {
                if (!blinking) {
                    cancel();
                    return;
                }
                if (visibleState) shape.makeInvisible();
                else shape.makeVisible();
                visibleState = !visibleState;
            }
        }, 0, 400);
    }

    /** Detiene el parpadeo. */
    public void stopBlink() {
        blinking = false;
        if (blinkTimer != null) {
            blinkTimer.cancel();
            blinkTimer = null;
        }
        shape.makeVisible();
    }

    public boolean isBlinking() {
        return this.blinking;
    }
}
