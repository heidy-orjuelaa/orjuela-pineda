/**
 * Robot que solo toma la mitad del dinero de las tiendas.
 */
public class TenderRobot extends Robot {

    public TenderRobot(int location) {
        super(location, "pink");
    }

    @Override
    public void rob(Store store) {
        if (store.canBeRobbedBy(this)) {
            int half = store.getTenges() / 2;
            store.withdraw(half);
            addProfit(half);
        }
    }
}
