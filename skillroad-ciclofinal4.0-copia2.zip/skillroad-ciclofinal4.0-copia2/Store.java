/**
 * Clase base Store que representa una tienda en la Ruta de la Seda.
 * Cada tienda tiene una ubicación, una cantidad de tenges (dinero),
 * y un contador de cuántas veces ha sido desocupada.
 * 
 * Puede ser extendida para crear tiendas de diferentes tipos (autonomous, fighter, etc.)
 * 
 * @author (Orjuela - Pineda)
 * @version 2025
 */
public class Store {    

    // Atributos protegidos para permitir acceso desde subclases
    protected int location;        
    protected int tenges;           
    protected int initialTenges;    
    protected int timesEmptied;     
    protected Rectangle shape;      
    protected boolean visible;      

    public Store(int location, int tenges) {
        this.location = location;
        this.tenges = tenges;
        this.initialTenges = tenges;
        this.timesEmptied = 0;
        this.visible = false;
        this.shape = new Rectangle();
        this.shape.changeColor("green");
        this.shape.moveHorizontal(location);
    }

    /**
     * Reduce el número de tenges en la tienda.
     * Si queda en 0, aumenta el contador de desocupaciones
     * y cambia su color para indicar que está vacía.
     */
    public void withdraw(int amount) {
        if (amount <= tenges) tenges -= amount;
        else tenges = 0;

        if (tenges == 0) {
            timesEmptied++;
            showEmpty();
        }
    }

    /** Reabastece la tienda a su cantidad inicial de tenges. */
    public void resupply() {
        tenges = initialTenges;
        showFull();
    }

    public int getTenges() { return tenges; }
    public int getTimesEmptied() { return timesEmptied; }
    public int getLocation() { return location; }
    public int getInitialTenges() { return initialTenges; }

    public void setTenges(int tenges) { this.tenges = tenges; }

    /** Muestra gráficamente la tienda en el lienzo. */
    public void show() {
        visible = true;
        shape.makeVisible();
    }

    /** Oculta gráficamente la tienda del lienzo. */
    public void hide() {
        visible = false;
        shape.makeInvisible();
    }

    /** Indica si la tienda puede ser robada por un robot (por defecto sí). */
    public boolean canBeRobbedBy(Robot robot) {
        return true;
    }

    /** Cambia el color del rectángulo a rojo (tienda vacía). */
    protected void showEmpty() {
        shape.changeColor("red");
    }

    /** Cambia el color del rectángulo a verde (tienda con dinero). */
    protected void showFull() {
        shape.changeColor("green");
    }
}
