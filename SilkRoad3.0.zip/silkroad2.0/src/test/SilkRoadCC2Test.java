package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import silkRoad.SilkRoad;

public class SilkRoadCC2Test {

    @Test
    public void testPlaceStoreInvalidLocation() {
        Exception exception = assertThrows(Exception.class, () -> {
            SilkRoad sr = new SilkRoad(5);
            sr.placeStore(10, 100); // fuera del límite
        });

        assertTrue(exception.getMessage().contains("fuera de los límites"), 
                   "Debe lanzar excepción por ubicación inválida.");
    }

    @Test
    public void testProfitWithoutRobots() throws Exception {
        SilkRoad sr = new SilkRoad(5);

        Exception exception = assertThrows(Exception.class, sr::profit);
        assertTrue(exception.getMessage().contains("No hay robots"),
                   "Debe lanzar excepción si no hay robots creados.");
    }

    @Test
    public void testRemoveStore() throws Exception {
        SilkRoad sr = new SilkRoad(5);
        sr.placeStore(1, 50);
        sr.removeStore(1);

        assertEquals(0, sr.stores().size(), "Después de eliminar la tienda, la lista debe quedar vacía.");
    }
}
