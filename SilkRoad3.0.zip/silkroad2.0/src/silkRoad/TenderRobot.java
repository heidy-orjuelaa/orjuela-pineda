package silkRoad;

/**
 * Clase TenderRobot.
 * 
 * Representa un robot que recoge únicamente la mitad del dinero disponible en una tienda.
 *
 */
public class TenderRobot extends Robot {

    public TenderRobot(int location, String color) {
        super(location, color);
    }

    /**
     * Toma solo la mitad del dinero disponible en la tienda.
     * 
     * @param store tienda de la cual se toma el dinero.
     * @throws IllegalArgumentException si la tienda es nula o tiene tenges negativos.
     */
    
    public void collectFrom(Store store) {
        if (store == null) {
            throw new IllegalArgumentException("La tienda no puede ser nula.");
        }
        if (store.getTenges() < 0) {
            throw new IllegalArgumentException("La tienda tiene un valor de tenges inválido (negativo).");
        }

        int available = store.getTenges();
        int half = available / 2;

        store.setTenges(available - half);
        addProfit(half);
    }
}