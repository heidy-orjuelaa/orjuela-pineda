package silkRoad;

/**
 * Tienda luchadora: solo entrega su dinero a robots que tengan
 * más dinero acumulado que ella.
 * 
 */
public class FighterStore extends Store {

    public FighterStore(int location, int tenges) {
        super(location, tenges);
    }

    /**
     * Permite que un robot intente tomar dinero de esta tienda.
     * Si el robot no tiene más dinero que la tienda, no pasa nada.
     */
    public void interact(Robot robot) {
        if (robot.getProfit() > getTenges()) {
            int dineroTomado = getTenges();
            robot.addProfit(dineroTomado);
            setTenges(0);
        }
    }

    @Override
    public String toString() {
        return "FighterStore{" +
                "location=" + getLocation() +
                ", tenges=" + getTenges() +
                '}';
    }
}
