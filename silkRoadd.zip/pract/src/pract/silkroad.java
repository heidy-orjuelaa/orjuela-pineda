package pract;

public class silkroad {

}
