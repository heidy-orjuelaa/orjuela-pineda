package test;
import silkRoad.*;


import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Casos de prueba colectivos para SilkRoad.
 * 
 * Pruebas cubren:
 * - Límites de ubicación de tiendas y robots
 * - Movimiento de robots dentro de la ruta
 * - Eliminación de robots
 * - Reinicio del sistema
 * - Reabastecimiento de tiendas
 * - Restricción de duplicación de robots
 * 
 * @author (Orjuela - Pineda)
 * @version 2025
 */

public class SilkRoadCC2Test {

    private SilkRoad road;
    /**
     * Inicializa SilkRoad antes de cada prueba con 10 posiciones.
     */
    @Before
    public void setUp() {
        road = new SilkRoad(10); 
    }

    /**
     * (OP) No debe permitir colocar tiendas en ubicaciones fuera de la ruta.
     */
    @Test
    public void accordingOPShouldNotPlaceStoreOutsideBounds() {
        road.placeStore(-1, 50);
        assertEquals("No debe agregarse tienda en ubicación negativa", 0, road.stores().size());

        road.placeStore(15, 50);
        assertEquals("No debe agregarse tienda en ubicación mayor a la longitud", 0, road.stores().size());
    }

    /**
     * (OP) Debe permitir mover el robot sin salirse de la ruta.
     */
    @Test
    public void accordingOPShouldMoveRobotWithinBounds() {
        road.placeRobot(0);
        road.moveRobot(0, 20); 
        assertEquals("El robot no debe salirse de la ruta", 9, road.robots().get(0).getLocation());
    }

    /**
     * (OP) Al eliminar un robot debe desaparecer de la lista.
     */
    @Test
    public void accordingOPShouldRemoveRobot() {
        road.placeRobot(3);
        assertEquals(1, road.robots().size());
        road.removeRobot(3);
        assertEquals(0, road.robots().size());
    }

    /**
     * (OP) Al reiniciar debe limpiar completamente las tiendas y robots.
     */
    @Test
    public void accordingOPShouldRebootSystem() {
        road.placeRobot(1);
        road.placeStore(2, 50);
        road.reboot();
        assertEquals(0, road.robots().size());
        assertEquals(0, road.stores().size());
    }

    /**
     * (OP) El reabastecimiento debe restaurar el valor inicial de todas las tiendas.
     */
    @Test
    public void accordingOPShouldResupplyAllStores() {
        road.placeStore(4, 30);
        road.placeStore(6, 10);

        for (Store s : road.stores()) {
            s.withdraw(s.getTenges());
            assertEquals(0, s.getTenges());
        }

        road.resupplyStores();

        for (Store s : road.stores()) {
            assertTrue("La tienda debe tener dinero nuevamente", s.getTenges() > 0);
        }
    }

    /**
     * (OP) No debe permitir colocar dos robots en la misma ubicación.
     */
    @Test
    public void accordingOPShouldNotAllowDuplicateRobots() {
        road.placeRobot(5);
        road.placeRobot(5);
        assertEquals("Sólo debe haber un robot en la ubicación 5", 1, road.robots().size());
    }
}
