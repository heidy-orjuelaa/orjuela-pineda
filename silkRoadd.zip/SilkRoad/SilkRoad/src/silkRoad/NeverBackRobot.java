package silkRoad;

/**
 * Clase NeverBackRobot.
 * 
 * Este robot no puede moverse hacia atrás.
 */
public class NeverBackRobot extends Robot {

    public NeverBackRobot(int location, String color) {
        super(location, color);
    }

    @Override
    public void move(int meters) {
        if (meters < 0) {
            throw new IllegalArgumentException("El robot NeverBack no puede moverse hacia atrás.");
        }
        super.move(meters);
    }
}
