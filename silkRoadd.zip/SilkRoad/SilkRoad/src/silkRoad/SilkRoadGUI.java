package silkRoad;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.Timer;

/**
 * Interfaz gráfica del simulador Silk Road.
 * Permite agregar tiendas y robots, iniciar la simulación y mostrar su progreso.
 * Utiliza Swing para los controles y gráficos del recorrido.
 * 
 *  * @author (Orjuela - Pineda)
 * @version 2025
 */

public class SilkRoadGUI extends JFrame {

    private final int POSITIONS = 20; 
    private SilkRoad silkRoad;
    private final CanvasPanel canvas;
    private final JTextArea logArea;
    private final JProgressBar profitBar;
    private final JButton btnAddStore, btnAddRobot, btnSimulate, btnStep, btnStop;
    private final JButton btnResupply, btnReturnRobots, btnReboot, btnToggleVisible;

    private Timer simulationTimer;
    private boolean simulating = false;
    private final int TIMER_DELAY = 500; 

    private final Map<Store, Color> storeColors = new HashMap<>();
    private final Map<Robot, Color> robotColors = new HashMap<>();
    private final Random rnd = new Random();
    private final Map<Robot, Boolean> robotBlinkState = new HashMap<>();
    private boolean blinkOn = true; 

    /**
     * Constructor principal.
     * Configura la ventana, los botones, el área de registro y el panel gráfico.
     */
    
    public SilkRoadGUI() {
        super("Silk Road Simulator (Swing)");

        try {
            this.silkRoad = new SilkRoad(POSITIONS);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                this,
                "Error al inicializar SilkRoad: " + ex.getMessage(),
                "Error de inicialización",
                JOptionPane.ERROR_MESSAGE
            );
            try {
                this.silkRoad = new SilkRoad(10);
            } catch (Exception ex2) {
                JOptionPane.showMessageDialog(
                    this,
                    "No fue posible inicializar el simulador. La aplicación se cerrará.",
                    "Error crítico",
                    JOptionPane.ERROR_MESSAGE
                );
                System.exit(1);
            }
        }

        silkRoad.makeVisible();

        canvas = new CanvasPanel();
        logArea = new JTextArea(6, 40);
        logArea.setEditable(false);
        profitBar = new JProgressBar(0, 100);
        profitBar.setStringPainted(false);
        profitBar.setPreferredSize(new Dimension(400, 18));

        btnAddStore = new JButton("Agregar Tienda");
        btnAddRobot = new JButton("Agregar Robot");
        btnSimulate = new JButton("Simular");
        btnStep = new JButton("Step");
        btnStop = new JButton("Parar");
        btnResupply = new JButton("Reabastecer Tiendas");
        btnReturnRobots = new JButton("Regresar Robots");
        btnReboot = new JButton("Reiniciar");
        btnToggleVisible = new JButton("Invisible");

        setupLayout();
        setupActions();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * Configura la distribución de los paneles y controles de la ventana.
     */
    
    private void setupLayout() {
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(btnAddStore);
        topPanel.add(btnAddRobot);
        topPanel.add(btnSimulate);
        topPanel.add(btnStep);
        topPanel.add(btnStop);
        topPanel.add(btnResupply);
        topPanel.add(btnReturnRobots);
        topPanel.add(btnReboot);
        topPanel.add(btnToggleVisible);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(new JLabel("Registro:"), BorderLayout.NORTH);
        rightPanel.add(new JScrollPane(logArea), BorderLayout.CENTER);
        rightPanel.add(profitBar, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(canvas, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);
    }

    /**
     * Asocia los botones con sus acciones.
     */
    
    private void setupActions() {
        btnAddStore.addActionListener(e -> handleAddStore());
        btnAddRobot.addActionListener(e -> handleAddRobot());
        btnSimulate.addActionListener(e -> startSimulation());
        btnStep.addActionListener(e -> stepSimulation());
        btnStop.addActionListener(e -> stopSimulation());
        btnResupply.addActionListener(e -> handleResupply());
        btnReturnRobots.addActionListener(e -> handleReturnRobots());
        btnReboot.addActionListener(e -> handleReboot());
        btnToggleVisible.addActionListener(e -> toggleVisible());
    }
  

    /**
     * Maneja la creación de una nueva tienda con tipo, ubicación y tenges.
     */
    
    private void handleAddStore() {
        String[] tipos = {"Normal", "Autonomous", "Fighter"};
        String tipoSeleccionado = (String) JOptionPane.showInputDialog(
            this,
            "Selecciona el tipo de tienda:",
            "Tipo de Tienda",
            JOptionPane.PLAIN_MESSAGE,
            null,
            tipos,
            tipos[0]
        );

        if (tipoSeleccionado == null) return;

        String posStr = JOptionPane.showInputDialog(this, "Ubicación de la tienda (0-" + (POSITIONS - 1) + "):");
        if (posStr == null) return;
        String tengesStr = JOptionPane.showInputDialog(this, "Tenges iniciales (entero):");
        if (tengesStr == null) return;

        try {
            int pos = Integer.parseInt(posStr.trim());
            int tenges = Integer.parseInt(tengesStr.trim());

            
            if (pos < 0 || pos >= POSITIONS || tenges < 0) {
                throw new NumberFormatException();
            }

            for (Store s : silkRoad.stores()) {
                if (s.getLocation() == pos) {
                    showMessageIfVisible("Ya existe una tienda en la posición " + pos);
                    return;
                }
            }

            
            silkRoad.placeStore(pos, tenges, tipoSeleccionado.toLowerCase());

            Store added = lastAddedStoreAt(pos);
            if (added != null) storeColors.put(added, randomBrightColor());

            log("Tienda tipo " + tipoSeleccionado + " añadida en posición " + pos);
            updateProfitBar();
            canvas.repaint();

        } catch (NumberFormatException ex) {
            showMessageIfVisible("Entrada inválida: ingresa enteros válidos.");
        } catch (IndexOutOfBoundsException ex) {
            showMessageIfVisible("Error: ubicación fuera de los límites de la ruta.");
        } catch (IllegalArgumentException ex) {
            showMessageIfVisible("Error: " + ex.getMessage());
        } catch (Exception ex) {
            showMessageIfVisible("Ocurrió un error inesperado: " + ex.getMessage());
        }
    }

    
    /**
     * Retorna la última tienda agregada en una posición.
     */

    private Store lastAddedStoreAt(int pos) {
        for (Store s : silkRoad.stores()) if (s.getLocation() == pos) return s;
        return null;
    }

    /**
     * Retorna la última tienda agregada en una posición.
     */
    
    private void handleAddRobot() {
        String[] tipos = {"Normal", "NeverBack", "Tender"};
        String tipoSeleccionado = (String) JOptionPane.showInputDialog(
            this,
            "Selecciona el tipo de robot:",
            "Tipo de Robot",
            JOptionPane.PLAIN_MESSAGE,
            null,
            tipos,
            tipos[0]
        );

        if (tipoSeleccionado == null) return;

        String posStr = JOptionPane.showInputDialog(this, "Ubicación del robot (0-" + (POSITIONS - 1) + "):");
        if (posStr == null) return;

        try {
            int pos = Integer.parseInt(posStr.trim());
            if (pos < 0 || pos >= POSITIONS) throw new NumberFormatException();

            for (Robot r : silkRoad.robots()) {
                if (r.getLocation() == pos) {
                    showMessageIfVisible("Ya existe un robot en la posición " + pos);
                    return;
                }
            }

            silkRoad.placeRobot(pos, tipoSeleccionado.toLowerCase());

            Robot added = lastAddedRobotAt(pos);
            if (added != null) robotColors.put(added, randomBrightColor());

            log("Robot tipo " + tipoSeleccionado + " añadido en posición " + pos);
            updateProfitBar();
            canvas.repaint();

        } catch (NumberFormatException ex) {
            showMessageIfVisible("Entrada inválida: ingresa un entero válido para posición.");
        } catch (IndexOutOfBoundsException ex) {
            showMessageIfVisible("Error: ubicación fuera de los límites de la ruta.");
        } catch (IllegalArgumentException ex) {
            showMessageIfVisible("Error: " + ex.getMessage());
        } catch (Exception ex) {
            showMessageIfVisible("Error al añadir robot: " + ex.getMessage());
        }
    }


    /**
     * Retorna el último robot agregado en una posición.
     */
    
    private Robot lastAddedRobotAt(int pos) {
        for (Robot r : silkRoad.robots()) if (r.getLocation() == pos) return r;
        return null;
    }

    /** Reabastece las tiendas. */
    
    private void handleResupply() {
        silkRoad.resupplyStores();
        log("Tiendas reabastecidas.");
        updateProfitBar();
        canvas.repaint();
    }

    /** Devuelve los robots a su posición inicial. */
    
    private void handleReturnRobots() {
        silkRoad.returnRobots();
        log("Robots regresaron a posiciones iniciales.");
        canvas.repaint();
    }
    
    /** Reinicia todo el sistema. */

    private void handleReboot() {
        silkRoad.reboot();
        storeColors.clear();
        robotColors.clear();
        robotBlinkState.clear();
        log("Sistema reiniciado.");
        updateProfitBar();
        canvas.repaint();
    }

    /** Alterna entre modo visible e invisible. */
    
    private void toggleVisible() {
        if (btnToggleVisible.getText().equals("Invisible")) {
            silkRoad.makeInvisible();
            btnToggleVisible.setText("Visible");
            log("Simulador puesto en modo invisible.");
        } else {
            silkRoad.makeVisible();
            btnToggleVisible.setText("Invisible");
            log("Simulador visible.");
        }
    }

    /**
     * Inicia la simulación automática.
     */
    
    private void startSimulation() {
        if (simulating) return;
        if (silkRoad.stores().isEmpty() || silkRoad.robots().isEmpty()) {
            showMessageIfVisible("Necesitas al menos 1 tienda y 1 robot para simular.");
            return;
        }
        simulating = true;
        log("\n--- Simulación iniciada ---");

        simulationTimer = new Timer(TIMER_DELAY, e -> {
            blinkOn = !blinkOn;
            stepSimulation();
        });
        simulationTimer.start();
    }
    
    /** Detiene la simulación. */

    private void stopSimulation() {
        if (!simulating) return;
        simulating = false;
        if (simulationTimer != null) {
            simulationTimer.stop();
            simulationTimer = null;
        }

        for (Robot r : silkRoad.robots()) r.stopBlink();
        log("--- Simulación detenida ---\n");
        canvas.repaint();
    }
    
    /**
     * Ejecuta un paso de la simulación.
     */
    private void stepSimulation() {
        ArrayList<Store> stores = silkRoad.stores();
        ArrayList<Robot> robots = silkRoad.robots();

        boolean anyStoreHas = stores.stream().anyMatch(s -> s.getTenges() > 0);
        if (!anyStoreHas) {
            log("No quedan tenges en tiendas. Simulación finalizada.");
            stopSimulation();
            return;
        }

        for (Robot r : robots) {
            int rpos = r.getLocation();
            Store nearest = null;
            int bestDist = Integer.MAX_VALUE;
            
            for (Store s : stores) {
                if (s.getTenges() <= 0) continue;
                int dist = Math.abs(s.getLocation() - rpos);
                if (dist < bestDist) {
                    bestDist = dist;
                    nearest = s;
                }
            }
            
            if (nearest == null) continue;

            int target = nearest.getLocation();
            int dir = Integer.compare(target, rpos);
            
            if (dir != 0) {
                try {
                    silkRoad.moveRobot(rpos, dir);
                    log("Robot se mueve desde " + rpos + " a " + (rpos + dir));
                } catch (IllegalArgumentException e) {
                    log("Movimiento inválido: " + e.getMessage());
                } catch (Exception e) {
                    log("Error al mover robot: " + e.getMessage());
                }
            }


            if (r.getLocation() == target && nearest.getTenges() > 0) {
                int gained = nearest.getTenges();
                nearest.withdraw(gained);
                r.addProfit(gained);
                log("Robot en " + target + " recogió " + gained + " tenges.");
            }
        }

        updateLeaderBlinking();
        updateProfitBar();
        canvas.repaint();
    }


    /** Actualiza el parpadeo del robot líder. */
    
    private void updateLeaderBlinking() {
        Robot leader = null;
        int max = Integer.MIN_VALUE;
        for (Robot r : silkRoad.robots()) {
            if (r.getProfit() > max) {
                max = r.getProfit();
                leader = r;
            }
        }

        for (Robot r : silkRoad.robots()) {
            if (r != leader) {
                r.stopBlink();
                robotBlinkState.put(r, false);
            }
        }
        if (leader != null && max > 0) {
            leader.blink();
            robotBlinkState.put(leader, true);
        }
    }

    /**
     * Actualiza la barra de progreso de ganancias.
     */
    private void updateProfitBar() {
        try {
            int totalProfit = silkRoad.profit();
            int maxPossible = 0;

            for (Store s : silkRoad.stores()) {
                maxPossible += s.getInitialTenges();
            }

            if (maxPossible <= 0) {
                profitBar.setValue(0);
                profitBar.setMaximum(100);
                return;
            }

            int percent = (int) ((totalProfit * 100L) / maxPossible);
            percent = Math.min(100, Math.max(0, percent));
            profitBar.setValue(percent);

        } catch (Exception ex) {
            profitBar.setValue(0);
            profitBar.setMaximum(100);
            log("No se pudo calcular las ganancias: " + ex.getMessage());
        }
    }


    /** Genera un color aleatorio brillante. */
    
    private Color randomBrightColor() {
        float hue = rnd.nextFloat();
        float sat = 0.6f + rnd.nextFloat() * 0.4f;
        float br = 0.6f + rnd.nextFloat() * 0.4f;
        return Color.getHSBColor(hue, sat, br);
    }
    
    /** Muestra un mensaje si el modo visible está activo. */

    private void showMessageIfVisible(String message) {
        if (btnToggleVisible.getText().equals("Invisible")) {
            JOptionPane.showMessageDialog(this, message);
        } else {
            log("[Mensaje oculto por modo invisible]: " + message);
        }
    }

    /** Registra un mensaje en el área de texto. */
    
    private void log(String s) {
        logArea.append(s + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    /**
     * Panel interno que dibuja el recorrido, tiendas y robots.
     */
    
    private class CanvasPanel extends JPanel {
        private final int PADDING = 60;

        /**
         * Dibuja todos los elementos del simulador.
         */
        
        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0;
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            g.setColor(new Color(245, 245, 250));
            g.fillRect(0, 0, w, h);

            Point[] route = computeRoutePositions(POSITIONS, w, h);

            g.setColor(new Color(205, 133, 63));
            g.setStroke(new BasicStroke(18f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int i = 0; i < route.length - 1; i++) {
                Point a = route[i], b = route[i + 1];
                g.drawLine(a.x, a.y, b.x, b.y);
            }

            g.setStroke(new BasicStroke(1f));
            g.setFont(new Font("SansSerif", Font.PLAIN, 12));
            for (int i = 0; i < route.length; i++) {
                g.setColor(Color.DARK_GRAY);
                g.fillOval(route[i].x - 4, route[i].y - 4, 8, 8);
                String lbl = Integer.toString(i);
                int strw = g.getFontMetrics().stringWidth(lbl);
                g.drawString(lbl, route[i].x - strw / 2, route[i].y + 20);
            }

            for (Store s : silkRoad.stores()) {
                int pos = s.getLocation();
                if (pos < 0 || pos >= route.length) continue;
                Point p = route[pos];
                Color c;
                if (s instanceof AutonomousStore) {
                    c = new Color(0, 128, 255);
                } else if (s instanceof FighterStore) {
                    c = new Color(255, 140, 0); 
                } else {
                    c = new Color(34, 139, 34); 
                }
                if (s.getTenges() <= 0) c = Color.RED;


                g.setColor(c);
                int wRect = 36, hRect = 28;
                g.fillRect(p.x - wRect / 2, p.y - 60, wRect, hRect);
                g.setColor(Color.WHITE);
                g.drawString("$", p.x - 5, p.y - 42);
            }

            for (Robot r : silkRoad.robots()) {
                int pos = r.getLocation();
                if (pos < 0 || pos >= route.length) continue;
                Point p = route[pos];
                Color c = robotColors.getOrDefault(r, new Color(70, 130, 255));

                boolean isLeaderBlink = robotBlinkState.getOrDefault(r, false);
                if (isLeaderBlink && !blinkOn) {
                    g.setColor(c.darker().darker());
                    g.fillOval(p.x - 12, p.y + 12, 24, 24);
                } else {
                    g.setColor(c);
                    g.fillOval(p.x - 12, p.y + 12, 24, 24);
                    g.setColor(Color.BLACK);
                    g.drawOval(p.x - 12, p.y + 12, 24, 24);
                }

                int profit = r.getProfit();
                if (profit > 0) {
                    g.setColor(Color.BLACK);
                    String pft = String.valueOf(profit);
                    g.drawString(pft, p.x - g.getFontMetrics().stringWidth(pft) / 2, p.y + 10);
                }
            }
        }

        /**
         * Calcula las posiciones del recorrido en pantalla.
         */
        
        private Point[] computeRoutePositions(int count, int w, int h) {
            Point[] pts = new Point[count];
            if (count <= 10) {
                int left = PADDING;
                int right = w - PADDING;
                int y = h / 2;
                for (int i = 0; i < count; i++) {
                    int x = left + (i * (right - left)) / (count - 1);
                    pts[i] = new Point(x, y);
                }
            } else {
                int cx = w / 2;
                int cy = h / 2;
                int step = 60;
                int dir = 0;
                int len = 1;
                int idx = 0;
                int x = cx, y = cy;
                pts[idx++] = new Point(x, y);

                while (idx < count) {
                    for (int r = 0; r < 2; r++) {
                        for (int i = 0; i < len && idx < count; i++) {
                            switch (dir) {
                                case 0 -> x += step;
                                case 1 -> y += step;
                                case 2 -> x -= step;
                                case 3 -> y -= step;
                            }
                            pts[idx++] = new Point(x, y);
                        }
                        dir = (dir + 1) % 4;
                    }
                    len++;
                }
            }
            return pts;
        }
    }

    
    /**
     * lanzar
     */
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SilkRoadGUI());
    }
}
