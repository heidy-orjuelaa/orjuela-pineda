package silkRoad;
import shapes.Rectangle; 


/**
 * Clase Store que representa una tienda en la Ruta de la Seda.
 * Cada tienda tiene una ubicación, una cantidad de tenges (dinero),
 * y un contador de cuántas veces ha sido desocupada.
 * 
 * La tienda puede ser mostrada o escondida visualmente mediante
 * un objeto Rectangle. Su color cambia dependiendo de si está vacía o llena.
 * 
 * @author (Orjuela - Pineda) 
 * @version 2025
 */
public class Store {

    private int location;        
    private int tenges;           
    private int initialTenges;    
    private int timesEmptied;     
    private Rectangle shape;      
    private boolean visible;      

    public Store(int location, int tenges) {
        this.location = location;
        this.tenges = tenges;
        this.initialTenges = tenges;
        this.timesEmptied = 0;
        this.visible = false;

        // Usa tu propia clase Rectangle (de shapes)
        this.shape = new Rectangle();
        this.shape.changeColor("green");
        this.shape.moveHorizontal(location * 50); // ajusta escala si lo ves muy pegado
    }

    public void withdraw(int amount) {
        if (amount <= tenges) {
            tenges -= amount;
        } else {
            tenges = 0;
        }

        if (tenges == 0) {
            timesEmptied++;
            showEmpty();
        }
    }

    public void resupply() {
        tenges = initialTenges;
        showFull();
    }

    public int getTenges() {
        return tenges;
    }

    public int getTimesEmptied() {
        return timesEmptied;
    }

    public int getLocation() {
        return location;
    }

    public int getInitialTenges() {
        return initialTenges;
    }

    public void setTenges(int tenges) {
        this.tenges = tenges;
    }

    public void show() {
        visible = true;
        shape.makeVisible();
    }

    public void hide() {
        visible = false;
        shape.makeInvisible();
    }

    private void showEmpty() {
        shape.changeColor("red"); 
    }

    private void showFull() {
        shape.changeColor("green"); 
    }
}
