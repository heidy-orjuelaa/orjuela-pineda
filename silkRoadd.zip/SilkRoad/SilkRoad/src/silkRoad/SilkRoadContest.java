package silkRoad;
/**
 * 
 * Permite calcular las utilidades máximas diarias de una matriz de datos
 * y simular su evolución día a día con pausas configurables.
 * 
 *
 * 
 *   solve - calcula máximos diarios y guarda los datos
 *  simulate - simula mostrando resultados
 *   simulate - simula usando los últimos datos pasados
 *   setSlow - control de velocidad
 * 
 * @author Orjuela - Pineda
 *
 */

public class SilkRoadContest {

    private long slow = 1000;
    private int[][] lastDays = null;

    public SilkRoadContest() { }

     /**
     * Establece la velocidad (tiempo de espera en milisegundos)
     * entre los pasos de la simulación.
     *
     * tiempo en milisegundos. Si es negativo, se toma como 0.
     */
    
    public void setSlow(long millis) {
        if (millis < 0) millis = 0;
        this.slow = millis;
    }

    /**
     * Atajo que establece una pausa estándar de 1 segundo (1000 ms)
     * entre los pasos de simulación.
     */
    
    public void slow() {
        this.slow = 1000; 
    }

    /**
     *  Calcula la máxima utilidad diaria.
     * 
     * Además, guarda los datos  para que
     * puedan ser usados posteriormente por el simulate()}.
     * 
     *
     *  days matriz de utilidades (cada fila representa un día)
     *  arreglo con la máxima utilidad por cada día
     */
    
    public int[] solve(int[][] days) {
        this.lastDays = days;

        if (days == null || days.length == 0) {
            return new int[0];
        }

        int[] maxDailyProfit = new int[days.length];

        for (int i = 0; i < days.length; i++) {
            if (days[i] == null || days[i].length == 0) {
                maxDailyProfit[i] = 0;
                continue;
            }
            int max = days[i][0];
            for (int j = 1; j < days[i].length; j++) {
                if (days[i][j] > max) {
                    max = days[i][j];
                }
            }
            maxDailyProfit[i] = max;
        }

        return maxDailyProfit;
    }

    /**
     *  Simula día a día usando los últimos datos cargados.
     * 
     * Si es o vacío, se muestra un mensaje
     * y la simulación no se ejecuta.
     */
    
    public void simulate() {
        simulate(this.lastDays);
    }

    /**
     * Simula la ejecución día a día mostrando en consola cada resultado.
     * 
     * Si days es  null o vacío, no se realiza la simulación.
     * 
     *
     *  days matriz de datos a simular; cada fila representa un día.
     */
    
    public void simulate(int[][] days) {
        if (days == null || days.length == 0) {
            System.out.println("simulate(): no hay datos para simular.");
            return;
        }

        int[] profits = solve(days);

        System.out.println("Simulación de la Maratón de Silk Road ");
        for (int i = 0; i < profits.length; i++) {
            System.out.println("Día " + (i + 1) + ": utilidad máxima = " + profits[i]);

            try {
                if (slow > 0) Thread.sleep(slow);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Simulación interrumpida.");
                return;
            }
        }
        System.out.println("Fin de la simulación");
    }
}
