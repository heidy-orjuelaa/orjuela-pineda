package silkRoad;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

/**
 * Clase de pruebas de aceptación rigurosas para la clase SilkRoad.
 * Verifica el comportamiento de los constructores, la gestión de tiendas y robots,
 * el movimiento, y el manejo de excepciones, incluyendo la lógica específica
 * de las subclases (AutonomousStore, FighterStore, NeverBackRobot, TenderRobot).
 */
public class SilkRoadTest {

    private SilkRoad silkRoad;
    private final int LENGTH = 10;
    private final int INITIAL_TENGE = 100;

    /**
     * Configuración inicial antes de cada prueba.
     */
    @BeforeEach
    void setUp() throws Exception {
        // La longitud de 10 permite probar ubicaciones 0 a 9
        silkRoad = new SilkRoad(LENGTH);
        System.out.println("--- Nueva prueba iniciada ---");
    }

    /**
     * Limpieza después de cada prueba.
     */
    @AfterEach
    void tearDown() {
        if (silkRoad != null) {
            silkRoad.finish(); // Asegura que todo se limpie y se oculte
        }
        System.out.println("--- Prueba finalizada ---\n");
    }

    // PRUEBAS DE CONSTRUCTOR Y REINICIO

    @Test
    void testConstructorInvalidoLongitudCero() {
        System.out.println("Ejecutando: testConstructorInvalidoLongitudCero");
        Exception exception = assertThrows(Exception.class, () -> {
            new SilkRoad(0);
        }, "Se esperaba una excepción para longitud 0.");

        String mensajeEsperado = "La longitud de la ruta debe ser mayor que cero.";
        assertTrue(exception.getMessage().contains(mensajeEsperado), "❌ Fallo: Mensaje de excepción incorrecto.");
        System.out.println(" Éxito: Constructor falla correctamente con longitud 0.");
    }

    @Test
    void testRebootYFinishLimpianTodo() throws Exception {
        System.out.println("Ejecutando: testRebootYFinishLimpianTodo");
        silkRoad.placeStore(1, 10);
        silkRoad.placeRobot(5);

        silkRoad.reboot();

        assertTrue(silkRoad.stores().isEmpty(), "Reboot: La lista de tiendas no se vació.");
        assertTrue(silkRoad.robots().isEmpty(), "Reboot: La lista de robots no se vació.");
        System.out.println(" Éxito: reboot() vacía las listas.");
    }


    // PRUEBAS DE TIENDAS

    @Test
    void testPlaceStoreTiposValidos() throws Exception {
        System.out.println("Ejecutando: testPlaceStoreTiposValidos");

        silkRoad.placeStore(1, 50, "normal");
        silkRoad.placeStore(2, 75, "autonomous");
        silkRoad.placeStore(3, 100, "fighter");

        ArrayList<Store> tiendas = silkRoad.stores();
        
        // Verificación de tipos de instancia
        assertTrue(tiendas.get(0).getClass().equals(Store.class), "Tienda 1 debe ser tipo Store (normal).");
        assertTrue(tiendas.get(1) instanceof AutonomousStore, "Tienda 2 debe ser AutonomousStore.");
        assertTrue(tiendas.get(2) instanceof FighterStore, "Tienda 3 debe ser FighterStore.");

        System.out.println(" Éxito: Colocación de Store, AutonomousStore y FighterStore exitosa.");
    }

    @Test
    void testPlaceAutonomousStoreIgnoraUbicacionInicial() throws Exception {
        System.out.println("Ejecutando: testPlaceAutonomousStoreIgnoraUbicacionInicial");
        
        // Colocamos el AutonomousStore en la posición 5
        silkRoad.placeStore(5, INITIAL_TENGE, "autonomous"); 
        
        Store as = silkRoad.stores().get(0);
        
        // La implementación de AutonomousStore usa randLocation(), que devuelve un valor [0, MAX_LENGTH - 1] (MAX_LENGTH = 100).
        // Por lo tanto, no debe estar en 5, ni debe estar dentro del límite de SilkRoad (0-9).
        
        assertNotEquals(5, as.getLocation(), "❌ Fallo: AutonomousStore no debe usar la ubicación dada (5).");
        
        // NOTA: Si randLocation() devuelve un valor > 9, la lógica de SilkRoadGUI fallaría al dibujar, 
        // pero la clase SilkRoad la acepta. Solo verificamos que ignore la entrada 5.
        
        System.out.println(" Éxito: AutonomousStore ignora la ubicación de entrada. Ubicación real: " + as.getLocation());
    }
    
    
    @Test
    void testResupplyStores() throws Exception {
        System.out.println("Ejecutando: testResupplyStores");
        silkRoad.placeStore(1, 50);
        Store s = silkRoad.stores().get(0);
        
        s.setTenges(10); // Simular retiro
        assertEquals(10, s.getTenges(), "Stock inicial no modificado.");
        
        silkRoad.resupplyStores();
        
        assertEquals(50, s.getTenges(), "La tienda no se reabasteció a su valor inicial.");
        System.out.println("Éxito: resupplyStores() restaura el stock inicial.");
    }
    
    //  PRUEBAS DE ROBOTS
    

    @Test
    void testPlaceRobotTiposValidos() throws Exception {
        System.out.println("Ejecutando: testPlaceRobotTiposValidos");
        
        silkRoad.placeRobot(1, "normal");
        silkRoad.placeRobot(2, "neverback");
        silkRoad.placeRobot(3, "tender");

        ArrayList<Robot> robots = silkRoad.robots();
        
        assertTrue(robots.get(0).getClass().equals(Robot.class), "Robot 1 debe ser tipo Robot (normal).");
        assertTrue(robots.get(1) instanceof NeverBackRobot, "Robot 2 debe ser NeverBackRobot.");
        assertTrue(robots.get(2) instanceof TenderRobot, "Robot 3 debe ser TenderRobot.");
        
        System.out.println(" Éxito: Colocación de Robot, NeverBackRobot y TenderRobot exitosa.");
    }

    @Test
    void testNeverBackRobotMovimientoRestringido() throws Exception {
        System.out.println("Ejecutando: testNeverBackRobotMovimientoRestringido");
        silkRoad.placeRobot(5, "neverback");
        Robot r = silkRoad.robots().get(0);
        
        // 1. Movimiento válido (adelante)
        silkRoad.moveRobot(5, 2);
        assertEquals(7, r.getLocation(), "NeverBackRobot falló al moverse hacia adelante.");
        
        // 2. Movimiento inválido (atrás)
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            silkRoad.moveRobot(7, -1);
        }, "Se esperaba IllegalArgumentException al mover un NeverBackRobot hacia atrás.");

        String mensajeEsperado = "El robot NeverBack no puede moverse hacia atrás.";
        assertTrue(exception.getMessage().contains(mensajeEsperado), "❌ Fallo: Mensaje de restricción incorrecto.");
        assertEquals(7, r.getLocation(), "El robot no debe moverse después de la excepción.");
        System.out.println("Éxito: NeverBackRobot impide correctamente el movimiento negativo.");
    }
    
    
    // PRUEBAS DE INTERACCIÓN Y LÓGICA

    @Test
    void testLogicTenderRobotCollectsHalf() throws Exception {
        System.out.println("Ejecutando: testLogicTenderRobotCollectsHalf");
        silkRoad.placeStore(5, 100);
        silkRoad.placeRobot(5, "tender");
        
        Store s = silkRoad.stores().get(0);
        TenderRobot tr = (TenderRobot) silkRoad.robots().get(0);
        
        // Simulamos la recolección del TenderRobot
        tr.collectFrom(s);

        assertEquals(50, tr.getProfit(), "TenderRobot no recogió la mitad (50) del dinero.");
        assertEquals(50, s.getTenges(), "La tienda no se quedó con la mitad (50) del dinero.");

        // Segunda recolección
        tr.collectFrom(s);
        
        assertEquals(50 + 25, tr.getProfit(), "TenderRobot falló en la segunda recolección (25).");
        assertEquals(25, s.getTenges(), "La tienda falló al actualizar su stock (25).");
        System.out.println(" Éxito: TenderRobot recoge exactamente la mitad del stock.");
    }
    
    @Test
    void testLogicFighterStoreInteraction() throws Exception {
        System.out.println("Ejecutando: testLogicFighterStoreInteraction");
        silkRoad.placeStore(3, 80, "fighter");
        silkRoad.placeRobot(3); // Robot Normal
        
        FighterStore fs = (FighterStore) silkRoad.stores().get(0);
        Robot r = silkRoad.robots().get(0);
        
        // 1. Robot tiene 0 de ganancia. 0 < 80. (No debe interactuar).
        fs.interact(r);
        assertEquals(0, r.getProfit(), "Robot ganó dinero cuando no debía (0 < 80).");
        assertEquals(80, fs.getTenges(), "Tienda perdió dinero cuando no debía (0 < 80).");
        
        // 2. Robot gana 100 de otra fuente (simulación).
        r.addProfit(100);
        assertEquals(100, r.getProfit(), "Ganancia de robot no actualizada correctamente.");
        
        // 3. Robot tiene 100. 100 > 80. (Debe interactuar y vaciar tienda).
        fs.interact(r);
        
        assertEquals(100 + 80, r.getProfit(), "Robot no tomó los 80 tenges de la tienda.");
        assertEquals(0, fs.getTenges(), "Tienda no se vació tras la interacción exitosa.");
        System.out.println("Éxito: FighterStore interactúa solo si el robot es 'más rico'.");
    }
    
    @Test
    void testProfitCalculatesTotal() throws Exception {
        System.out.println("Ejecutando: testProfitCalculatesTotal");
        
        silkRoad.placeRobot(1);
        silkRoad.placeRobot(2, "neverback");
        silkRoad.placeRobot(3, "tender");
        
        Robot r1 = silkRoad.robots().stream().filter(r -> r.getLocation() == 1).findFirst().get();
        Robot r2 = silkRoad.robots().stream().filter(r -> r.getLocation() == 2).findFirst().get();
        Robot r3 = silkRoad.robots().stream().filter(r -> r.getLocation() == 3).findFirst().get();
        
        r1.addProfit(10);
        r2.addProfit(20);
        r3.addProfit(30);

        assertEquals(10 + 20 + 30, silkRoad.profit(), "El cálculo de ganancia total es incorrecto.");
        System.out.println("Éxito: profit() suma correctamente las ganancias de todos los robots.");
    }
}