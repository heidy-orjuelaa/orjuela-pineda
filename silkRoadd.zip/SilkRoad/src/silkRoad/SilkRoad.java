package silkRoad;
import java.util.ArrayList;

/**
 * Clase principal que modela el simulador de la Ruta de la Seda.
 *
 * Esta clase gestiona las tiendas y los robots que interactúan en el recorrido.
 * Permite crear, eliminar y mover robots y tiendas, así como mostrar el estado
 * gráfico del juego (visible o invisible).
 *
 * @author
 *  (Orjuela - Pineda)
 * @version 4.0
 */
public class SilkRoad {

    private int length;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private boolean visible;

    /**
     * Crea una nueva Ruta de la Seda con una longitud dada.
     * @param length Número de posiciones del recorrido.
     * @throws Exception si la longitud es inválida.
     */
    public SilkRoad(int length) throws Exception {
        if (length <= 0) {
            throw new Exception("La longitud de la ruta debe ser mayor que cero.");
        }
        this.length = length;
        stores = new ArrayList<>();
        robots = new ArrayList<>();
        visible = false;
    }

    
    public SilkRoad(int[][] days) throws Exception {
        this(days.length);
    }

    /**
     * Crea una tienda normal en una ubicación específica.
     *
     * @param location posición donde se ubicará la tienda.
     * @param tenges cantidad inicial de tenges en la tienda.
     * @throws Exception si la ubicación es inválida, ya hay una tienda o los tenges son negativos.
     */
    public void placeStore(int location, int tenges) throws Exception {
        
        if (location < 0 || location >= length) {
            throw new Exception("Ubicación fuera de los límites de la ruta (0 - " + (length - 1) + ").");
        }
        
        for (Store s : stores) {
            if (s.getLocation() == location) {
                throw new Exception("Ya existe una tienda en la posición " + location + ".");
            }
        }

        if (tenges < 0) {
            throw new Exception("La cantidad de tenges no puede ser negativa.");
        }
        
        Store nueva = new Store(location, tenges);
        stores.add(nueva);
       
        if (visible) nueva.show();
    }

    /**
     * Crea una tienda según tipo.
     * @param type "normal", "autonomous" o "fighter"
     * @throws IndexOutOfBoundsException si la ubicación está fuera del rango.
     * @throws IllegalArgumentException si el tipo de tienda no es válido.
     */
    public void placeStore(int location, int tenges, String type) 
            throws IndexOutOfBoundsException, IllegalArgumentException {

        if (location < 0 || location >= length) {
            throw new IndexOutOfBoundsException("Ubicación de tienda fuera de los límites de la ruta.");
        }

        Store nueva;

        switch (type.toLowerCase()) {
            case "autonomous" -> nueva = new AutonomousStore(location, tenges);
            case "fighter" -> nueva = new FighterStore(location, tenges);
            case "normal" -> nueva = new Store(location, tenges); 
            default -> throw new IllegalArgumentException("Tipo de tienda desconocido: " + type);
        }

        stores.add(nueva);
        if (visible) nueva.show();
    }
  
    /**
     * Elimina una tienda de una ubicación específica, si existe.
     * 
     * @param location ubicación de la tienda a eliminar.
     * @throws Exception si no hay tiendas registradas o no existe una tienda en esa ubicación.
     */
    public void removeStore(int location) throws Exception {
        if (stores.isEmpty()) {
            throw new Exception("No hay tiendas registradas para eliminar.");
        }

        boolean removed = stores.removeIf(store -> {
            boolean coincide = store.getLocation() == location;
            if (coincide) store.hide();
            return coincide;
        });

        if (!removed) {
            throw new Exception("No se encontró una robot en la ubicación " + location + ".");
        }
    }

    /**
     * Crea un robot normal en una ubicación.
     * @throws Exception si la ubicación está fuera de los límites o ya hay un robot allí.
     */
    public void placeRobot(int location) throws Exception {
        if (location < 0 || location >= length) {
            throw new Exception("Ubicación fuera de los límites (0 - " + (length - 1) + ").");
        }
        for (Robot r : robots) {
            if (r.getLocation() == location) {
                throw new Exception("Ya existe un robot en la posición " + location + ".");
            }
        }
        Robot nuevo = new Robot(location, "blue");
        robots.add(nuevo);
        if (visible) nuevo.show();
    }

    /**
     * Crea un robot de un tipo específico.
     * @throws Exception si la ubicación es inválida, el tipo no es reconocido o ya hay un robot allí.
     */
    public void placeRobot(int location, String type) throws Exception {
        if (location < 0 || location >= length) {
            throw new Exception("Ubicación fuera de los límites (0 - " + (length - 1) + ").");
        }

        for (Robot r : robots) {
            if (r.getLocation() == location) {
                throw new Exception("Ya existe un robot en la posición " + location + ".");
            }
        }

        if (type == null || type.isEmpty()) {
            throw new Exception("Debes especificar un tipo de robot válido.");
        }

        Robot nuevo;
        switch (type.toLowerCase()) {
            case "neverback" -> nuevo = new NeverBackRobot(location, "red");
            case "tender" -> nuevo = new TenderRobot(location, "green");
            case "normal" -> nuevo = new Robot(location, "blue");
            default -> throw new Exception("Tipo de robot no reconocido: " + type);
        }

        robots.add(nuevo);
        if (visible) nuevo.show();
    }


    /**
     * Elimina un robot en una ubicación específica.
     * @throws Exception si no hay robots o no existe uno en la ubicación dada.
     */
    public void removeRobot(int location) throws Exception {
        if (robots.isEmpty()) {
            throw new Exception("No hay robots para eliminar.");
        }
        boolean removed = robots.removeIf(robot -> {
            boolean coincide = robot.getLocation() == location;
            if (coincide) robot.hide();
            return coincide;
        });
        if (!removed) {
            throw new Exception("No se encontró un robot en la ubicación " + location + ".");
        }
    }
 

    /**
     * Mueve un robot desde su ubicación actual una cantidad determinada de metros.
     * @throws Exception si no hay robot en la posición indicada.
     */
    public void moveRobot(int location, int meters) throws Exception {
        boolean encontrado = false;
        for (Robot r : robots) {
            if (r.getLocation() == location) {
                encontrado = true;
                int nuevaUbicacion = r.getLocation() + meters;
                if (nuevaUbicacion < 0) nuevaUbicacion = 0;
                if (nuevaUbicacion >= length) nuevaUbicacion = length - 1;
                r.move(nuevaUbicacion - r.getLocation());
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("No se encontró un robot en la ubicación " + location + ".");
        }
    }
    
    
    /**
     * Mueve todos los robots.
     */
    
    public void moveRobots() {
        for (Robot r : robots) {
            r.move(1); 
        }
    }

    
    /**
     * Devuelve la lista de robots actuales.
     * 
     * @return ArrayList de robots.
     */

    public ArrayList<Robot> robots() {
        return robots;
    }

    /**
     * Devuelve la lista de tiendas actuales.
     * 
     * @return ArrayList de tiendas.
     */
    
    public ArrayList<Store> stores() {
        return stores;
    }
     

    /**
     * Reinicia la posición de todos los robots a su estado inicial.
     */
    
    public void returnRobots() {
        for (Robot robot : robots) {
            robot.resetPosition();
        }
    }

    /**
     * Reabastece todos las tienda.
     */
    
    public void resupplyStores() {
        for (Store store : stores) {
            store.resupply();
        }
    }

    /**
     * Reinicia el sistema ocultando todos los robots y tiendas
     * y limpiando las listas de robots y tiendas.
     */
    
    public void reboot() {
        for (Store s : stores) s.hide();
        for (Robot r : robots) r.hide();
        stores.clear();
        robots.clear();
    }

    /**
     * Calcula las ganancias totales de los robots.
     * @throws Exception si no hay robots creados.
     */
    public int profit() throws Exception {
        if (robots.isEmpty()) {
            throw new Exception("No hay robots creados para calcular ganancias.");
        }
        int total = 0;
        for (Robot robot : robots) {
            total += robot.getProfit();
        }
        return total;
    }

    /**
     * Hace visibles todos los robots y tiendas del sistema.
     */
    
    public void makeVisible() {
        visible = true;
        for (Store store : stores) store.show();
        for (Robot robot : robots) robot.show();
    }

    /**
     * Hace invisibles todos los robots y tiendas del sistema.
     */
    
    public void makeInvisible() {
        visible = false;
        for (Store store : stores) store.hide();
        for (Robot robot : robots) robot.hide();
    }
    
    /**
     * Termina la ejecución del sistema, reiniciando todo y ocultando los elementos.
     */

    public void finish() {
        reboot();
        visible = false;
    }

    
    public boolean ok() {
        return true;
    }
}
