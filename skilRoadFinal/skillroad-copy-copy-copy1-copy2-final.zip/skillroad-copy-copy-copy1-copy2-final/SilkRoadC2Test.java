import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class SilkRoadC2Test {

    private SilkRoad road;

    @Before
    public void setUp() {
        // Creamos una ruta de longitud 10 y la ponemos invisible para pruebas
        road = new SilkRoad(10);
        road.makeInvisible();
    }

    @Test
    public void testPlaceAndRemoveStore() {
        road.placeStore(3, 50);
        assertEquals(1, road.stores().length);

        road.removeStore(3);
        assertEquals(0, road.stores().length);
    }

    @Test
    public void testPlaceRobotAndMove() {
        road.placeRobot(2);
        assertEquals(1, road.robots().length);

        road.moveRobot(2, 3); // Mueve 3 metros
        assertEquals(5, road.robots()[0][0]); // Nueva ubicación esperada
    }

    @Test
    public void testResupplyStores() {
        road.placeStore(4, 20);
        road.moveRobot(0, 4); // Simula que el robot consume la tienda
        road.resupplyStores();

        assertTrue(road.stores()[0][1] > 0); // Debe haberse restaurado
    }

    @Test
    public void testReturnRobots() {
        road.placeRobot(1);
        road.moveRobot(1, 5);
        road.returnRobots();

        assertEquals(1, road.robots()[0][0]); // Volvió a la posición inicial
    }

    @Test
    public void testProfitCalculation() {
        road.placeRobot(0);
        road.placeStore(1, 10);
        road.moveRobot(0, 1);

        int profit = road.profit();
        assertTrue(profit >= 0);
    }

    @Test
    public void testBlinkHighestProfitRobot() {
        road.placeRobot(0);
        road.placeRobot(5);
        // Simular ganancias
        road.moveRobot(0, 2); // Supongamos que gana algo
        road.moveRobots();    // Lógica debe decidir quién parpadea

        // Verificar que solo uno parpadea
        int blinkingCount = 0;
        for (int[] robot : road.robots()) {
            // Debemos consultar desde la clase Robot si está blinking
            // Supongamos que tenemos método isBlinking() accesible
            // blinkingCount += (robotObject.isBlinking() ? 1 : 0);
        }
        assertTrue(blinkingCount <= 1);
    }
}
